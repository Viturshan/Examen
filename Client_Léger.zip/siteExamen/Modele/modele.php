<?php
    /*
    Dans ce fichier, on réalise toutes les fonctions de connexion à la BDD,
    deconnexion de la BDD et exécution dde l'ensemble des requêtes sur les tables de la BDD: insert, delete, update,select. */


    function connexion(){
       $connexion=mysqli_connect("localhost","root","","site_de_vehicule");
       if($connexion == null){
         echo"Erreur de connexion au serveur Mysql.";
       }
       return $connexion;

    }
    function deconnexion($connexion){
       mysqli_close($connexion);

    }
    /**********************Gestion des concession******************/
    function InsertConcession ($tab){
       $requete= "insert into concession values(null, '"
       .$tab['nom']."','"
       .$tab['adresse']."','"
       .$tab['datecreation']."','"
       .$tab['telephone']."') ;";

       $con = connexion (); //appel de la connexion
       mysqli_query ($con, $requete);//execution de la requete
       deconnexion ($con); //deconnexion de la base de données
    }
    function SelectAllConcession(){
       $requete ="select * from concession;";
       $con= connexion();
       $lesconcession = mysqli_query($con, $requete);
       deconnexion($con);
       return $lesconcession;
    }
    function DeleteConcession ($idconcession){
       $requete="delete from concession where idconcession=".$idconcession;
       $con= connexion();
       mysqli_query($con, $requete);
       deconnexion($con);


    }
    function Updateconcession ($tab){
       $requete="update concession set nom='".$tab['nom']."'
       ,datecreation='".$tab['datecreation']."'
       ,adresse='".$tab['adresse']."'  
       ,telephone='".$tab['telephone']."'
       where idconcession= ".$tab['idconcession'];
       $con= connexion();
       mysqli_query($con, $requete);
       deconnexion($con);

    }
    function SelectWhereConcession($idconcession){
       $requete="select * from concession where idconcession=".$idconcession;
       $con= connexion();
       $resultats=mysqli_query($con, $requete);
       $lconcession=mysqli_fetch_assoc($resultats);
       deconnexion($con);
       return $lconcession;
    }
     /**********************Gestion des congés******************/
     function InsertConcessionnaire ($tab){
       $requete= "insert into concessionnaire values(null, '"
       .$tab['nom']."','"
       .$tab['diplome']."','"
       .$tab['adresse']."','"
       .$tab['email']."','"
       .$tab['telephone']."') ;";

       $con = connexion (); //appel de la connexion
       mysqli_query ($con, $requete);//execution de la requete
       deconnexion ($con); //deconnexion de la base de données
    }
    function SelectAllConcessionnaires(){
       $requete ="select * from concessionnaire;";
       $con= connexion();
       $lesconcessionnaires = mysqli_query($con, $requete);
       deconnexion($con);
       return $lesconcessionnaires;
    }
    function DeleteConcessionnaire ($idconcessionnaire){
       $requete="delete from concessionnaire where idconcessionnaire=".$idconcessionnaire;
       $con= connexion();
       mysqli_query($con, $requete);
       deconnexion($con);


    }
    function UpdateConcessionnaire ($tab){
       $requete="update concessionnaire set nom='"
       .$tab['nom']."'
       ,diplome='"
       .$tab['diplome']."'
       ,adresse='"
       .$tab['adresse']."'
       ,email='"
       .$tab['email']."'
       ,telephone='"
       .$tab['telephone']."'
       where idconcessionnaire= ".$tab['idconcessionnaire'];
       $con= connexion();
       mysqli_query($con, $requete);
       deconnexion($con);

    }
    function SelectWhereConcessionnaire($idconcessionnaire){
       $requete="select * from concessionnaire where idconcessionnaire=".$idconcessionnaire;
       $con= connexion();
       $resultats=mysqli_query($con, $requete);
       $leconcessionnaire=mysqli_fetch_assoc($resultats);
       deconnexion($con);
       return $leconcessionnaire;
    }
    /**********************Gestion des client******************/
    function InsertClient ($tab){
       $requete= "insert into client values(null, '"
       .$tab['nom']."','"
       .$tab['diplome']."','"
       .$tab['email']."','"
       .$tab['telephone']."','"
       .$tab['adresse']."') ;";

       $con = connexion (); //appel de la connexion
       mysqli_query ($con, $requete);//execution de la requete
       deconnexion ($con); //deconnexion de la base de données
    }
    function SelectAllClient(){
       $requete ="select * from client;";
       $con= connexion();
       $lesclient = mysqli_query($con, $requete);
       deconnexion($con);
       return $lesclient;
    }
    function DeleteClient ($idclient){
       $requete="delete from client where idclient=".$idclient;
       $con= connexion();
       mysqli_query($con, $requete);
       deconnexion($con);


    }
    function UpdateClient ($tab){
       $requete="update client set nom='".$tab['nom']."'
       ,diplome='".$tab['diplome']."'
       ,email='".$tab['email']."'
       ,telephone='".$tab['telephone']."'
       ,adresse='".$tab['adresse']."'
       where idclient= ".$tab['idclient'];
       $con= connexion();
       mysqli_query($con, $requete);
       deconnexion($con);

    }
    function SelectWhereClient($idclient){
       $requete="select * from client where idclient=".$idclient;
       $con= connexion();
       $resultats=mysqli_query($con, $requete);
       $lclient=mysqli_fetch_assoc($resultats);
       deconnexion($con);
       return $lclient;
    }
    /**********************Gestion des revendeur******************/
    function InsertRevendeur ($tab){
      $requete= "insert into revendeur values(null, '"
      .$tab['nom']."','"
     .$tab['diplome']."','"
     .$tab['adresse']."','"
     .$tab['email']."','"
     .$tab['telephone']."') ;";

     $con = connexion (); //appel de la connexion
     mysqli_query ($con, $requete);//execution de la requete
     deconnexion ($con); //deconnexion de la base de données
    }
    function SelectAllRevendeur(){
        $requete ="select * from revendeur;";
        $con= connexion();
        $lesrevendeur = mysqli_query($con, $requete);
        deconnexion($con);
        return $lesrevendeur;
    }
    function DeleteRevendeur ($idrevendeur){
        $requete="delete from revendeur where idrevendeur=".$idrevendeur;
        $con= connexion();
        mysqli_query($con, $requete);
        deconnexion($con);
    }
    function UpdateRevendeur ($tab){
        $requete="update revendeur set nom='".$tab['nom']."'
        ,diplome='".$tab['diplome']."'
        ,adresse='".$tab['adresse']."'
        ,email='".$tab['email']."'
        ,telephone='".$tab['telephone']."'
        where idrevendeur= ".$tab['idrevendeur'];
        $con= connexion();
        mysqli_query($con, $requete);
        deconnexion($con);
    }
    function SelectWhereRevendeur($idrevendeur){
        $requete="select * from revendeur where idrevendeur=".$idrevendeur;
        $con= connexion();
        $resultats=mysqli_query($con, $requete);
        $lerevendeur=mysqli_fetch_assoc($resultats);
        deconnexion($con);
        return $lerevendeur;
    }
   /**********************Gestion des réponses******************/
   function InsertTechnicien($tab){
    $requete= "insert into technicien values(null, '"
    .$tab['nom']."','"
    .$tab['prenom']."','"
    .$tab['adresse']."','"
    .$tab['email']."','"
    .$tab['telephone']."','"
    .$tab['diplome']."') ;";

    $con = connexion (); //appel de la connexion
    mysqli_query ($con, $requete);//execution de la requete
    deconnexion ($con); //deconnexion de la base de données
    }
    function SelectAllTechniciens(){
    $requete ="select * from technicien;";
    $con= connexion();
    $lesTechniciens = mysqli_query($con, $requete);
    deconnexion($con);
    return $lesTechniciens;
    }
    function DeleteTechnicien ($idtechnicien){
    $requete="delete from technicien where idtechnicien=".$idtechnicien;
    $con= connexion();
    mysqli_query($con, $requete);
    deconnexion($con);
    }
    function UpdateTechnicien ($tab){
    $requete="update technicien set nom='".$tab['nom']."'
    ,prenom='".$tab['prenom']."'
    ,adresse='".$tab['adresse']."'
    telephone='".$tab['telephone']."'
    ,diplome='".$tab['diplome']."'
    where idtechnicien= ".$tab['idtechnicien'];
    $con= connexion();
    mysqli_query($con, $requete);
    deconnexion($con);

    }
    function SelectWhereTechnicien($idtechnicien){
    $requete="select * from technicien where idtechnicien=".$idtechnicien;
    $con= connexion();
    $resultats=mysqli_query($con, $requete);
    $leTechnicien=mysqli_fetch_assoc($resultats);
    deconnexion($con);
    return $leTechnicien;
    }
    /************/
    function InsertVehicule($idvehicule){
      $requete="insert into vehicule values(null, '"
      .$tab['marque']."','"
      .$tab['matricule']."','"
      .$tab['energie']."','"
      .$tab['kilometrage']."','"
      .$tab['datedecirculation']."';'";
    }
    function SelectAllVehicule(){
      $requete ="select * from vehicule;";
      $con= connexion();
      $lesvehicules = mysqli_query($con, $requete);
      deconnexion($con);
      return $lesvehicules;
  }
  function SelectWhereVehicule($idvehicule){
   $requete="select * from vehicule where idvehicule=".$idvehicule;
   $con= connexion();
   $resultats=mysqli_query($con, $requete);
   $leVehicule=mysqli_fetch_assoc($resultats);
   deconnexion($con);
   return $leVehicule;
   }


   function LibelleCategorie($categorie){
      $libelle="";
      if ($categorie==1){ 
         $libelle="Sportive";
      }
      elseif ($categorie==2){
         $libelle="Citadine";
      }
      else{
         $libelle="Error";
      }
      return $libelle;
   }

   function DeleteVehicule ($idvehicule){
      $requete="delete from vehicule where idvehicule=".$idvehicule;
      echo "Ligne supprimée avec succès";
      $con= connexion();
      mysqli_query($con, $requete);
      deconnexion($con);
   }
?>