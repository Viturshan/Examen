<!DOCTYPE html>
<html>
<head>
<title>Catalogue</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css" />
<link rel="stylesheet" type="text/css" href="../style.css">
<script src="https://kit.fontawesome.com/d2648eda2a.js" crossorigin="anonymous"></script>
</head>
<body>
    <?php
        include 'Header.php';
     ?>

<?php
$bdd=new PDO('mysql:host=localhost;dbname=site_de_vehicule;charset=utf8;','root','');
 
?>
<!DOCTYPE html>
<html>
<head>
<title>Inscription</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<header>
<nav class="navbar bg-body-tertiary">
<div class="container-fluid">
    <a class="navbar-brand">Inscription</a>
<form class="d-flex" role="search">
<input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
<button class="btn btn-outline-success" type="submit">Search</button>
</form>
</div>
</nav>
</header>
    <form method ="POST" action="" align="center">
         Pseudo
         <br>
         <input type="text" name="pseudo">
         <br>
         Mot de passe<br>
         <input type="password" name="mdp">
         <br>
         <label for="profil">Vous êtes ?</label>
    
   
    <input list="profil-list" id="profil" name="profil" placeholder="Sélectionnez votre profil...">
        
      
    <datalist id="profil-list">
            
           
    
       
    <option value="Particulier">
            
          
    
      
    <option value="Vendeur">
            
        
    </datalist>
         <input type="submit" name="Valider">  
    
    </form>
    <?php
    if(isset($_POST['Valider'])){
        if(!empty($_POST['pseudo']) AND ! empty($_POST['mdp']) AND ! empty($_POST['profil'])){
            $pseudo=htmlspecialchars($_POST['pseudo']);
            $mdp=sha1($_POST['mdp']);
            $profil=htmlspecialchars($_POST['profil']);
            $insertUser=$bdd->prepare('insert into utilisateur(pseudo,mdp,profil) values (?,?,?);');
            $insertUser->execute(array($pseudo,$mdp,$profil));

            $recupUser = $bdd-> prepare('select * from utilisateur where pseudo = ? AND mdp = ? AND profil=?;');
            $recupUser->execute(array($pseudo,$mdp,$profil));
    
            if($recupUser->rowCount() >0 ){
                $_SESSION['pseudo']=$pseudo;
                $_SESSION['mdp']=$mdp;
                $_SESSION['profil']=$profil;
                echo "Inscription réussie !";
                
    
            }else{
                echo "Votre mot de passe ou votre pseudo est incorrect.";
            }
    
        }else{
            echo "Veuillez complétez les champs suivants.";
        }
    } 
    ?> 
</body>
</html>