<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vente à la concession</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css" />
    <link rel="stylesheet" type="text/css" href="../style.css">
    <script src="https://kit.fontawesome.com/d2648eda2a.js" crossorigin="anonymous"></script>


    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            padding: 4px; /* Réduire la taille des cellules */
            text-align: left;
            border-bottom: 1px solid #ddd;
            font-size: 12px; /* Réduire la taille de la police */
        }

        th {
            background-color: #f2f2f2;
        }
    </style>



</head>
<body>
    <?php
        include 'Header.php';
     ?>
   <form method="post">
   <center>
   <table>
            <h1>Ajout d'une voiture en vente</h1>
<tr>
    <td> Marque </td>
    <td> <input type="text" name="marque" required></td>
</tr>
<tr>
    <td>Immatriculation</td>
    <td> <input type="text" name="matricule" required></td>
</tr>
<tr>
    <td> Energie utilisée  </td>
    <td> <input type="text" name="energie" required></td>
</tr>
<tr>
    <td> Kilométrage </td>
    <td> <input type="number" name="kilometrage" required></td>
</tr>
<tr>
    <td> Date de première mise en circulation </td>
    <td> <input type="date" name="datedecirculation" required></td>
</tr>
<tr>
    <td>Catégorie 1 ou 2 pour respectivement haute gamme et citadine</td>
    <td><input type="number" name="categorie" required></td>
<tr>
    <td> <input type="reset" name="Annuler" value="Annuler"> </td>
    <td> <input type="submit" name="Valider" value="Valider"></td>
</tr>
</table>
   </form>
   <?php
        require_once("../modele/modele.php");
        $bdd = new PDO('mysql:host=localhost;dbname=site_de_vehicule;charset=utf8', 'root', '');
            $recupVehicule = $bdd->prepare('SELECT * FROM vehicule;');
            $recupVehicule->execute();
            $vehicule = $recupVehicule->fetchAll(PDO::FETCH_ASSOC);
            if (isset($_POST['Valider'])) {
                if (!empty($_POST['marque']) && !empty($_POST['matricule']) && !empty($_POST['energie']) && !empty($_POST['kilometrage']) && !empty($_POST['datedecirculation'])) {
                    $marque = htmlspecialchars($_POST['marque']);
                    $matricule = htmlspecialchars($_POST['matricule']);
                    $energie = htmlspecialchars($_POST['energie']);
                    $kilometrage = htmlspecialchars($_POST['kilometrage']);
                    $datedecirculation = htmlspecialchars($_POST['datedecirculation']);
                    $categorie = htmlspecialchars($_POST['categorie']);
                    
                    $insertUser = $bdd->prepare('INSERT INTO vehicule (marque, matricule, energie, kilometrage, datedecirculation,categorie) VALUES (?, ?, ?, ?, ?, ?)');
                    $insertUser->execute(array($marque, $matricule, $energie, $kilometrage, $datedecirculation,$categorie));
                    echo "Véhicule ajouté à la concession";

                    }
                 else {
                    echo "Veuillez compléter tous les champs.";
                }
                unset($_POST['Valider']);
            }
            
            
        
?>


    <title>Liste des véhicules</title>
    
<body>
    <h2>Liste des véhicules de la catégorie Sportive</h2>
    <table>
        <tr>
            <th>ID Vehicule</th>
            <th>Marque</th>
            <th>Matricule</th>
            <th>Energie</th>
            <th>Kilometrage</th>
            <th>Date de circulation</th>
            <th>Catégorie</th>
        </tr>
        <?php foreach ($vehicule as $row) : ?>
            <tr>
                <td><?php echo $row['idvehicule']; ?></td>
                <td><?php echo $row['marque']; ?></td>
                <td><?php echo $row['matricule']; ?></td>
                <td><?php echo $row['energie']; ?></td>
                <td><?php echo $row['kilometrage']; ?></td>
                <td><?php echo $row['datedecirculation']; ?></td>
                <td><?php echo LibelleCategorie($row['categorie']); ?></td>
                <?php echo "<td> <form method='post'>
                    <input type='hidden' name='id' value='".$row['idvehicule']."'>
                    <input type='submit' name='supprimerligne' value='Supprimer'>
                    </form>
                </td>";
                
                ?>
            </tr>
        <?php endforeach; ?>
        <?php
        if(isset($_POST['supprimerligne'])){
                    $id = $_POST['id'];
                    DeleteVehicule($id);
                }
        ?>
    </table>
</center>
</body>
</html>

