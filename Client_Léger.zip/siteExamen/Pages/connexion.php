<!DOCTYPE html>
<html>
<head>
<title>Connexion au site de vente de véhicules d'occasion</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css" />
<link rel="stylesheet" type="text/css" href="../style.css">
<script src="https://kit.fontawesome.com/d2648eda2a.js" crossorigin="anonymous"></script>
</head>
<body>
    <?php
        include 'Header.php';
     ?>
<?php
$bdd=new PDO('mysql:host=localhost;dbname=site_de_vehicule;charset=utf8;','root','');
if(isset($_POST['Valider'])){
    if(!empty($_POST['pseudo']) AND ! empty($_POST['mdp'])){
        $pseudo=htmlspecialchars($_POST['pseudo']);
        $mdp=sha1($_POST['mdp']);
        $recupUser = $bdd-> prepare('select * from utilisateur where pseudo= ? AND mdp = ?;');
        $recupUser->execute(array($pseudo,$mdp));
        $user = $recupUser->fetchAll(PDO::FETCH_ASSOC);

        if($recupUser->rowCount() ==1 ){
           $_SESSION['pseudo']=$user[0]['pseudo'];
           $_SESSION['mdp']=$user[0]['mdp'];
           $_SESSION['profil']=$user[0]['profil'];
           // var_dump($user[0]['pseudo']);
           echo "Connexion réussie";
          

        }else{
            echo "Votre mot de passe ou votre pseudo est incorrect.";
        }

    }else{
        echo "Veuillez complétez les champs suivants.";
    }
} 
?>
<!DOCTYPE html>
<html>
<body>
    <form method ="POST" action="" align="center">
         Pseudo
         <br>
         <input type="text" name="pseudo">
         <br>
    
         Mot de passe<br>
         <input type="password" name="mdp">
         <br>
    
        
      
    <datalist id="profil-list">
            
           
    
       
    <option value="Particulier">
            
          
    
      
    <option value="Vendeur">
            
        
    </datalist>
         <input type="submit" name="Valider">  
    
    </form>
    <?php
    /*
        if(isset($_POST['Valider'])){
            if(!empty($_POST['pseudo']) AND ! empty($_POST['mdp'])){
                $pseudo=htmlspecialchars($_POST['pseudo']);
                $mdp=sha1($_POST['mdp']);
                $profil=htmlspecialchars($_POST['profil']);
                $recupUser = $bdd-> prepare('select * from utilisateur where pseudo= ? AND mdp = ? AND profil= ?;');
                $recupUser->execute(array($pseudo,$mdp,$profil));
        
                if($recupUser->rowCount() >0 ){
                    $_SESSION['pseudo']=$pseudo;
                    $_SESSION['mdp']=$mdp;
                    $_SESSION['id']=$recupUser->fetch()['id'];
                    echo "Connexion réussie";
                    if ($profil == "Particulier") {
                        echo '<a href="Catalogue.php"> Aller sur le catalogue</a>';
                    } elseif ($profil == "Vendeur") {
                        echo '<a href="concession.php">Ajouter une voiture au catalogue</a>';
                    }
                    
               
            }else{
                echo "Veuillez complétez les champs suivants.";
            }
        
        } 
    }
    */
    ?>    
        <p align="center">Pas encore inscrit ? Pas de soucis, cliquez sur le bouton ci-dessous pour faire un pas de plus vers la voiture de votre destinée</p>
        <a href="inscription.php"><button class="btn btn-outline-success" type="submit" >S'inscrire</button></a>
</body>