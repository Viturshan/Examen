<!DOCTYPE html>
<html>
<head>
<title>Messagerie</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css" />
<link rel="stylesheet" type="text/css" href="../style.css">
<script src="https://kit.fontawesome.com/d2648eda2a.js" crossorigin="anonymous"></script>
</head>
<body>
     <?php
        include 'Header.php';
     ?>
<body>
<center>
    <form method ="POST" action="" align="center">
         Pseudo
         <br>
         <input type="text" name="pseudo">
         <br>
         Commentaire
         <br>
         <textarea name="com"></textarea>
         <br>
         <input type="submit" name="Valider">  

    </form>
    <section id="messages"></section>
</center>
</body>
</html>
<?php
    require_once("../Modele/modele.php");
?>
<?php
try {
    $bdd = new PDO('mysql:host=localhost;dbname=site_de_vehicule;charset=utf8', 'root', '');
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die('Erreur : ' . $e->getMessage());
}

if (isset($_POST['Valider'])) {
    if (!empty($_POST['pseudo']) && !empty($_POST['com'])) {
        $pseudo = htmlspecialchars($_POST['pseudo']);
        $com = nl2br(htmlspecialchars($_POST['com']));

        $insertUser = $bdd->prepare('INSERT INTO messages(pseudo, com) VALUES (?, ?)');
        $insertUser->execute(array($pseudo, $com));

        $recupUser = $bdd->prepare('SELECT * FROM messages WHERE pseudo = ? AND com = ?');
        $recupUser->execute(array($pseudo, $com));

        if ($recupUser->rowCount() > 0) {
            session_start();
            $_SESSION['pseudo'] = $pseudo;
            $_SESSION['com'] = $com;
            echo "Commentaire envoyé!";
            echo $_SESSION['com'];
        }
    } else {
        echo "Veuillez compléter les champs suivants.";
    }
}
?>
