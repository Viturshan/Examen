
     <!--Barre de Navigation-->
        <nav>
            <h1> <img src="../images/logo_peugeot.png" height="100" width="100" alt="image 1" class="round-image"> </h1>
            <div class="onglets" >
                <a href="Accueil.php"><p >Accueil</p><br></a>
                <a href="Catalogue.php"><p >Catalogue</p><br></a>
                <?php
                session_start();
                if (isset($_SESSION['profil']) && $_SESSION['profil']=='Vendeur'){

                    echo '<a href="concession.php"><p >Vente</p>';
                }
                ?>
                <a href="connexion.php"><p >Mon Compte</p><br></a>
                <a href="Contact.php"><p><i class="fa-solid fa-envelope"></i></p></a>
                <?php
                    if (isset($_SESSION['pseudo'])) {
                        echo 'Utilisateur connecté:'.$_SESSION["pseudo"];
                    }
                    else{
                        echo 'Pas d\'utilisateur connecté   ';
                    }
                ?>
                <br>
                <form method="post" action="">
                    <input type="submit" name="logout" value="Déconnexion">
                </form>
                <?php
                    if (isset($_POST['logout'])) {
                        // Détruire toutes les variables de session
                        $_SESSION = array();
                    
                        // Détruire la session
                        session_destroy();
                    }
                ?>
                <a href="panier.php"><p><i class="fa-solid fa-cart-shopping"></i></p></a>
                <form class="d-flex" role="search">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">    
                </form>
            </div>
        </nav>
        <!--Fin de la barre-->
