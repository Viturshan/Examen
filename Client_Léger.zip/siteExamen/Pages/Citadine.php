<!DOCTYPE html>
<html>
<head>
<title>Citadine</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css" />
<link rel="stylesheet" type="text/css" href="../style.css">
<script src="https://kit.fontawesome.com/d2648eda2a.js" crossorigin="anonymous"></script>
</head>
<body>
    <?php
        include 'Header.php';
     ?>
    <h1>Bienvenue sur le catalogue des voitures citadines</h1>
    <?php
    try {
        $bdd = new PDO('mysql:host=localhost;dbname=site_de_vehicule;charset=utf8', 'root', '');
        $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
        $recupUser = $bdd->prepare('SELECT * FROM vehicule where categorie=2;');
        $recupUser->execute();
        $vehicule = $recupUser->fetchAll(PDO::FETCH_ASSOC);
       // var_dump($vehicule);
    } catch (PDOException $e) {
        echo 'Erreur : ' . $e->getMessage();
    }
    require_once("../modele/modele.php");
    ?>

<html>
<head>
    <title>Liste des véhicules</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            padding: 4px; /* Réduire la taille des cellules */
            text-align: left;
            border-bottom: 1px solid #ddd;
            font-size: 12px; /* Réduire la taille de la police */
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h2>Liste des véhicules de la catégorie Citadine</h2>
    <table>
        <tr>
            <th>ID Vehicule</th>
            <th>Marque</th>
            <th>Matricule</th>
            <th>Energie</th>
            <th>Kilometrage</th>
            <th>Date de circulation</th>
            <th>Catégorie</th>
        </tr>
        <?php foreach ($vehicule as $row) : ?>
            <tr>
                <td><?php echo $row['idvehicule']; ?></td>
                <td><?php echo $row['marque']; ?></td>
                <td><?php echo $row['matricule']; ?></td>
                <td><?php echo $row['energie']; ?></td>
                <td><?php echo $row['kilometrage']; ?></td>
                <td><?php echo $row['datedecirculation']; ?></td>
                <td><?php echo LibelleCategorie($row['categorie']); ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>






<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catalogue des véhicules</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="style2.css">
</head>
    <footer>

        <h1>Nos services</h1>
        <div class="services">
            
            <div class="service">
                <h3>Livraison gratuite</h3>
                <p>Pour tout achat de voiture la livraison de votre véhicule vous est offerte pour faciliter la récupération de votre achat.</p>
            </div>

            <div class="service">
                <h3>Paiement en ligne</h3>
                <p>Le paiement de votre véhicule peut être fait intégralement en ligne pour vous éviter le déplacement en concession. Cela vous permet de finir toutes les procédures depuis chez vous sans avoir à vous préoccuper des horaires d'ouverture.</p>
            </div>

            <div class="service">
                <h3>Aimé ou remboursé</h3>
                <p>Vous remarquez un problème ou simplement le véhicule ne correspond pas à ce que vous pensiez? Pas de soucis vous pouvez le renvoyer et nous vous remboursons la somme dans un délai de 7 jours ouvrés.</p>
            </div>

        </div>

        <p id="contact">Contact : 08 19 17 278 1 | &copy; 2021, Burgure.</p>
    </footer>
</body>
</html>



