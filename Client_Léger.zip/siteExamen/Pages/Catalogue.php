<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css" />
    <title>Catalogue des véhicules</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../style.css">
    <script src="https://kit.fontawesome.com/d2648eda2a.js" crossorigin="anonymous"></script>
</head>
<body>
    <?php
        include 'Header.php';
     ?>

    <section class="main" id="produits">

        <div class="content">
            <div class="card">
                <div class="left">
                   <h4><a href="haute_gamme.php">Berlines, Sportives, SUV</a></h4>
                   <p>Découvrez notre vaste sélection de véhicules neufs et d'occasion,
                         soigneusement sélectionnés pour répondre à toutes vos attentes. 
                         Que vous recherchiez une berline élégante, un SUV robuste ou une sportive luxueuse, 
                         nous avons la voiture qu'il vous faut. Profitez de nos offres exclusives et de notre 
                         service client exceptionnel pour une expérience d'achat automobile inégalée.
                    </p>
                </div>
                <div class="right">
                    <a href="haute_gamme.php"><img src="../images/haute_gamme.jpg" alt="image2"></a>
                </div>
            </div>

            <div class="card">
                <div class="left">
                    <h4><a href="Citadine.php">Familiales, Citadines </a></h4>
                    <p>Découvrez notre sélection de véhicules neufs et d'occasion, 
                        soigneusement sélectionnés pour répondre à toutes vos attentes. 
                        Que vous recherchiez un véhicule passe partout ou un véhicule plus abordable 
                        nous avons ce qu'il vous faut. Profitez de nos offre exclusives et de notre 
                        service client exceptionnel pour une expériende d'achat automobile inégalée.</p>
                </div>
                <div class="right">
                    <a href="Citadine.php"><img src="../images/citadine.jpg" alt="image3"></a>
                </div>
            </div>
        </div>
    </section>

    <footer>

        <h1>Nos services</h1>
        <div class="services">
            
            <div class="service">
                <h3>Livraison gratuite</h3>
                <p>Pour tout achat de voiture la livraison de votre véhicule vous est offerte pour faciliter la récupération de votre achat.</p>
            </div>

            <div class="service">
                <h3>Paiement en ligne</h3>
                <p>Le paiement de votre véhicule peut être fait intégralement en ligne pour vous éviter le déplacement en concession. Cela vous permet de finir toutes les procédures depuis chez vous sans avoir à vous préoccuper des horaires d'ouverture.</p>
            </div>

            <div class="service">
                <h3>Aimé ou remboursé</h3>
                <p>Vous remarquez un problème ou simplement le véhicule ne correspond pas à ce que vous pensiez? Pas de soucis vous pouvez le renvoyer et nous vous remboursons la somme dans un délai de 7 jours ouvrés.</p>
            </div>

        </div>

        <p id="contact">Contact : 08 19 17 278 1 | &copy; 2021, Burgure.</p>
    </footer>
</body>
</html>