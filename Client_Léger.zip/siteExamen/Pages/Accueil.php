<!DOCTYPE html>
<html>
<head>
<title>Site de vente de voitures d'occasion de Peugeot</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css" />
<link rel="stylesheet" type="text/css" href="../style.css">
<script src="https://kit.fontawesome.com/d2648eda2a.js" crossorigin="anonymous"></script>
</head>
<body>
    <?php
        include 'Header.php';
     ?>
    <center>
    <h2> Bienvenue au sein du groupe Peugeot</h2>
    <br>
    <p id="p"> Peugeot est une marque automobile française qui fait partie du groupe Stellantis depuis 2021, suite à la fusion de PSA Peugeot Citroën et Fiat Chrysler Automobiles. Fondée en 1810 comme fabricant de moulins à café et de bicyclettes, Peugeot s'est diversifiée dans la fabrication d'automobiles en 1889.
    Peugeot a une présence mondiale avec une forte implantation en Europe, en Afrique, au Moyen-Orient, en Amérique du Sud et en Asie. La marque continue d'étendre son influence, en s'adaptant aux besoins spécifiques de chaque marché.  
    Face a la crise de la COVID19 pour le marché de l'automobile, Peugeot souhaite créer un site pour la vente de voitures d'occasion. Elle souhaite s'installer dans le marché de l'occasion et développer sa gamme de voiture.
    </p>
    <br>


    <a href="https://www.peugeot.fr/"> Visiter le site de Peugeot </a>
    <br>
    </center>
</body>
</html>