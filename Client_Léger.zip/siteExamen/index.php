<?php 
session_start();
//echo $_SESSION['pseudo'];
?>
<!DOCTYPE html>
<html>
<head>
<title>Site de vente de voitures d'occasion de Peugeot</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css" />
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>


    
    <!--Barre de Navigation-->
    <nav>
        <h1> <img src="images/logo_peugeot.png" height="100" width="100" alt="image 1" class="round-image"> </h1>
        <div class="onglets" >
            <a href="Pages/Accueil.php"><p >Accueil</p><br></a>
            <a href="Pages/Catalogue.php"><p >Catalogue</p><br></a>
            <p >Vente</p><br>
            <a href="connexion/connexion.php"><p >Mon Compte</p><br></a>
            <form class="d-flex" role="search">
                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">    
              </form>
            <a href="Pages/Contact.php"><p><i class="fa-solid fa-envelope"></i></p></a>
            <a href="Pages/favoris.php"><p><i class="fa-solid fa-heart"></i></p></a>
            <a href="Pages/panier.php"><p><i class="fa-solid fa-cart-shopping"></i></p></a>
        </div>
    </nav>
    <!--Fin de la barre-->
    <!-- header-->
    <header>
       <h1>Le véhicule de vos rêves en un clic</h1>
      <a href ="Pages/Catalogue.php"> <button>Naviguer <i class="fas fa-paper-plane"></i></button></a>
    </header>


    <footer>
        <h2>Coordonnées</h2>
        <pre>09 70 80 91 20       12 avenue de Cléry           mail.contact.informatique@peugeot.fr           <a id="n" href="<https://www.linkedin.com/school/cfa-insta/?originalSubdomain=fr>">linkedin</a></pre>
    </footer>

</body>
</html>