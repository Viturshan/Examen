DROP DATABASE IF EXISTS site_de_vehicule;
CREATE DATABASE site_de_vehicule;
USE site_de_vehicule;

CREATE TABLE utilisateur(
    idutilisateur INT(3) NOT NULL AUTO_INCREMENT,
    pseudo VARCHAR(50),
    mdp VARCHAR(50),
    profil VARCHAR(50),
    PRIMARY KEY(idutilisateur)
);
CREATE table messages(
    idmessages int(3) not null auto_increment,
    pseudo varchar(50),
    com varchar(50),
    primary key(idmessages)
);
CREATE TABLE concession(
    idconcession INT(3) NOT NULL AUTO_INCREMENT, 
    nom VARCHAR(50),
    adresse VARCHAR(50),
    datecreation DATE,
    telephone VARCHAR(50),
    PRIMARY KEY(idconcession)
);

CREATE TABLE concessionnaire(
    idconcessionnaire INT(3) NOT NULL AUTO_INCREMENT,
    nom VARCHAR(50),
    prenom VARCHAR(50),
    adresse VARCHAR(50),
    email VARCHAR(50),
    telephone VARCHAR(50),
    PRIMARY KEY(idconcessionnaire)
);

CREATE TABLE client(
    idclient INT(3) NOT NULL AUTO_INCREMENT,
    nom VARCHAR(20), 
    prenom VARCHAR(50),
    email VARCHAR(50),
    telephone VARCHAR(50),
    adresse VARCHAR(50),
    PRIMARY KEY(idclient)
);

CREATE TABLE revendeur (
    idrevendeur INT(3) NOT NULL AUTO_INCREMENT,
    nom VARCHAR(50),
    prenom VARCHAR(50),
    adresse VARCHAR(50),
    email VARCHAR(50),
    telephone VARCHAR(50),
    PRIMARY KEY(idrevendeur)
);

CREATE TABLE technicien (
    idtechnicien INT(3) NOT NULL AUTO_INCREMENT,
    nom VARCHAR(50),
    prenom VARCHAR(50),
    adresse VARCHAR(50),
    email VARCHAR(50),
    telephone VARCHAR(50),
    diplome VARCHAR(50),
    PRIMARY KEY(idtechnicien)
);

CREATE TABLE controle_technique(
    idcontrole INT(3) NOT NULL AUTO_INCREMENT,
    datedereparation DATE,
    prix FLOAT,
    nbpieces INT,
    idtechnicien INT(3) NOT NULL,
    PRIMARY KEY(idcontrole),
    FOREIGN KEY (idtechnicien) REFERENCES technicien(idtechnicien)
);

CREATE TABLE vehicule(
    idvehicule INT(3) NOT NULL AUTO_INCREMENT,
    marque VARCHAR(50),
    matricule VARCHAR(50),
    energie VARCHAR(50),
    kilometrage INT,
    datedecirculation DATE,
    categorie INT,
    PRIMARY KEY(idvehicule)
);
