-- -----------------------------------------------------
-- Script de la base de données E-Peugeot
-- -----------------------------------------------------

-- Suppression de la base si elle existe
DROP DATABASE IF EXISTS epeugeot;

-- Création de la base de données
CREATE DATABASE epeugeot;
USE epeugeot;

-- -----------------------------------------------------
-- Création des tables
-- -----------------------------------------------------

-- Table des utilisateurs
CREATE TABLE utilisateur (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) UNIQUE NOT NULL,
    mot_de_passe VARCHAR(255) NOT NULL,
    nom VARCHAR(50) NOT NULL,
    prenom VARCHAR(50) NOT NULL,
    adresse TEXT,
    telephone VARCHAR(20),
    role ENUM('CLIENT', 'ADMIN') DEFAULT 'CLIENT',
    date_creation DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table des catégories de véhicules
CREATE TABLE categorie (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(50) NOT NULL,
    description TEXT,
    slug VARCHAR(50) UNIQUE NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table des véhicules
CREATE TABLE vehicule (
    id INT AUTO_INCREMENT PRIMARY KEY,
    marque varchar(50) not null,
    reference VARCHAR(50) UNIQUE NOT NULL,
    modele VARCHAR(100) NOT NULL,
    description TEXT,
    annee INT NOT NULL,
    kilometrage INT NOT NULL,
    prix_vente DECIMAL(10, 2) NOT NULL,
    prix_location_jour DECIMAL(10, 2) NOT NULL,
    disponible BOOLEAN DEFAULT true,
    categorie_id INT NOT NULL,
    date_ajout DATETIME DEFAULT CURRENT_TIMESTAMP,
    images TEXT,
    FOREIGN KEY (categorie_id) REFERENCES categorie(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table des locations
CREATE TABLE location (
    id INT AUTO_INCREMENT PRIMARY KEY,
    utilisateur_id INT NOT NULL,
    vehicule_id INT NOT NULL,
    date_debut DATE NOT NULL,
    date_fin DATE NOT NULL,
    prix_total DECIMAL(10, 2) NOT NULL,
    statut ENUM('EN_ATTENTE', 'CONFIRMEE', 'EN_COURS', 'TERMINEE', 'ANNULEE') DEFAULT 'EN_ATTENTE',
    date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateur(id) ON DELETE RESTRICT,
    FOREIGN KEY (vehicule_id) REFERENCES vehicule(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table des ventes
CREATE TABLE vente (
    id INT AUTO_INCREMENT PRIMARY KEY,
    utilisateur_id INT NOT NULL,
    vehicule_id INT NOT NULL,
    prix_vente DECIMAL(10, 2) NOT NULL,
    statut ENUM('EN_ATTENTE', 'PAYEE', 'LIVREE', 'ANNULEE') DEFAULT 'EN_ATTENTE',
    date_vente DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateur(id) ON DELETE RESTRICT,
    FOREIGN KEY (vehicule_id) REFERENCES vehicule(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table du panier
CREATE TABLE panier (
    id INT AUTO_INCREMENT PRIMARY KEY,
    utilisateur_id INT NOT NULL,
    vehicule_id INT NOT NULL,
    type ENUM('LOCATION', 'ACHAT') NOT NULL,
    date_debut DATE,
    date_fin DATE,
    date_ajout DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateur(id) ON DELETE CASCADE,
    FOREIGN KEY (vehicule_id) REFERENCES vehicule(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table pour les historiques
CREATE TABLE historique_prix (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vehicule_id INT NOT NULL,
    ancien_prix_vente DECIMAL(10, 2) NOT NULL,
    nouveau_prix_vente DECIMAL(10, 2) NOT NULL,
    ancien_prix_location DECIMAL(10, 2) NOT NULL,
    nouveau_prix_location DECIMAL(10, 2) NOT NULL,
    date_modification DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vehicule_id) REFERENCES vehicule(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE historique_modifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    table_name VARCHAR(50) NOT NULL,
    record_id INT NOT NULL,
    champ_modifie VARCHAR(50) NOT NULL,
    ancienne_valeur TEXT,
    nouvelle_valeur TEXT,
    date_modification DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------
-- Création des triggers
-- -----------------------------------------------------
DELIMITER //

-- Trigger pour l'historique des prix
CREATE TRIGGER before_vehicule_update
BEFORE UPDATE ON vehicule
FOR EACH ROW
BEGIN
    IF NEW.prix_vente != OLD.prix_vente OR NEW.prix_location_jour != OLD.prix_location_jour THEN
        INSERT INTO historique_prix (
            vehicule_id,
            ancien_prix_vente,
            nouveau_prix_vente,
            ancien_prix_location,
            nouveau_prix_location
        ) VALUES (
            OLD.id,
            OLD.prix_vente,
            NEW.prix_vente,
            OLD.prix_location_jour,
            NEW.prix_location_jour
        );
    END IF;
END //

-- Trigger pour vérifier les locations
CREATE TRIGGER before_location_insert
BEFORE INSERT ON location
FOR EACH ROW
BEGIN
    IF NEW.date_fin <= NEW.date_debut THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'La date de fin doit être postérieure à la date de début';
    END IF;

    IF EXISTS (
        SELECT 1 FROM location 
        WHERE vehicule_id = NEW.vehicule_id
        AND statut NOT IN ('ANNULEE', 'TERMINEE')
        AND (
            (date_debut BETWEEN NEW.date_debut AND NEW.date_fin)
            OR (date_fin BETWEEN NEW.date_debut AND NEW.date_fin)
            OR (date_debut <= NEW.date_debut AND date_fin >= NEW.date_fin)
        )
    ) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = ''Le véhicule n\'est pas disponible pour ces dates';
    END IF;
END //

-- Trigger pour vérifier les ventes
CREATE TRIGGER before_vente_insert
BEFORE INSERT ON vente
FOR EACH ROW
BEGIN
    DECLARE v_disponible BOOLEAN;
    
    SELECT disponible INTO v_disponible
    FROM vehicule
    WHERE id = NEW.vehicule_id;
    
    IF NOT v_disponible THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = ''Le véhicule n\'est pas disponible à la vente';
    END IF;
END //

-- Trigger pour le statut des ventes
CREATE TRIGGER after_vente_status_update
AFTER UPDATE ON vente
FOR EACH ROW
BEGIN
    IF NEW.statut = 'PAYEE' AND OLD.statut != 'PAYEE' THEN
        UPDATE vehicule
        SET disponible = false
        WHERE id = NEW.vehicule_id;
    END IF;
    
    IF NEW.statut = 'ANNULEE' AND OLD.statut != 'ANNULEE' THEN
        UPDATE vehicule
        SET disponible = true
        WHERE id = NEW.vehicule_id;
    END IF;
END //

-- Trigger pour le panier
CREATE TRIGGER before_panier_insert
BEFORE INSERT ON panier
FOR EACH ROW
BEGIN
    IF EXISTS (
        SELECT 1 FROM panier
        WHERE utilisateur_id = NEW.utilisateur_id
        AND vehicule_id = NEW.vehicule_id
    ) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Ce véhicule est déjà dans votre panier';
    END IF;

    IF NEW.type = 'LOCATION' THEN
        IF NEW.date_debut IS NULL OR NEW.date_fin IS NULL THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Les dates sont obligatoires pour une location';
        END IF;
        
        IF NEW.date_fin <= NEW.date_debut THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'La date de fin doit être postérieure à la date de début';
        END IF;
        
        IF NEW.date_debut < CURDATE() THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'La date de début ne peut pas être dans le passé';
        END IF;
    END IF;
END //

-- -----------------------------------------------------
-- Création des procédures stockées
-- -----------------------------------------------------

-- Procédure pour calculer le prix d'une location
CREATE PROCEDURE calculer_prix_location(
    IN p_vehicule_id INT,
    IN p_date_debut DATE,
    IN p_date_fin DATE,
    OUT p_prix_total DECIMAL(10, 2)
)
BEGIN
    DECLARE v_prix_jour DECIMAL(10, 2);
    DECLARE v_nb_jours INT;
    
    SELECT prix_location_jour INTO v_prix_jour 
    FROM vehicule 
    WHERE id = p_vehicule_id;
    
    SET v_nb_jours = DATEDIFF(p_date_fin, p_date_debut) + 1;
    SET p_prix_total = v_prix_jour * v_nb_jours;
END //

-- Procédure pour valider une location
CREATE PROCEDURE valider_location(
    IN p_location_id INT
)
BEGIN
    UPDATE location 
    SET statut = 'CONFIRMEE'
    WHERE id = p_location_id;
    
    UPDATE vehicule v
    JOIN location l ON l.vehicule_id = v.id
    SET v.disponible = false
    WHERE l.id = p_location_id;
END //

DELIMITER ;

-- -----------------------------------------------------
-- Insertion des données initiales
-- -----------------------------------------------------

-- Insertion des catégories
INSERT INTO categorie (nom, description, slug) VALUES
('Citadines', 'Véhicules compacts parfaits pour la ville', 'citadines'),
('Berlines', 'Véhicules confortables pour longs trajets', 'berlines');

-- Insertion de l'administrateur
INSERT INTO utilisateur (email, mot_de_passe, nom, prenom, role) VALUES
('admin@epeugeot.fr', 'admin123', 'Admin', 'System', 'ADMIN');

-- Insertion des véhicules de démonstration
INSERT INTO vehicule (reference, modele, description, annee, kilometrage, prix_vente, prix_location_jour, categorie_id) VALUES
('208-001', 'Peugeot 208', 'Citadine polyvalente, parfaite pour la ville', 2022, 15000, 18500.00, 45.00, 1),
('508-001', 'Peugeot 508', 'Berline haut de gamme', 2022, 20000, 35000.00, 75.00, 2);
