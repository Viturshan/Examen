package vue.dialogs;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import modele.entites.Vehicule;
import controleur.PanierControleur;
import util.ImageManager;
import java.util.Date;
import com.toedter.calendar.JDateChooser; // Pour le sélecteur de date

public class DialogDetailVehicule extends JDialog implements ActionListener {
    private Vehicule vehicule;
    private JLabel lbImage;
    private JTextArea txtDescription;
    private JPanel panelDates;
    private JDateChooser dateDebut, dateFin;
    private JButton btAcheter, btLouer, btFermer;
    private int utilisateurId;

    public DialogDetailVehicule(JFrame parent, Vehicule vehicule, int utilisateurId) {
        super(parent, "Détail du véhicule", true);
        this.vehicule = vehicule;
        this.utilisateurId = utilisateurId;
        
        this.setSize(800, 600);
        this.setLocationRelativeTo(parent);
        this.setLayout(null);
        this.setResizable(false);

        // Image du véhicule
        this.lbImage = ImageManager.createImageLabel(vehicule.getReference(), 400, 300);
        this.lbImage.setBounds(20, 20, 400, 300);
        this.add(this.lbImage);

        // Informations principales
        JPanel panelInfo = new JPanel(new GridLayout(6, 2, 10, 10));
        panelInfo.setBounds(440, 20, 320, 200);
        panelInfo.setBorder(BorderFactory.createTitledBorder("Informations"));
       
        panelInfo.add(new JLabel("Marque :"));
        panelInfo.add(new JLabel(vehicule.getMarque()));
        
        panelInfo.add(new JLabel("Modèle :"));
        panelInfo.add(new JLabel(vehicule.getModele()));
        
        panelInfo.add(new JLabel("Année :"));
        panelInfo.add(new JLabel(String.valueOf(vehicule.getAnnee())));
        
        panelInfo.add(new JLabel("Kilométrage :"));
        panelInfo.add(new JLabel(vehicule.getKilometrage() + " km"));
        
        panelInfo.add(new JLabel("Prix de vente :"));
        panelInfo.add(new JLabel(vehicule.getPrixVente() + " €"));
        
        panelInfo.add(new JLabel("Prix location/jour :"));
        panelInfo.add(new JLabel(vehicule.getPrixLocationJour() + " €"));
        
//        panelInfo.add(new JLabel("État :"));
//        panelInfo.add(new JLabel(vehicule.getEtat()));
        
        this.add(panelInfo);

        // Description
        JLabel lbDescription = new JLabel("Description :");
        lbDescription.setBounds(20, 330, 100, 25);
        this.add(lbDescription);

        this.txtDescription = new JTextArea(vehicule.getDescription());
        this.txtDescription.setEditable(false);
        this.txtDescription.setLineWrap(true);
        this.txtDescription.setWrapStyleWord(true);
        JScrollPane scrollDescription = new JScrollPane(this.txtDescription);
        scrollDescription.setBounds(20, 360, 740, 100);
        this.add(scrollDescription);

        // Panel dates pour location
        this.panelDates = new JPanel(null);
        this.panelDates.setBounds(440, 240, 320, 100);
        this.panelDates.setBorder(BorderFactory.createTitledBorder("Période de location"));
        
        JLabel lbDateDebut = new JLabel("Date début :");
        lbDateDebut.setBounds(20, 30, 80, 25);
        this.dateDebut = new JDateChooser();
        this.dateDebut.setBounds(100, 30, 150, 25);
        
        JLabel lbDateFin = new JLabel("Date fin :");
        lbDateFin.setBounds(20, 60, 80, 25);
        this.dateFin = new JDateChooser();
        this.dateFin.setBounds(100, 60, 150, 25);
        
        this.panelDates.add(lbDateDebut);
        this.panelDates.add(this.dateDebut);
        this.panelDates.add(lbDateFin);
        this.panelDates.add(this.dateFin);
        this.panelDates.setVisible(false);
        this.add(this.panelDates);

        // Boutons
        JPanel panelBoutons = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        panelBoutons.setBounds(20, 480, 740, 40);
        
        this.btAcheter = new JButton("Ajouter au panier (Achat)");
        this.btLouer = new JButton("Ajouter au panier (Location)");
        this.btFermer = new JButton("Fermer");
        
        panelBoutons.add(this.btAcheter);
        panelBoutons.add(this.btLouer);
        panelBoutons.add(this.btFermer);
        this.add(panelBoutons);

        // Ajout des écouteurs
        this.btAcheter.addActionListener(this);
        this.btLouer.addActionListener(this);
        this.btFermer.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == this.btAcheter) {
            this.ajouterAuPanier("ACHAT");
        }
        else if(e.getSource() == this.btLouer) {
            if(!this.panelDates.isVisible()) {
                this.panelDates.setVisible(true);
                this.btLouer.setText("Valider la location");
            } else {
                this.ajouterAuPanier("LOCATION");
            }
        }
        else if(e.getSource() == this.btFermer) {
            this.dispose();
        }
    }

    private void ajouterAuPanier(String type) {
    	System.out.println("Début de ajouter au panier");
        if(type.equals("LOCATION")) {
            // Vérification des dates
            if(this.dateDebut.getDate() == null || this.dateFin.getDate() == null) {
                JOptionPane.showMessageDialog(this,
                    "Veuillez sélectionner les dates de location",
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if(this.dateDebut.getDate().after(this.dateFin.getDate())) {
                JOptionPane.showMessageDialog(this,
                    "La date de début doit être antérieure à la date de fin",
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Vérification de la disponibilité
            if(!new modele.dao.LocationDAO().disponible(
                this.vehicule.getId(),
                this.dateDebut.getDate(),
                this.dateFin.getDate())) {
                JOptionPane.showMessageDialog(this,
                    "Le véhicule n'est pas disponible pour ces dates",
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        // Ajout au panier
        if(PanierControleur.ajouterAuPanier(this.createPanierItem(type))) {
            JOptionPane.showMessageDialog(this,
                "Véhicule ajouté au panier avec succès !",
                "Succès",
                JOptionPane.INFORMATION_MESSAGE);
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(this,
                "Erreur lors de l'ajout au panier",
                "Erreur",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private modele.entites.Panier createPanierItem(String type) {
        if(type.equals("LOCATION")) {
            return new modele.entites.Panier(
                this.utilisateurId,
                this.vehicule.getId(),
                this.dateDebut.getDate(),
                this.dateFin.getDate()
            );
        } else {
            return new modele.entites.Panier(
                this.utilisateurId,
                this.vehicule.getId()
            );
        }
    }
}