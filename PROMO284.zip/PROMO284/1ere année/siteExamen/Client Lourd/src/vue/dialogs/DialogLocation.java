package vue.dialogs;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Date;
import java.math.BigDecimal;
import com.toedter.calendar.JDateChooser;
import modele.entites.Vehicule;
import modele.entites.Location;
import controleur.LocationControleur;
import util.SystemMessages;

public class DialogLocation extends JDialog implements ActionListener {
    private Vehicule vehicule;
    private int utilisateurId;
    private JDateChooser dateDebut;
    private JDateChooser dateFin;
    private JLabel lbPrixJour;
    private JLabel lbTotal;
    private JButton btCalculer;
    private JButton btValider;
    private JButton btAnnuler;

    public DialogLocation(JFrame parent, Vehicule vehicule, int utilisateurId) {
        super(parent, "Location de véhicule", true);
        this.vehicule = vehicule;
        this.utilisateurId = utilisateurId;

        // Configuration de la fenêtre
        this.setSize(400, 400);
        this.setLocationRelativeTo(parent);
        this.setLayout(null);
        this.setResizable(false);

        // Informations du véhicule
        JPanel panelInfo = new JPanel(new GridLayout(3, 2, 10, 10));
        panelInfo.setBounds(20, 20, 360, 90);
        panelInfo.setBorder(BorderFactory.createTitledBorder("Informations véhicule"));

        panelInfo.add(new JLabel("Modèle :"));
        panelInfo.add(new JLabel(vehicule.getModele()));
        panelInfo.add(new JLabel("Prix par jour :"));
        panelInfo.add(new JLabel(vehicule.getPrixLocationJour() + " €"));
        this.lbPrixJour = new JLabel("Total estimé : ");
        this.lbTotal = new JLabel("0.00 €");
        panelInfo.add(this.lbPrixJour);
        panelInfo.add(this.lbTotal);

        this.add(panelInfo);

        // Sélection des dates
        JPanel panelDates = new JPanel(null);
        panelDates.setBounds(20, 130, 360, 120);
        panelDates.setBorder(BorderFactory.createTitledBorder("Période de location"));

        JLabel lbDateDebut = new JLabel("Date de début :");
        lbDateDebut.setBounds(20, 30, 100, 25);
        this.dateDebut = new JDateChooser();
        this.dateDebut.setBounds(130, 30, 150, 25);
        this.dateDebut.setMinSelectableDate(new Date()); // Pas de date dans le passé

        JLabel lbDateFin = new JLabel("Date de fin :");
        lbDateFin.setBounds(20, 70, 100, 25);
        this.dateFin = new JDateChooser();
        this.dateFin.setBounds(130, 70, 150, 25);
        this.dateFin.setMinSelectableDate(new Date());

        panelDates.add(lbDateDebut);
        panelDates.add(this.dateDebut);
        panelDates.add(lbDateFin);
        panelDates.add(this.dateFin);

        this.add(panelDates);

        // Boutons
        JPanel panelBoutons = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        panelBoutons.setBounds(20, 270, 360, 40);

        this.btCalculer = new JButton("Calculer");
        this.btValider = new JButton("Valider");
        this.btAnnuler = new JButton("Annuler");

        panelBoutons.add(this.btCalculer);
        panelBoutons.add(this.btValider);
        panelBoutons.add(this.btAnnuler);

        this.add(panelBoutons);

        // Écouteurs
        this.btCalculer.addActionListener(this);
        this.btValider.addActionListener(this);
        this.btAnnuler.addActionListener(this);

        // État initial
        this.btValider.setEnabled(false);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == this.btCalculer) {
            this.calculerTotal();
        }
        else if(e.getSource() == this.btValider) {
            this.validerLocation();
        }
        else if(e.getSource() == this.btAnnuler) {
            this.dispose();
        }
    }

    private void calculerTotal() {
        if(this.dateDebut.getDate() == null || this.dateFin.getDate() == null) {
            SystemMessages.showError(this, "Veuillez sélectionner les dates");
            return;
        }

        if(this.dateDebut.getDate().after(this.dateFin.getDate())) {
            SystemMessages.showError(this, "La date de début doit être antérieure à la date de fin");
            return;
        }

        // Calcul du nombre de jours
        long diff = this.dateFin.getDate().getTime() - this.dateDebut.getDate().getTime();
        int nbJours = (int) (diff / (1000 * 60 * 60 * 24)) + 1;

        // Calcul du total
        BigDecimal total = this.vehicule.getPrixLocationJour().multiply(new BigDecimal(nbJours));
        this.lbTotal.setText(total.toString() + " €");

        // Vérification de la disponibilité
        if(LocationControleur.verifierDisponibilite(
            this.vehicule.getId(), 
            this.dateDebut.getDate(), 
            this.dateFin.getDate())) {
            this.btValider.setEnabled(true);
        } else {
            SystemMessages.showError(this, "Le véhicule n'est pas disponible pour ces dates");
            this.btValider.setEnabled(false);
        }
    }

    private void validerLocation() {
        if(SystemMessages.showConfirm(this, "Confirmez-vous la location ?")) {
            // Création de la location
            Location location = new Location(
                this.utilisateurId,
                this.vehicule.getId(),
                this.dateDebut.getDate(),
                this.dateFin.getDate()
            );

            if(LocationControleur.creerLocation(location)) {
                SystemMessages.showSuccess(this, "Location enregistrée avec succès !");
                this.dispose();
            } else {
                SystemMessages.showError(this, "Erreur lors de l'enregistrement de la location");
            }
        }
    }
}