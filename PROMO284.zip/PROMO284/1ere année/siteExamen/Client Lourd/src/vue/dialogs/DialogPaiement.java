package vue.dialogs;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import modele.entites.Utilisateur;
import util.SystemMessages;

public class DialogPaiement extends JDialog implements ActionListener {
    private BigDecimal montant;
    private Utilisateur utilisateur;
    private String type; // "LOCATION" ou "ACHAT"
    
    // Composants de l'interface
    private JComboBox<String> cbTypeCarte;
    private JTextField txtNumeroCarte;
    private JTextField txtNom;
    private JTextField txtDateExpiration;
    private JTextField txtCVC;
    private JButton btPayer;
    private JButton btAnnuler;
    
    public DialogPaiement(JFrame parent, BigDecimal montant, Utilisateur utilisateur, String type) {
        super(parent, "Paiement", true);
        this.montant = montant;
        this.utilisateur = utilisateur;
        this.type = type;
        
        // Configuration de la fenêtre
        this.setSize(400, 500);
        this.setLocationRelativeTo(parent);
        this.setLayout(null);
        this.setResizable(false);
        
        // Panneau d'informations
        JPanel panelInfo = new JPanel(new GridLayout(2, 2, 10, 10));
        panelInfo.setBounds(20, 20, 360, 60);
        panelInfo.setBorder(BorderFactory.createTitledBorder("Informations"));
        
        panelInfo.add(new JLabel("Montant à payer :"));
        panelInfo.add(new JLabel(montant + " €"));
        panelInfo.add(new JLabel("Type :"));
        panelInfo.add(new JLabel(type));
        
        this.add(panelInfo);
        
        // Panneau de paiement
        JPanel panelPaiement = new JPanel(null);
        panelPaiement.setBounds(20, 100, 360, 300);
        panelPaiement.setBorder(BorderFactory.createTitledBorder("Informations de paiement"));
        
        // Type de carte
        JLabel lbTypeCarte = new JLabel("Type de carte :");
        lbTypeCarte.setBounds(20, 30, 100, 25);
        this.cbTypeCarte = new JComboBox<>(new String[]{
            "Visa", "MasterCard", "American Express"
        });
        this.cbTypeCarte.setBounds(130, 30, 200, 25);
        
        // Numéro de carte
        JLabel lbNumeroCarte = new JLabel("Numéro :");
        lbNumeroCarte.setBounds(20, 70, 100, 25);
        this.txtNumeroCarte = new JTextField();
        this.txtNumeroCarte.setBounds(130, 70, 200, 25);
        
        // Nom sur la carte
        JLabel lbNom = new JLabel("Nom :");
        lbNom.setBounds(20, 110, 100, 25);
        this.txtNom = new JTextField(utilisateur.getNomComplet());
        this.txtNom.setBounds(130, 110, 200, 25);
        
        // Date d'expiration
        JLabel lbDateExpiration = new JLabel("Expiration :");
        lbDateExpiration.setBounds(20, 150, 100, 25);
        this.txtDateExpiration = new JTextField("MM/YY");
        this.txtDateExpiration.setBounds(130, 150, 200, 25);
        
        // CVC
        JLabel lbCVC = new JLabel("CVC :");
        lbCVC.setBounds(20, 190, 100, 25);
        this.txtCVC = new JTextField();
        this.txtCVC.setBounds(130, 190, 100, 25);
        
        panelPaiement.add(lbTypeCarte);
        panelPaiement.add(this.cbTypeCarte);
        panelPaiement.add(lbNumeroCarte);
        panelPaiement.add(this.txtNumeroCarte);
        panelPaiement.add(lbNom);
        panelPaiement.add(this.txtNom);
        panelPaiement.add(lbDateExpiration);
        panelPaiement.add(this.txtDateExpiration);
        panelPaiement.add(lbCVC);
        panelPaiement.add(this.txtCVC);
        
        this.add(panelPaiement);
        
        // Boutons
        JPanel panelBoutons = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        panelBoutons.setBounds(20, 420, 360, 40);
        
        this.btPayer = new JButton("Payer " + montant + " €");
        this.btAnnuler = new JButton("Annuler");
        
        panelBoutons.add(this.btPayer);
        panelBoutons.add(this.btAnnuler);
        
        this.add(panelBoutons);
        
        // Écouteurs
        this.btPayer.addActionListener(this);
        this.btAnnuler.addActionListener(this);
        
        // Focus initial
        this.txtNumeroCarte.requestFocus();
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == this.btPayer) {
            this.processPayment();
        }
        else if(e.getSource() == this.btAnnuler) {
            this.dispose();
        }
    }
    
    private final void processPayment() {
        // Validation des champs
        if(!this.validateFields()) {
            return;
        }
        
        // Simulation du paiement (dans un cas réel, appel à un service de paiement)
        JDialog loadingDialog = null;
        try {
            loadingDialog = new JDialog(this, "Traitement du paiement", true);
            JProgressBar progressBar = new JProgressBar();
            progressBar.setIndeterminate(true);
            loadingDialog.add(progressBar);
            loadingDialog.setSize(250, 50);
            loadingDialog.setLocationRelativeTo(this);
            
            // Afficher la dialog de chargement dans un thread séparé
            //new Thread(() -> loadingDialog.setVisible(true)).start();
            loadingDialog.setVisible(true);
            
            // Simulation du délai de traitement
            Thread.sleep(2000);
            
            // Fermer la dialog de chargement
            loadingDialog.dispose();
            
            // Afficher la confirmation
            SystemMessages.showSuccess(this, 
                "Paiement effectué avec succès !\n" +
                "Un email de confirmation vous a été envoyé."
            );
            
            this.dispose();
            
        } catch(InterruptedException ex) {
            if(loadingDialog != null) {
                loadingDialog.dispose();
            }
            SystemMessages.showError(this, "Erreur lors du traitement du paiement");
        }
    }
    
    private boolean validateFields() {
        // Validation du numéro de carte
        String numeroCarte = this.txtNumeroCarte.getText().replaceAll("\\s", "");
        if(numeroCarte.length() < 16 || !numeroCarte.matches("\\d+")) {
            SystemMessages.showError(this, "Numéro de carte invalide");
            this.txtNumeroCarte.requestFocus();
            return false;
        }

        // Validation du nom
        String nom = this.txtNom.getText().trim();
        if(nom.length() < 3 || !nom.matches("[a-zA-Z\\s]+")) {
            SystemMessages.showError(this, "Nom invalide");
            this.txtNom.requestFocus();
            return false;
        }

        // Validation de la date d'expiration
        String dateExpiration = this.txtDateExpiration.getText().trim();
        if(!dateExpiration.matches("(0[1-9]|1[0-2])/[0-9]{2}")) {
            SystemMessages.showError(this, "Date d'expiration invalide (format MM/YY)");
            this.txtDateExpiration.requestFocus();
            return false;
        }

        // Validation du mois d'expiration
        int mois = Integer.parseInt(dateExpiration.substring(0, 2));
        int annee = Integer.parseInt(dateExpiration.substring(3)) + 2000;
        if(!isDateExpirationValide(mois, annee)) {
            SystemMessages.showError(this, "La carte est expirée");
            this.txtDateExpiration.requestFocus();
            return false;
        }

        // Validation du CVC
        String cvc = this.txtCVC.getText().trim();
        if(!cvc.matches("[0-9]{3,4}")) {
            SystemMessages.showError(this, "CVC invalide");
            this.txtCVC.requestFocus();
            return false;
        }

        return true;
    }

    private boolean isDateExpirationValide(int mois, int annee) {
        java.util.Calendar cal = java.util.Calendar.getInstance();
        int currentYear = cal.get(java.util.Calendar.YEAR);
        int currentMonth = cal.get(java.util.Calendar.MONTH) + 1;

        if(annee < currentYear) {
            return false;
        }
        if(annee == currentYear && mois < currentMonth) {
            return false;
        }
        return true;
    }

    // Méthode pour formater automatiquement le numéro de carte
    private void formatNumeroCarte() {
        String numero = this.txtNumeroCarte.getText().replaceAll("\\s", "");
        StringBuilder formatted = new StringBuilder();
        
        for(int i = 0; i < numero.length(); i++) {
            if(i > 0 && i % 4 == 0) {
                formatted.append(" ");
            }
            formatted.append(numero.charAt(i));
        }
        
        this.txtNumeroCarte.setText(formatted.toString());
    }

    // Méthode pour formater automatiquement la date d'expiration
    private void formatDateExpiration() {
        String date = this.txtDateExpiration.getText().replaceAll("/", "");
        if(date.length() > 2) {
            this.txtDateExpiration.setText(date.substring(0, 2) + "/" + date.substring(2));
        }
    }

    // Méthode pour obtenir le résultat du paiement
    public boolean estPaiementValide() {
        return true; // Dans un cas réel, retournerait le résultat du service de paiement
    }

    // Classe interne pour simuler une transaction de paiement
    private class SimulationPaiement {
        private BigDecimal montant;
        private String numeroCarte;
        private String dateExpiration;
        private String cvc;

        public SimulationPaiement(BigDecimal montant, String numeroCarte, 
                                String dateExpiration, String cvc) {
            this.montant = montant;
            this.numeroCarte = numeroCarte;
            this.dateExpiration = dateExpiration;
            this.cvc = cvc;
        }

        public boolean processTransaction() {
            try {
                // Simulation d'une transaction bancaire
                Thread.sleep(2000);
                
                // Dans un cas réel, appel à l'API de paiement
                boolean success = true; // Simuler une réponse positive
                
                if(success) {
                    // Enregistrer la transaction dans la base de données
                    enregistrerTransaction();
                    // Envoyer un email de confirmation
                    envoyerEmailConfirmation();
                }
                
                return success;
            } catch(InterruptedException e) {
                return false;
            }
        }

        private void enregistrerTransaction() {
            // Dans un cas réel, enregistrement dans la base de données
            System.out.println("Transaction enregistrée : " + montant + " €");
        }

        private void envoyerEmailConfirmation() {
            // Dans un cas réel, envoi d'email via un service SMTP
            System.out.println("Email de confirmation envoyé à : " + utilisateur.getEmail());
        }
    }
}