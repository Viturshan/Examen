package vue.panels;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Date;

import controleur.PanierControleur;
import controleur.VehiculeControleur;
import controleur.LocationControleur;
import modele.entites.Vehicule;
import modele.entites.Utilisateur;
import modele.entites.Panier;
import vue.principal.VueGenerale;

public class PanelVehicules extends JPanel implements ActionListener {
    private VueGenerale parent;
    private Utilisateur utilisateurConnecte;
    private JComboBox<String> cbCategories;
    private JTextField txtRecherche;
    private JButton btRechercher = new JButton("Rechercher");
    private JTable tableVehicules;
    private JScrollPane scrollTable;
    
    // Composants pour le détail d'un véhicule
    private JPanel panelDetail = new JPanel();
    private JLabel lbImage = new JLabel();
    private JLabel lbModele = new JLabel();
    private JLabel lbPrix = new JLabel();
    private JLabel lbNonDisponible = new JLabel("VÉHICULE NON DISPONIBLE", JLabel.CENTER);
    private JButton btAcheter = new JButton("Acheter");
    private JButton btLouer = new JButton("Louer");

    public PanelVehicules(VueGenerale parent, Utilisateur utilisateurConnecte) {
        this.parent = parent;
        this.utilisateurConnecte = utilisateurConnecte;
        this.setLayout(null);
        this.setBounds(0, 0, 1200, 650);

        // Configuration des filtres
        JPanel panelFiltres = new JPanel();
        panelFiltres.setBounds(10, 10, 1180, 40);
        panelFiltres.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 5));

        this.cbCategories = new JComboBox<>(new String[]{"Toutes", "Citadines", "Berlines"});
        this.txtRecherche = new JTextField(20);

        panelFiltres.add(new JLabel("Catégorie :"));
        panelFiltres.add(this.cbCategories);
        panelFiltres.add(new JLabel("Recherche :"));
        panelFiltres.add(this.txtRecherche);
        panelFiltres.add(this.btRechercher);

        // Configuration du tableau
        String[] entetes = {"ID", "Référence", "Modèle", "Année", "Kilométrage", "Prix Vente", "Prix Location/Jour"};
        Object[][] donnees = this.getDonnees();
        this.tableVehicules = new JTable(donnees, entetes);
        this.scrollTable = new JScrollPane(this.tableVehicules);
        this.scrollTable.setBounds(10, 60, 700, 580);

        // Masquer la colonne ID
        this.tableVehicules.getColumnModel().getColumn(0).setMinWidth(0);
        this.tableVehicules.getColumnModel().getColumn(0).setMaxWidth(0);
        this.tableVehicules.getColumnModel().getColumn(0).setWidth(0);

        // Configuration du renderer de cellules pour mettre en évidence les véhicules non disponibles
        this.tableVehicules.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, 
                                                          boolean isSelected, boolean hasFocus, 
                                                          int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                
                // Récupérer le modèle du tableau
                int modelRow = table.convertRowIndexToModel(row);
                
                // Récupérer le véhicule correspondant à cette ligne
                if (modelRow >= 0 && modelRow < table.getModel().getRowCount()) {
                    int vehiculeId = (Integer) table.getModel().getValueAt(modelRow, 0);
                    Vehicule vehicule = VehiculeControleur.getVehiculeById(vehiculeId);
                    
                    if (vehicule != null && !vehicule.isDisponible()) {
                        // Si le véhicule n'est pas disponible, utiliser une couleur différente
                        if (!isSelected) {
                            c.setBackground(new Color(255, 200, 200)); // Rouge clair
                        } else {
                            c.setBackground(new Color(255, 150, 150)); // Rouge plus foncé pour la sélection
                        }
                        
                        // Mettre le texte en italique
                        Font originalFont = c.getFont();
                        c.setFont(new Font(originalFont.getName(), Font.ITALIC, originalFont.getSize()));
                    } else {
                        // Couleurs normales pour les véhicules disponibles
                        if (!isSelected) {
                            c.setBackground(row % 2 == 0 ? new Color(240, 240, 255) : Color.WHITE);
                        } else {
                            c.setBackground(new Color(51, 122, 183));
                        }
                        
                        // Police normale
                        Font originalFont = c.getFont();
                        c.setFont(new Font(originalFont.getName(), Font.PLAIN, originalFont.getSize()));
                    }
                }
                
                return c;
            }
        });

        // Configuration du panel de détail
        this.panelDetail.setBounds(720, 60, 470, 580);
        this.panelDetail.setLayout(null);
        this.panelDetail.setBorder(BorderFactory.createTitledBorder("Détail du véhicule"));

        this.lbImage.setBounds(10, 20, 450, 300);
        this.lbModele.setBounds(10, 330, 450, 30);
        this.lbPrix.setBounds(10, 370, 450, 30);
        
        // Configuration du label de non-disponibilité
        this.lbNonDisponible.setFont(new Font("Arial", Font.BOLD, 16));
        this.lbNonDisponible.setForeground(Color.RED);
        this.lbNonDisponible.setBounds(10, 270, 450, 30);
        this.lbNonDisponible.setVisible(false);
        this.panelDetail.add(this.lbNonDisponible);
        
        JPanel panelActions = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 5));
        panelActions.setBounds(10, 420, 450, 40);
        panelActions.add(this.btAcheter);
        panelActions.add(this.btLouer);

        this.panelDetail.add(this.lbImage);
        this.panelDetail.add(this.lbModele);
        this.panelDetail.add(this.lbPrix);
        this.panelDetail.add(panelActions);

        // Ajout des composants au panel principal
        this.add(panelFiltres);
        this.add(this.scrollTable);
        this.add(this.panelDetail);

        // Ajout des écouteurs
        this.cbCategories.addActionListener(this);
        this.btRechercher.addActionListener(this);
        this.btAcheter.addActionListener(this);
        this.btLouer.addActionListener(this);

        // Écouteur pour la sélection dans le tableau
        this.tableVehicules.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                this.afficherDetail();
            }
        });
    }

    private Object[][] getDonnees() {
        ArrayList<Vehicule> lesVehicules = VehiculeControleur.selectAllVehicules();
        Object[][] matrice = new Object[lesVehicules.size()][7];
        int i = 0;
        for(Vehicule v : lesVehicules) {
            matrice[i][0] = v.getId();
            matrice[i][1] = v.getReference();
            matrice[i][2] = v.getModele();
            matrice[i][3] = v.getAnnee();
            matrice[i][4] = v.getKilometrage();
            matrice[i][5] = v.getPrixVente();
            matrice[i][6] = v.getPrixLocationJour();
            i++;
        }
        return matrice;
    }

    private void afficherDetail() {
        int ligne = this.tableVehicules.getSelectedRow();
        if(ligne != -1) {
            int vehiculeId = (Integer) this.tableVehicules.getValueAt(ligne, 0);
            Vehicule vehicule = VehiculeControleur.getVehiculeById(vehiculeId);
            
            if (vehicule != null) {
                String reference = vehicule.getReference();
                String modele = vehicule.getModele();
                String prix = vehicule.getPrixVente().toString();
                
                // Dans un cas réel, charger l'image depuis la base de données ou un dossier
                this.lbImage.setText("Image du véhicule: " + reference);
                this.lbModele.setText("Modèle : " + modele);
                this.lbPrix.setText("Prix : " + prix + " €");
                
                // Indiquer la disponibilité
                if (!vehicule.isDisponible()) {
                    this.lbImage.setBorder(BorderFactory.createLineBorder(Color.RED, 2));
                    this.lbNonDisponible.setVisible(true);
                    
                    // Désactiver les boutons d'action
                    this.btAcheter.setEnabled(false);
                    this.btLouer.setEnabled(false);
                } else {
                    this.lbImage.setBorder(BorderFactory.createLineBorder(Color.GRAY));
                    this.lbNonDisponible.setVisible(false);
                    
                    // Activer les boutons d'action
                    this.btAcheter.setEnabled(true);
                    this.btLouer.setEnabled(true);
                }
                
                // Rafraîchir l'affichage
                this.panelDetail.revalidate();
                this.panelDetail.repaint();
            }
        }
    }

    public void rafraichirTableau() {
        // Récupérer les données à jour
        Object[][] donnees = this.getDonnees();
        
        // Mettre à jour le modèle du tableau
        String[] entetes = {"ID", "Référence", "Modèle", "Année", "Kilométrage", "Prix Vente", "Prix Location/Jour"};
        this.tableVehicules.setModel(new DefaultTableModel(donnees, entetes));
        
        // Masquer la colonne ID
        this.tableVehicules.getColumnModel().getColumn(0).setMinWidth(0);
        this.tableVehicules.getColumnModel().getColumn(0).setMaxWidth(0);
        this.tableVehicules.getColumnModel().getColumn(0).setWidth(0);
        
        // Si une ligne était sélectionnée, essayer de la maintenir sélectionnée
        if (this.tableVehicules.getSelectedRow() != -1) {
            this.afficherDetail();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == this.cbCategories) {
            // Filtrer les véhicules par catégorie
            this.actualiserTableau();
        }
        else if(e.getSource() == this.btRechercher) {
            // Rechercher les véhicules
            this.actualiserTableau();
        }
        else if(e.getSource() == this.btAcheter) {
            this.ajouterAuPanier("ACHAT");
        }
        else if(e.getSource() == this.btLouer) {
            this.ajouterAuPanier("LOCATION");
        }
    }

    private void actualiserTableau() {
        String categorie = this.cbCategories.getSelectedItem().toString();
        String recherche = this.txtRecherche.getText().toLowerCase();
        
        // Récupérer les données filtrées
        Object[][] donneesFiltrees = getDonneesFiltrees(categorie, recherche);
        
        // Mettre à jour le modèle du tableau
        String[] entetes = {"ID", "Référence", "Modèle", "Année", "Kilométrage", "Prix Vente", "Prix Location/Jour"};
        this.tableVehicules.setModel(new DefaultTableModel(donneesFiltrees, entetes));
        
        // Masquer la colonne ID
        this.tableVehicules.getColumnModel().getColumn(0).setMinWidth(0);
        this.tableVehicules.getColumnModel().getColumn(0).setMaxWidth(0);
        this.tableVehicules.getColumnModel().getColumn(0).setWidth(0);
    }

    private Object[][] getDonneesFiltrees(String categorie, String recherche) {
        ArrayList<Vehicule> lesVehicules;
        
        // Filtrer par catégorie
        if(categorie.equals("Toutes")) {
            lesVehicules = VehiculeControleur.selectAllVehicules();
        } else {
            // Récupérer l'ID de la catégorie en fonction de son nom
            int categorieId = 0;
            if(categorie.equals("Citadines")) categorieId = 1;
            if(categorie.equals("Berlines")) categorieId = 2;
            
            lesVehicules = VehiculeControleur.selectByCategorie(categorieId);
        }
        
        // Filtrer par recherche si nécessaire
        if(!recherche.isEmpty()) {
            ArrayList<Vehicule> vehiculesFiltres = new ArrayList<>();
            for(Vehicule v : lesVehicules) {
                if(v.getModele().toLowerCase().contains(recherche) || 
                   v.getReference().toLowerCase().contains(recherche)) {
                    vehiculesFiltres.add(v);
                }
            }
            lesVehicules = vehiculesFiltres;
        }
        
        // Convertir en tableau pour le modèle
        Object[][] matrice = new Object[lesVehicules.size()][7];
        int i = 0;
        for(Vehicule v : lesVehicules) {
            matrice[i][0] = v.getId();
            matrice[i][1] = v.getReference();
            matrice[i][2] = v.getModele();
            matrice[i][3] = v.getAnnee();
            matrice[i][4] = v.getKilometrage();
            matrice[i][5] = v.getPrixVente();
            matrice[i][6] = v.getPrixLocationJour();
            i++;
        }
        
        return matrice;
    }

    private void ajouterAuPanier(String type) {
        int ligne = this.tableVehicules.getSelectedRow();
        if(ligne != -1) {
            // Récupérer l'ID du véhicule
            int vehiculeId = (Integer) this.tableVehicules.getValueAt(ligne, 0);
            
            // Vérifier la disponibilité du véhicule
            Vehicule vehicule = VehiculeControleur.getVehiculeById(vehiculeId);
            if (vehicule != null) {
                // Si c'est une location ou un achat, vérifier la disponibilité
                if ((type.equals("LOCATION") && !vehicule.isDisponible()) || 
                    (type.equals("ACHAT") && !vehicule.isDisponible())) {
                    JOptionPane.showMessageDialog(this,
                        "Ce véhicule n'est plus disponible " + 
                        (type.equals("LOCATION") ? "à la location" : "à l'achat") + ".",
                        "Véhicule non disponible",
                        JOptionPane.WARNING_MESSAGE);
                    return;
                }
                
                // Si on arrive ici, le véhicule est disponible, continuer le processus
                String message = type.equals("ACHAT") ? 
                    "Voulez-vous ajouter ce véhicule à votre panier d'achat ?" :
                    "Voulez-vous ajouter ce véhicule à votre panier de location ?";
                
                int choix = JOptionPane.showConfirmDialog(this,
                    message,
                    "Confirmation",
                    JOptionPane.YES_NO_OPTION);
                    
                if(choix == JOptionPane.YES_OPTION) {
                    // Créer l'objet Panier
                    Panier panier;
                    if(type.equals("ACHAT")) {
                        panier = new Panier(
                            this.utilisateurConnecte.getId(),
                            vehiculeId
                        );
                    } else {
                        // Pour une location, demander les dates
                        panier = demanderDatesLocation(vehiculeId);
                        if(panier == null) {
                            return; // L'utilisateur a annulé
                        }
                    }
                    
                    // Ajouter au panier via le contrôleur
                    if(PanierControleur.ajouterAuPanier(panier)) {
                        JOptionPane.showMessageDialog(this,
                            "Véhicule ajouté au panier avec succès !",
                            "Succès",
                            JOptionPane.INFORMATION_MESSAGE);
                            
                        // Rafraîchir le panier s'il est visible
                        if(this.parent != null) {
                            this.parent.rafraichirPanier();
                        }
                    } else {
                        JOptionPane.showMessageDialog(this,
                            "Erreur lors de l'ajout au panier",
                            "Erreur",
                            JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this,
                    "Impossible de récupérer les informations du véhicule.",
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this,
                "Veuillez sélectionner un véhicule",
                "Erreur",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private Panier demanderDatesLocation(int vehiculeId) {
        // Créer un dialogue pour sélectionner les dates
        JDialog dialog = new JDialog((Frame)SwingUtilities.getWindowAncestor(this), "Sélectionner les dates", true);
        dialog.setLayout(new GridLayout(3, 2, 10, 10));
        dialog.setSize(400, 200);
        dialog.setLocationRelativeTo(this);
        
        // Composants pour la sélection de dates
        JLabel lbDateDebut = new JLabel("Date de début :");
        com.toedter.calendar.JDateChooser dateDebut = new com.toedter.calendar.JDateChooser();
        dateDebut.setDate(new java.util.Date()); // Date du jour
        
        JLabel lbDateFin = new JLabel("Date de fin :");
        com.toedter.calendar.JDateChooser dateFin = new com.toedter.calendar.JDateChooser();
        
        JButton btValider = new JButton("Valider");
        JButton btAnnuler = new JButton("Annuler");
        
        dialog.add(lbDateDebut);
        dialog.add(dateDebut);
        dialog.add(lbDateFin);
        dialog.add(dateFin);
        dialog.add(btAnnuler);
        dialog.add(btValider);
        
        // Variable pour stocker le résultat
        final Panier[] resultat = new Panier[1];
        resultat[0] = null;
        
        // Écouteurs
        btValider.addActionListener(e -> {
            if (dateDebut.getDate() == null || dateFin.getDate() == null) {
                JOptionPane.showMessageDialog(dialog, 
                    "Veuillez sélectionner les dates", 
                    "Erreur", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (dateDebut.getDate().after(dateFin.getDate())) {
                JOptionPane.showMessageDialog(dialog, 
                    "La date de début doit être antérieure à la date de fin", 
                    "Erreur", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Vérifier que les dates sont disponibles
            if (!LocationControleur.verifierDisponibilite(vehiculeId, dateDebut.getDate(), dateFin.getDate())) {
                JOptionPane.showMessageDialog(dialog, 
                    "Le véhicule n'est pas disponible pour ces dates", 
                    "Erreur", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Créer l'objet Panier
            resultat[0] = new Panier(
                this.utilisateurConnecte.getId(),
                vehiculeId,
                dateDebut.getDate(),
                dateFin.getDate()
            );
            
            dialog.dispose();
        });
        
        btAnnuler.addActionListener(e -> dialog.dispose());
        
        dialog.setVisible(true);
        
        return resultat[0];
    }
}