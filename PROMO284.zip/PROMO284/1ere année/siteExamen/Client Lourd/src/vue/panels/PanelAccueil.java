package vue.panels;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import modele.entites.Vehicule;
import controleur.VehiculeControleur;

public class PanelAccueil extends JPanel {
//    private JPanel panelNouveautes;
    private JPanel panelPromotions;
    private ArrayList<VehiculeCard> cardsNouveautes;
    private ArrayList<VehiculeCard> cardsPromotions;

    public PanelAccueil() {
        this.setLayout(null);
        this.setBounds(0, 0, 1200, 650);
        
        // En-tête
        JLabel lbBienvenue = new JLabel("Bienvenue sur E-Peugeot");
        lbBienvenue.setFont(new Font("Arial", Font.BOLD, 24));
        lbBienvenue.setBounds(450, 20, 300, 30);
        this.add(lbBienvenue);
        
        // Texte de présentation
        JTextArea txtPresentation = new JTextArea(
            "Découvrez notre sélection de véhicules Peugeot d'occasion. " +
            "Que vous souhaitiez acheter ou louer, nous avons le véhicule qu'il vous faut !"
        );
        txtPresentation.setEditable(false);
        txtPresentation.setLineWrap(true);
        txtPresentation.setWrapStyleWord(true);
        txtPresentation.setOpaque(false);
        txtPresentation.setFont(new Font("Arial", Font.PLAIN, 14));
        txtPresentation.setBounds(200, 60, 800, 40);
        this.add(txtPresentation);

        // Section Nouveautés
//        JLabel lbNouveautes = new JLabel("Derniers véhicules ajoutés");
//        lbNouveautes.setFont(new Font("Arial", Font.BOLD, 18));
//        lbNouveautes.setBounds(20, 120, 300, 25);
//        this.add(lbNouveautes);

//        this.panelNouveautes = new JPanel();
//        this.panelNouveautes.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 10));
//        this.panelNouveautes.setBounds(20, 150, 1160, 220);
//        this.add(this.panelNouveautes);

        // Section Promotions
        JLabel lbPromotions = new JLabel("Promotions du moment");
        lbPromotions.setFont(new Font("Arial", Font.BOLD, 18));
        lbPromotions.setBounds(20, 390, 300, 25);
        this.add(lbPromotions);

        this.panelPromotions = new JPanel();
        this.panelPromotions.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 10));
        this.panelPromotions.setBounds(20, 420, 1160, 220);
        this.add(this.panelPromotions);

        // Initialisation des cartes
        this.chargerNouveautes();
//        this.chargerPromotions();
    }

    private void chargerNouveautes() {
        ArrayList<Vehicule> nouveautes = VehiculeControleur.getDerniersVehicules(3);
        this.cardsNouveautes = new ArrayList<>();

        for(Vehicule v : nouveautes) {
            VehiculeCard card = new VehiculeCard(v);
            this.cardsNouveautes.add(card);
//            this.panelNouveautes.add(card);
        }
    }

//    private void chargerPromotions() {
//        ArrayList<Vehicule> promotions = VehiculeControleur.getVehiculesEnPromotion(3);
//        this.cardsPromotions = new ArrayList<>();
//
//        for(Vehicule v : promotions) {
//            VehiculeCard card = new VehiculeCard(v);
//            this.cardsPromotions.add(card);
//            this.panelPromotions.add(card);
//        }
//    }

    // Classe interne pour les cartes de véhicules
    private class VehiculeCard extends JPanel {
        private Vehicule vehicule;

        public VehiculeCard(Vehicule vehicule) {
            this.vehicule = vehicule;
            this.setPreferredSize(new Dimension(350, 200));
            this.setLayout(null);
            this.setBorder(BorderFactory.createLineBorder(Color.GRAY));

            // Image du véhicule
            JLabel lbImage = new JLabel();
            lbImage.setBounds(10, 10, 160, 120);
            // TODO: Charger l'image du véhicule
            this.add(lbImage);

            // Informations du véhicule
            JLabel lbModele = new JLabel(vehicule.getModele());
            lbModele.setFont(new Font("Arial", Font.BOLD, 14));
            lbModele.setBounds(180, 10, 160, 20);
            this.add(lbModele);

            JLabel lbAnnee = new JLabel("Année : " + vehicule.getAnnee());
            lbAnnee.setBounds(180, 40, 160, 20);
            this.add(lbAnnee);

            JLabel lbKm = new JLabel("Kilométrage : " + vehicule.getKilometrage() + " km");
            lbKm.setBounds(180, 60, 160, 20);
            this.add(lbKm);

            JLabel lbPrixVente = new JLabel("Prix vente : " + vehicule.getPrixVente() + " €");
            lbPrixVente.setFont(new Font("Arial", Font.BOLD, 14));
            lbPrixVente.setBounds(180, 90, 160, 20);
            this.add(lbPrixVente);

            JLabel lbPrixLocation = new JLabel("Location : " + vehicule.getPrixLocationJour() + " €/jour");
            lbPrixLocation.setBounds(180, 110, 160, 20);
            this.add(lbPrixLocation);

            // Boutons d'action
            JButton btDetails = new JButton("Voir détails");
            btDetails.setBounds(120, 160, 110, 25);
            btDetails.addActionListener(e -> afficherDetails());
            this.add(btDetails);
        }

        private void afficherDetails() {
            // TODO: Ouvrir la vue détaillée du véhicule
        }
    }
}