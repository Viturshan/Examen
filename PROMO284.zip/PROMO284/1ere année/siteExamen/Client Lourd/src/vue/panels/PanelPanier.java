package vue.panels;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.util.ArrayList;

import modele.entites.Utilisateur;
import modele.entites.Panier;
import modele.entites.Vehicule;
import controleur.PanierControleur;
import controleur.VehiculeControleur;
import vue.principal.VueGenerale;

public class PanelPanier extends JPanel implements ActionListener {
    private Utilisateur utilisateur;
    private VueGenerale parent;
    
    private JTabbedPane tabbedPane;
    private JPanel panelAchats;
    private JPanel panelLocations;
    
    private JTable tableAchats;
    private JTable tableLocations;
    private JScrollPane scrollAchats;
    private JScrollPane scrollLocations;
    
    private JLabel lbTotalAchats = new JLabel("Total : 0 €");
    private JLabel lbTotalLocations = new JLabel("Total : 0 €");
    
    private JButton btValiderAchats = new JButton("Valider les achats");
    private JButton btValiderLocations = new JButton("Valider les locations");
    private JButton btSupprimerAchat = new JButton("Supprimer");
    private JButton btSupprimerLocation = new JButton("Supprimer");

    public PanelPanier(VueGenerale parent, Utilisateur utilisateur) {
        this.parent = parent;
        this.utilisateur = utilisateur;
        
        this.setLayout(null);
        this.setBounds(0, 0, 1200, 650);
        
        // Configuration des onglets
        this.tabbedPane = new JTabbedPane();
        this.tabbedPane.setBounds(10, 10, 1180, 630);
        
        // Panel Achats
        this.panelAchats = new JPanel(null);
        String[] entetesAchats = {"ID", "Référence", "Modèle", "Prix"};
        this.tableAchats = new JTable(new Object[0][4], entetesAchats);
        this.scrollAchats = new JScrollPane(this.tableAchats);
        this.scrollAchats.setBounds(10, 10, 1140, 500);
        
        JPanel panelActionsAchats = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelActionsAchats.setBounds(10, 520, 1140, 40);
        panelActionsAchats.add(this.btSupprimerAchat);
        panelActionsAchats.add(this.lbTotalAchats);
        panelActionsAchats.add(this.btValiderAchats);
        
        this.panelAchats.add(this.scrollAchats);
        this.panelAchats.add(panelActionsAchats);
        
        // Panel Locations
        this.panelLocations = new JPanel(null);
        String[] entetesLocations = {"ID", "Référence", "Modèle", "Prix/Jour", "Durée", "Total"};
        this.tableLocations = new JTable(new Object[0][6], entetesLocations);
        this.scrollLocations = new JScrollPane(this.tableLocations);
        this.scrollLocations.setBounds(10, 10, 1140, 500);
        
        JPanel panelActionsLocations = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelActionsLocations.setBounds(10, 520, 1140, 40);
        panelActionsLocations.add(this.btSupprimerLocation);
        panelActionsLocations.add(this.lbTotalLocations);
        panelActionsLocations.add(this.btValiderLocations);
        
        this.panelLocations.add(this.scrollLocations);
        this.panelLocations.add(panelActionsLocations);
        
        // Ajout des onglets
        this.tabbedPane.addTab("Achats", this.panelAchats);
        this.tabbedPane.addTab("Locations", this.panelLocations);
        
        this.add(this.tabbedPane);
        
        // Ajout des écouteurs
        this.btValiderAchats.addActionListener(this);
        this.btValiderLocations.addActionListener(this);
        this.btSupprimerAchat.addActionListener(this);
        this.btSupprimerLocation.addActionListener(this);
        
        // Cacher la colonne ID
        this.tableAchats.getColumnModel().getColumn(0).setMinWidth(0);
        this.tableAchats.getColumnModel().getColumn(0).setMaxWidth(0);
        this.tableAchats.getColumnModel().getColumn(0).setWidth(0);
        
        this.tableLocations.getColumnModel().getColumn(0).setMinWidth(0);
        this.tableLocations.getColumnModel().getColumn(0).setMaxWidth(0);
        this.tableLocations.getColumnModel().getColumn(0).setWidth(0);
        
        // Chargement initial des données
        this.chargerPanier();
    }

    public void chargerPanier() {
        // Récupérer les éléments du panier pour cet utilisateur
        ArrayList<Panier> panierItems = PanierControleur.getPanierUtilisateur(this.utilisateur.getId());
        
        // Préparer les tableaux pour les achats et les locations
        DefaultTableModel modelAchats = new DefaultTableModel(
            new Object[][] {}, 
            new String[] {"ID", "Référence", "Modèle", "Prix"}
        );
        
        DefaultTableModel modelLocations = new DefaultTableModel(
            new Object[][] {}, 
            new String[] {"ID", "Référence", "Modèle", "Prix/Jour", "Durée (jours)", "Total"}
        );
        
        // Variables pour calculer les totaux
        BigDecimal totalAchats = BigDecimal.ZERO;
        BigDecimal totalLocations = BigDecimal.ZERO;
        
        // Remplir les tableaux
        for (Panier item : panierItems) {
            // Charger les informations du véhicule
            Vehicule vehicule = VehiculeControleur.getVehiculeById(item.getVehiculeId());
            
            if (vehicule != null) {
                if (item.isAchat()) {
                    // Ajouter au tableau des achats
                    Object[] row = {
                        item.getId(),
                        vehicule.getReference(),
                        vehicule.getModele(),
                        vehicule.getPrixVente()
                    };
                    modelAchats.addRow(row);
                    
                    // Ajouter au total
                    totalAchats = totalAchats.add(vehicule.getPrixVente());
                } else if (item.isLocation()) {
                    // Calculer la durée et le total
                    int duree = item.getDureeLocation();
                    BigDecimal total = vehicule.getPrixLocationJour().multiply(new BigDecimal(duree));
                    
                    // Ajouter au tableau des locations
                    Object[] row = {
                        item.getId(),
                        vehicule.getReference(),
                        vehicule.getModele(),
                        vehicule.getPrixLocationJour(),
                        duree,
                        total
                    };
                    modelLocations.addRow(row);
                    
                    // Ajouter au total
                    totalLocations = totalLocations.add(total);
                }
            }
        }
        
        // Mettre à jour les tableaux
        this.tableAchats.setModel(modelAchats);
        this.tableLocations.setModel(modelLocations);
        
        // Cacher la colonne ID
        this.tableAchats.getColumnModel().getColumn(0).setMinWidth(0);
        this.tableAchats.getColumnModel().getColumn(0).setMaxWidth(0);
        this.tableAchats.getColumnModel().getColumn(0).setWidth(0);
        
        this.tableLocations.getColumnModel().getColumn(0).setMinWidth(0);
        this.tableLocations.getColumnModel().getColumn(0).setMaxWidth(0);
        this.tableLocations.getColumnModel().getColumn(0).setWidth(0);
        
        // Mettre à jour les totaux
        this.lbTotalAchats.setText("Total : " + totalAchats + " €");
        this.lbTotalLocations.setText("Total : " + totalLocations + " €");
        
        // Activer/désactiver les boutons selon qu'il y a des éléments dans le panier
        this.btValiderAchats.setEnabled(modelAchats.getRowCount() > 0);
        this.btValiderLocations.setEnabled(modelLocations.getRowCount() > 0);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == this.btValiderAchats) {
            this.validerAchats();
        }
        else if(e.getSource() == this.btValiderLocations) {
            this.validerLocations();
        }
        else if(e.getSource() == this.btSupprimerAchat) {
            this.supprimerSelection("ACHAT");
        }
        else if(e.getSource() == this.btSupprimerLocation) {
            this.supprimerSelection("LOCATION");
        }
    }

    private void validerAchats() {
        if(this.tableAchats.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this,
                "Votre panier d'achats est vide",
                "Information",
                JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        int choix = JOptionPane.showConfirmDialog(this,
            "Voulez-vous valider vos achats pour un total de " + this.lbTotalAchats.getText() + " ?",
            "Confirmation d'achat",
            JOptionPane.YES_NO_OPTION);
            
        if(choix == JOptionPane.YES_OPTION) {
            // Processus de paiement
            if(this.processPayment()) {
                // Récupérer les IDs des articles du panier
                ArrayList<Integer> itemsId = new ArrayList<>();
                for(int i = 0; i < this.tableAchats.getRowCount(); i++) {
                    itemsId.add((Integer)this.tableAchats.getValueAt(i, 0));
                }
                
                // Créer les ventes correspondantes et vider le panier
                if(PanierControleur.validerAchats(itemsId, this.utilisateur.getId())) {
                    JOptionPane.showMessageDialog(this,
                        "Vos achats ont été validés avec succès !",
                        "Succès",
                        JOptionPane.INFORMATION_MESSAGE);
                    this.chargerPanier();
                    
                    // Rafraîchir le panneau compte
                    if(this.parent != null) {
                        this.parent.rafraichirCompte();
                    }
                } else {
                    JOptionPane.showMessageDialog(this,
                        "Erreur lors de la validation des achats",
                        "Erreur",
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    private void validerLocations() {
        System.out.println("Début validerLocations()");
        
        if(this.tableLocations.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this,
                "Votre panier de locations est vide",
                "Information",
                JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        int choix = JOptionPane.showConfirmDialog(this,
            "Voulez-vous valider vos locations pour un total de " + this.lbTotalLocations.getText() + " ?",
            "Confirmation de location",
            JOptionPane.YES_NO_OPTION);
            
        if(choix == JOptionPane.YES_OPTION) {
            System.out.println("Utilisateur a confirmé la validation");
            
            // Processus de paiement
            boolean paiementReussi = this.processPayment();
            System.out.println("Résultat du paiement : " + paiementReussi);
            
            if(paiementReussi) {
                // Récupérer les IDs des articles du panier
                ArrayList<Integer> itemsId = new ArrayList<>();
                for(int i = 0; i < this.tableLocations.getRowCount(); i++) {
                    int id = (Integer)this.tableLocations.getValueAt(i, 0);
                    itemsId.add(id);
                    System.out.println("Ajout de l'ID " + id + " à la liste d'articles à valider");
                }
                
                System.out.println("Appel de PanierControleur.validerLocations()");
                // Créer les locations correspondantes et vider le panier
                if(PanierControleur.validerLocations(itemsId, this.utilisateur.getId())) {
                    JOptionPane.showMessageDialog(this,
                        "Vos locations ont été validées avec succès !",
                        "Succès",
                        JOptionPane.INFORMATION_MESSAGE);
                    this.chargerPanier();
                    
                    // Rafraîchir le panneau compte
                    if(this.parent != null) {
                        this.parent.rafraichirCompte();
                    }
                    
                    System.out.println("Locations validées avec succès");
                } else {
                    JOptionPane.showMessageDialog(this,
                        "Erreur lors de la validation des locations",
                        "Erreur",
                        JOptionPane.ERROR_MESSAGE);
                    System.out.println("Erreur lors de la validation des locations");
                }
            }
        }
    }

    private void supprimerSelection(String type) {
        JTable table = type.equals("ACHAT") ? this.tableAchats : this.tableLocations;
        int ligne = table.getSelectedRow();
        
        if(ligne == -1) {
            JOptionPane.showMessageDialog(this,
                "Veuillez sélectionner un élément à supprimer",
                "Erreur",
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        int id = (Integer)table.getValueAt(ligne, 0);
        int choix = JOptionPane.showConfirmDialog(this,
            "Voulez-vous supprimer cet élément de votre panier ?",
            "Confirmation de suppression",
            JOptionPane.YES_NO_OPTION);
            
        if(choix == JOptionPane.YES_OPTION) {
            if(PanierControleur.supprimerDuPanier(id)) {
                JOptionPane.showMessageDialog(this,
                    "Article supprimé du panier avec succès !",
                    "Succès",
                    JOptionPane.INFORMATION_MESSAGE);
                this.chargerPanier();
            } else {
                JOptionPane.showMessageDialog(this,
                    "Erreur lors de la suppression de l'article",
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private boolean processPayment() {
        // Simuler un processus de paiement simple
        JDialog loadingDialog = new JDialog((Frame)SwingUtilities.getWindowAncestor(this), "Traitement du paiement", true);
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JProgressBar progressBar = new JProgressBar();
        progressBar.setIndeterminate(true);
        JLabel label = new JLabel("Traitement du paiement en cours...");
        
        panel.add(label, BorderLayout.NORTH);
        panel.add(progressBar, BorderLayout.CENTER);
        
        loadingDialog.add(panel);
        loadingDialog.setSize(300, 100);
        loadingDialog.setLocationRelativeTo(this);
        
        // Créer un timer pour fermer la boîte de dialogue après 2 secondes
        Timer timer = new Timer(2000, (e) -> {
            loadingDialog.dispose();
        });
        timer.setRepeats(false);
        timer.start();
        
        loadingDialog.setVisible(true); // Ceci bloque jusqu'à ce que le dialogue soit fermé
        
        return true; // Simuler un paiement réussi
    }
}