package vue.panels;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import modele.entites.Vehicule;
import modele.entites.Location;
import modele.entites.Vente;
import controleur.VehiculeControleur;
import controleur.LocationControleur;
import controleur.VenteControleur;
import vue.principal.VueGenerale;

public class PanelAdmin extends JPanel implements ActionListener {
    private VueGenerale parent;
    private JTabbedPane tabbedPane;
    private JPanel panelGestionVehicules;
    private JPanel panelGestionDonnees;
    
    // Composants pour l'ajout de véhicule
    private JTextField txtMarque,txtReference, txtModele, txtDescription, txtAnnee, txtKilometrage, txtPrixVente, txtPrixLocation;
    private JComboBox<String> cbCategories;
    private JButton btAjouter, btEffacer;
    
    // Composants pour la gestion des données
    private JTabbedPane tabbedPaneDonnees;
    private JTable tableLocations;
    private JTable tableVentes;
    private JScrollPane scrollLocations;
    private JScrollPane scrollVentes;
    private JButton btSupprimerLocation;
    private JButton btSupprimerVente;
    
    public PanelAdmin(VueGenerale parent) {
        this.parent = parent;
        this.setLayout(null);
        this.setBounds(0, 0, 1200, 650);
        
        // Initialisation des onglets
        this.tabbedPane = new JTabbedPane();
        this.tabbedPane.setBounds(10, 10, 1180, 630);
        
        // Configuration du panel Gestion des véhicules
        this.initPanelGestionVehicules();
        
        // Configuration du panel Gestion des données
        this.initPanelGestionDonnees();
        
        // Ajout des onglets
        this.tabbedPane.addTab("Gestion des véhicules", this.panelGestionVehicules);
        this.tabbedPane.addTab("Gestion des données", this.panelGestionDonnees);
        
        this.add(this.tabbedPane);
    }
    
    private void initPanelGestionVehicules() {
        this.panelGestionVehicules = new JPanel(null);
        
        // Formulaire d'ajout de véhicule
        JPanel panelFormulaire = new JPanel(new GridLayout(8, 2, 10, 10));
        panelFormulaire.setBounds(50, 50, 500, 300);
        panelFormulaire.setBorder(BorderFactory.createTitledBorder("Ajouter un véhicule"));
        
        // Initialisation des composants
        JLabel lbMarque = new JLabel("Marque :"); 	
        this.txtMarque = new JTextField();

        JLabel lbReference = new JLabel("Référence :");
        this.txtReference = new JTextField();
        
        JLabel lbModele = new JLabel("Modèle :");
        this.txtModele = new JTextField();
        
        JLabel lbDescription = new JLabel("Description :");
        this.txtDescription = new JTextField();
        
        JLabel lbAnnee = new JLabel("Année :");
        this.txtAnnee = new JTextField();
        
        JLabel lbKilometrage = new JLabel("Kilométrage :");
        this.txtKilometrage = new JTextField();
        
        JLabel lbPrixVente = new JLabel("Prix de vente :");
        this.txtPrixVente = new JTextField();
        
        JLabel lbPrixLocation = new JLabel("Prix location/jour :");
        this.txtPrixLocation = new JTextField();
        
        JLabel lbCategorie = new JLabel("Catégorie :");
        this.cbCategories = new JComboBox<>(new String[]{"Citadines", "Berlines"});
        
        // Ajout des composants au formulaire
        panelFormulaire.add(lbMarque);
        panelFormulaire.add(this.lbMarque);
        panelFormulaire.add(lbReference);
        panelFormulaire.add(this.txtReference);
        panelFormulaire.add(lbModele);
        panelFormulaire.add(this.txtModele);
        panelFormulaire.add(lbDescription);
        panelFormulaire.add(this.txtDescription);
        panelFormulaire.add(lbAnnee);
        panelFormulaire.add(this.txtAnnee);
        panelFormulaire.add(lbKilometrage);
        panelFormulaire.add(this.txtKilometrage);
        panelFormulaire.add(lbPrixVente);
        panelFormulaire.add(this.txtPrixVente);
        panelFormulaire.add(lbPrixLocation);
        panelFormulaire.add(this.txtPrixLocation);
        panelFormulaire.add(lbCategorie);
        panelFormulaire.add(this.cbCategories);
        
        // Boutons d'action
        JPanel panelBoutons = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        panelBoutons.setBounds(50, 380, 500, 40);
        
        this.btAjouter = new JButton("Ajouter");
        this.btEffacer = new JButton("Effacer");
        
        panelBoutons.add(this.btAjouter);
        panelBoutons.add(this.btEffacer);
        
        // Ajout des panels au panel principal
        this.panelGestionVehicules.add(panelFormulaire);
        this.panelGestionVehicules.add(panelBoutons);
        
        // Ajout des écouteurs
        this.btAjouter.addActionListener(this);
        this.btEffacer.addActionListener(this);
    }
    
    private void initPanelGestionDonnees() {
        this.panelGestionDonnees = new JPanel(null);
        
        // Initialisation de l'onglet pour gérer les locations et ventes
        this.tabbedPaneDonnees = new JTabbedPane();
        this.tabbedPaneDonnees.setBounds(10, 10, 1150, 580);
        
        // Panel Locations
        JPanel panelLocations = new JPanel(null);
        
        // Tableau des locations
        String[] entetesLocations = {"ID", "Client", "Véhicule", "Date début", "Date fin", "Prix total", "Statut"};
        this.tableLocations = new JTable(this.getDonneesLocations(), entetesLocations);
        this.scrollLocations = new JScrollPane(this.tableLocations);
        this.scrollLocations.setBounds(10, 10, 1120, 480);
        
        // Bouton pour supprimer une location
        this.btSupprimerLocation = new JButton("Supprimer la location sélectionnée");
        this.btSupprimerLocation.setBounds(450, 500, 250, 30);
        this.btSupprimerLocation.addActionListener(this);
        
        panelLocations.add(this.scrollLocations);
        panelLocations.add(this.btSupprimerLocation);
        
        // Panel Ventes
        JPanel panelVentes = new JPanel(null);
        
        // Tableau des ventes
        String[] entetesVentes = {"ID", "Client", "Véhicule", "Date", "Prix", "Statut"};
        this.tableVentes = new JTable(this.getDonneesVentes(), entetesVentes);
        this.scrollVentes = new JScrollPane(this.tableVentes);
        this.scrollVentes.setBounds(10, 10, 1120, 480);
        
        // Bouton pour supprimer une vente
        this.btSupprimerVente = new JButton("Supprimer la vente sélectionnée");
        this.btSupprimerVente.setBounds(450, 500, 250, 30);
        this.btSupprimerVente.addActionListener(this);
        
        panelVentes.add(this.scrollVentes);
        panelVentes.add(this.btSupprimerVente);
        
        // Ajout des onglets
        this.tabbedPaneDonnees.addTab("Locations", panelLocations);
        this.tabbedPaneDonnees.addTab("Ventes", panelVentes);
        
        this.panelGestionDonnees.add(this.tabbedPaneDonnees);
        
        // Masquer les colonnes ID
        this.tableLocations.getColumnModel().getColumn(0).setMinWidth(0);
        this.tableLocations.getColumnModel().getColumn(0).setMaxWidth(0);
        this.tableLocations.getColumnModel().getColumn(0).setWidth(0);
        
        this.tableVentes.getColumnModel().getColumn(0).setMinWidth(0);
        this.tableVentes.getColumnModel().getColumn(0).setMaxWidth(0);
        this.tableVentes.getColumnModel().getColumn(0).setWidth(0);
    }
    
    private Object[][] getDonneesLocations() {
        ArrayList<Location> locations = LocationControleur.getAllLocations();
        Object[][] donnees = new Object[locations.size()][7];
        
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        int i = 0;
        for (Location location : locations) {
            donnees[i][0] = location.getId();
            donnees[i][1] = location.getNomUtilisateur();
            donnees[i][2] = location.getModeleVehicule();
            donnees[i][3] = sdf.format(location.getDateDebut());
            donnees[i][4] = sdf.format(location.getDateFin());
            donnees[i][5] = location.getPrixTotal() + " €";
            donnees[i][6] = location.getStatut();
            i++;
        }
        
        return donnees;
    }
    
    private Object[][] getDonneesVentes() {
        ArrayList<Vente> ventes = VenteControleur.getAllVentes();
        Object[][] donnees = new Object[ventes.size()][6];
        
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        int i = 0;
        for (Vente vente : ventes) {
            donnees[i][0] = vente.getId();
            donnees[i][1] = vente.getNomUtilisateur();
            donnees[i][2] = vente.getModeleVehicule();
            donnees[i][3] = sdf.format(vente.getDateVente());
            donnees[i][4] = vente.getPrixVente() + " €";
            donnees[i][5] = vente.getStatut();
            i++;
        }
        
        return donnees;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == this.btAjouter) {
            this.ajouterVehicule();
        }
        else if(e.getSource() == this.btEffacer) {
            this.effacerFormulaire();
        }
        else if(e.getSource() == this.btSupprimerLocation) {
            this.supprimerLocation();
        }
        else if(e.getSource() == this.btSupprimerVente) {
            this.supprimerVente();
        }
    }
    
    private void supprimerLocation() {
        int ligne = this.tableLocations.getSelectedRow();
        if(ligne == -1) {
            JOptionPane.showMessageDialog(this,
                "Veuillez sélectionner une location à supprimer",
                "Erreur",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int id = (Integer) this.tableLocations.getValueAt(ligne, 0);
        int choix = JOptionPane.showConfirmDialog(this,
            "Voulez-vous vraiment supprimer cette location ?\nCette action est irréversible.",
            "Confirmation de suppression",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if(choix == JOptionPane.YES_OPTION) {
            if(LocationControleur.supprimerLocation(id)) {
                JOptionPane.showMessageDialog(this,
                    "Location supprimée avec succès !",
                    "Succès",
                    JOptionPane.INFORMATION_MESSAGE);
                
                // Rafraîchir les tableaux
                this.rafraichirTableaux();
                
                // Rafraîchir la liste des véhicules
                if(this.parent != null) {
                    this.parent.getPanelVehicules().rafraichirTableau();
                }
            } else {
                JOptionPane.showMessageDialog(this,
                    "Erreur lors de la suppression de la location",
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void supprimerVente() {
        int ligne = this.tableVentes.getSelectedRow();
        if(ligne == -1) {
            JOptionPane.showMessageDialog(this,
                "Veuillez sélectionner une vente à supprimer",
                "Erreur",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int id = (Integer) this.tableVentes.getValueAt(ligne, 0);
        int choix = JOptionPane.showConfirmDialog(this,
            "Voulez-vous vraiment supprimer cette vente ?\nCette action est irréversible.",
            "Confirmation de suppression",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if(choix == JOptionPane.YES_OPTION) {
            if(VenteControleur.supprimerVente(id)) {
                JOptionPane.showMessageDialog(this,
                    "Vente supprimée avec succès !",
                    "Succès",
                    JOptionPane.INFORMATION_MESSAGE);
                
                // Rafraîchir les tableaux
                this.rafraichirTableaux();
                
                // Rafraîchir la liste des véhicules
                if(this.parent != null) {
                    this.parent.getPanelVehicules().rafraichirTableau();
                }
            } else {
                JOptionPane.showMessageDialog(this,
                    "Erreur lors de la suppression de la vente",
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void rafraichirTableaux() {
        // Mettre à jour les tableaux
        String[] entetesLocations = {"ID", "Client", "Véhicule", "Date début", "Date fin", "Prix total", "Statut"};
        this.tableLocations.setModel(new DefaultTableModel(this.getDonneesLocations(), entetesLocations));
        
        String[] entetesVentes = {"ID", "Client", "Véhicule", "Date", "Prix", "Statut"};
        this.tableVentes.setModel(new DefaultTableModel(this.getDonneesVentes(), entetesVentes));
        
        // Masquer les colonnes ID
        this.tableLocations.getColumnModel().getColumn(0).setMinWidth(0);
        this.tableLocations.getColumnModel().getColumn(0).setMaxWidth(0);
        this.tableLocations.getColumnModel().getColumn(0).setWidth(0);
        
        this.tableVentes.getColumnModel().getColumn(0).setMinWidth(0);
        this.tableVentes.getColumnModel().getColumn(0).setMaxWidth(0);
        this.tableVentes.getColumnModel().getColumn(0).setWidth(0);
        
        // Ajouter un listener de sélection pour activer/désactiver les boutons
        this.tableLocations.getSelectionModel().addListSelectionListener(e -> {
            this.btSupprimerLocation.setEnabled(this.tableLocations.getSelectedRow() != -1);
        });
        
        this.tableVentes.getSelectionModel().addListSelectionListener(e -> {
            this.btSupprimerVente.setEnabled(this.tableVentes.getSelectedRow() != -1);
        });
    }
    
    private void ajouterVehicule() {
        // Validation des champs
        if(this.txtReference.getText().isEmpty() || 
           this.txtModele.getText().isEmpty() || 
           this.txtAnnee.getText().isEmpty() || 
           this.txtKilometrage.getText().isEmpty() || 
           this.txtPrixVente.getText().isEmpty() || 
           this.txtPrixLocation.getText().isEmpty()) {
            
            JOptionPane.showMessageDialog(this,
                "Veuillez remplir tous les champs obligatoires",
                "Erreur",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        try {
            // Récupération des valeurs
            String reference = this.txtReference.getText();
            String modele = this.txtModele.getText();
            String description = this.txtDescription.getText();
            int annee = Integer.parseInt(this.txtAnnee.getText());
            int kilometrage = Integer.parseInt(this.txtKilometrage.getText());
            BigDecimal prixVente = new BigDecimal(this.txtPrixVente.getText().replace(',', '.'));
            BigDecimal prixLocation = new BigDecimal(this.txtPrixLocation.getText().replace(',', '.'));
            int categorieId = this.cbCategories.getSelectedIndex() + 1; // +1 car les IDs commencent à 1
            
            // Affichage des valeurs pour debug
            System.out.println("Ajout véhicule - Référence: " + reference);
            System.out.println("Ajout véhicule - Modèle: " + modele);
            System.out.println("Ajout véhicule - Année: " + annee);
            System.out.println("Ajout véhicule - Kilométrage: " + kilometrage);
            System.out.println("Ajout véhicule - Prix vente: " + prixVente);
            System.out.println("Ajout véhicule - Prix location: " + prixLocation);
            System.out.println("Ajout véhicule - Catégorie ID: " + categorieId);
            
            // Création du véhicule
            Vehicule vehicule = new Vehicule(
                reference, modele, description, annee, 
                kilometrage, prixVente, prixLocation, categorieId
            );
            
            // Ajout à la base de données
            if(VehiculeControleur.insertVehicule(vehicule)) {
                JOptionPane.showMessageDialog(this,
                    "Véhicule ajouté avec succès !",
                    "Succès",
                    JOptionPane.INFORMATION_MESSAGE);
                this.effacerFormulaire();
                
                // Rafraîchir le tableau des véhicules
                if (this.parent != null) {
                    this.parent.getPanelVehicules().rafraichirTableau();
                }
            } else {
                JOptionPane.showMessageDialog(this,
                    "Erreur lors de l'ajout du véhicule. Vérifiez la console pour plus de détails.",
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
            }
            
        } catch(NumberFormatException e) {
            JOptionPane.showMessageDialog(this,
                "Veuillez saisir des valeurs numériques valides pour l'année, le kilométrage et les prix.\nErreur: " + e.getMessage(),
                "Erreur de format",
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    
    private void effacerFormulaire() {
        this.txtReference.setText("");
        this.txtModele.setText("");
        this.txtDescription.setText("");
        this.txtAnnee.setText("");
        this.txtKilometrage.setText("");
        this.txtPrixVente.setText("");
        this.txtPrixLocation.setText("");
        this.cbCategories.setSelectedIndex(0);
    }
}