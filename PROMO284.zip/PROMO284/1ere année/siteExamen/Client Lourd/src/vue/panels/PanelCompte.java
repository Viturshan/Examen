package vue.panels;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import modele.entites.Utilisateur;
import modele.entites.Location;
import modele.entites.Vehicule;
import controleur.UtilisateurControleur;
import controleur.LocationControleur;
import controleur.VehiculeControleur;
import modele.entites.Vente;
import controleur.VenteControleur;

public class PanelCompte extends JPanel implements ActionListener {
    private Utilisateur utilisateur;
    private JTabbedPane tabbedPane;
    
    // Panel Informations Personnelles
    private JPanel panelInfos;
    private JTextField txtNom, txtPrenom, txtEmail, txtTel, txtAdresse;
    private JButton btModifier = new JButton("Modifier");
    private JButton btEnregistrer = new JButton("Enregistrer");
    
    // Panel Historique Locations
    private JPanel panelLocations;
    private JTable tableLocations;
    private JScrollPane scrollLocations;
    
    // Panel Historique Achats
    private JPanel panelAchats;
    private JTable tableAchats;
    private JScrollPane scrollAchats;
    
    // Panel Modification Mot de Passe
    private JPanel panelMdp;
    private JPasswordField txtAncienMdp, txtNouveauMdp, txtConfirmMdp;
    private JButton btChangerMdp = new JButton("Changer le mot de passe");

    public PanelCompte(Utilisateur utilisateur) {
        this.utilisateur = utilisateur;
        
        this.setLayout(null);
        this.setBounds(0, 0, 1200, 650);
        
        // Initialisation des onglets
        this.tabbedPane = new JTabbedPane();
        this.tabbedPane.setBounds(10, 10, 1180, 630);
        
        // Configuration du panel Informations
        this.initPanelInfos();
        
        // Configuration du panel Locations
        this.initPanelLocations();
        
        // Configuration du panel Achats
        this.initPanelAchats();
        
        // Configuration du panel Mot de passe
        this.initPanelMdp();
        
        // Ajout des onglets
        this.tabbedPane.addTab("Informations Personnelles", this.panelInfos);
        this.tabbedPane.addTab("Mes Locations", this.panelLocations);
        this.tabbedPane.addTab("Mes Achats", this.panelAchats);
        this.tabbedPane.addTab("Modifier mot de passe", this.panelMdp);
        
        this.add(this.tabbedPane);
        
        // Ajout des écouteurs
        this.btModifier.addActionListener(this);
        this.btEnregistrer.addActionListener(this);
        this.btChangerMdp.addActionListener(this);
    }
    
    private void initPanelInfos() {
        this.panelInfos = new JPanel(null);
        
        // Création des composants
        JLabel lbNom = new JLabel("Nom :");
        JLabel lbPrenom = new JLabel("Prénom :");
        JLabel lbEmail = new JLabel("Email :");
        JLabel lbTel = new JLabel("Téléphone :");
        JLabel lbAdresse = new JLabel("Adresse :");
        
        this.txtNom = new JTextField(this.utilisateur.getNom());
        this.txtPrenom = new JTextField(this.utilisateur.getPrenom());
        this.txtEmail = new JTextField(this.utilisateur.getEmail());
        this.txtTel = new JTextField(this.utilisateur.getTelephone());
        this.txtAdresse = new JTextField(this.utilisateur.getAdresse());
        
        // Positionnement
        lbNom.setBounds(50, 50, 100, 25);
        this.txtNom.setBounds(160, 50, 200, 25);
        
        lbPrenom.setBounds(50, 90, 100, 25);
        this.txtPrenom.setBounds(160, 90, 200, 25);
        
        lbEmail.setBounds(50, 130, 100, 25);
        this.txtEmail.setBounds(160, 130, 200, 25);
        
        lbTel.setBounds(50, 170, 100, 25);
        this.txtTel.setBounds(160, 170, 200, 25);
        
        lbAdresse.setBounds(50, 210, 100, 25);
        this.txtAdresse.setBounds(160, 210, 400, 25);
        
        this.btModifier.setBounds(160, 260, 100, 25);
        this.btEnregistrer.setBounds(280, 260, 100, 25);
        
        // État initial des champs
        this.setEditable(false);
        this.btEnregistrer.setVisible(false);
        
        // Ajout des composants
        this.panelInfos.add(lbNom);
        this.panelInfos.add(this.txtNom);
        this.panelInfos.add(lbPrenom);
        this.panelInfos.add(this.txtPrenom);
        this.panelInfos.add(lbEmail);
        this.panelInfos.add(this.txtEmail);
        this.panelInfos.add(lbTel);
        this.panelInfos.add(this.txtTel);
        this.panelInfos.add(lbAdresse);
        this.panelInfos.add(this.txtAdresse);
        this.panelInfos.add(this.btModifier);
        this.panelInfos.add(this.btEnregistrer);
    }
    
    private void initPanelLocations() {
        this.panelLocations = new JPanel(null);
        
        // Configuration du tableau
        String[] entetesLocations = {"Date début", "Date fin", "Véhicule", "Prix total", "Statut"};
        Object[][] donneesLocations = this.getDonneesLocations();
        this.tableLocations = new JTable(donneesLocations, entetesLocations);
        this.scrollLocations = new JScrollPane(this.tableLocations);
        this.scrollLocations.setBounds(10, 10, 1150, 580);
        
        this.panelLocations.add(this.scrollLocations);
    }
    
    private void initPanelAchats() {
        this.panelAchats = new JPanel(null);
        
        // Configuration du tableau
        String[] entetesAchats = {"Date", "Véhicule", "Prix", "Statut"};
        Object[][] donneesAchats = this.getDonneesAchats();
        this.tableAchats = new JTable(donneesAchats, entetesAchats);
        this.scrollAchats = new JScrollPane(this.tableAchats);
        this.scrollAchats.setBounds(10, 10, 1150, 580);
        
        this.panelAchats.add(this.scrollAchats);
    }
    
    private void initPanelMdp() {
        this.panelMdp = new JPanel(null);
        
        JLabel lbAncienMdp = new JLabel("Ancien mot de passe :");
        JLabel lbNouveauMdp = new JLabel("Nouveau mot de passe :");
        JLabel lbConfirmMdp = new JLabel("Confirmer mot de passe :");
        
        this.txtAncienMdp = new JPasswordField();
        this.txtNouveauMdp = new JPasswordField();
        this.txtConfirmMdp = new JPasswordField();
        
        lbAncienMdp.setBounds(50, 50, 150, 25);
        this.txtAncienMdp.setBounds(210, 50, 200, 25);
        
        lbNouveauMdp.setBounds(50, 90, 150, 25);
        this.txtNouveauMdp.setBounds(210, 90, 200, 25);
        
        lbConfirmMdp.setBounds(50, 130, 150, 25);
        this.txtConfirmMdp.setBounds(210, 130, 200, 25);
        
        this.btChangerMdp.setBounds(210, 170, 200, 25);
        
        this.panelMdp.add(lbAncienMdp);
        this.panelMdp.add(this.txtAncienMdp);
        this.panelMdp.add(lbNouveauMdp);
        this.panelMdp.add(this.txtNouveauMdp);
        this.panelMdp.add(lbConfirmMdp);
        this.panelMdp.add(this.txtConfirmMdp);
        this.panelMdp.add(this.btChangerMdp);
    }
    
    private void setEditable(boolean editable) {
        this.txtNom.setEditable(editable);
        this.txtPrenom.setEditable(editable);
        this.txtEmail.setEditable(editable);
        this.txtTel.setEditable(editable);
        this.txtAdresse.setEditable(editable);
    }
    
    private Object[][] getDonneesLocations() {
        ArrayList<Location> locations = LocationControleur.getLocationsUtilisateur(this.utilisateur.getId());
        Object[][] donnees = new Object[locations.size()][5];
        
        int i = 0;
        for (Location location : locations) {
            // Récupérer le véhicule pour afficher son modèle
            Vehicule vehicule = VehiculeControleur.getVehiculeById(location.getVehiculeId());
            String modele = vehicule != null ? vehicule.getModele() : "N/A";
            
            // Formater les dates
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            String dateDebut = location.getDateDebut() != null ? sdf.format(location.getDateDebut()) : "N/A";
            String dateFin = location.getDateFin() != null ? sdf.format(location.getDateFin()) : "N/A";
            
            donnees[i][0] = dateDebut;
            donnees[i][1] = dateFin;
            donnees[i][2] = modele;
            donnees[i][3] = location.getPrixTotal() + " €";
            donnees[i][4] = location.getStatut();
            i++;
        }
        
        return donnees;
    }
    
    private Object[][] getDonneesAchats() {
        ArrayList<Vente> ventes = VenteControleur.getVentesUtilisateur(this.utilisateur.getId());
        Object[][] donnees = new Object[ventes.size()][4];
        
        int i = 0;
        for (Vente vente : ventes) {
            // Récupérer le véhicule pour afficher son modèle
            Vehicule vehicule = VehiculeControleur.getVehiculeById(vente.getVehiculeId());
            String modele = vehicule != null ? vehicule.getModele() : "N/A";
            
            // Formater la date
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            String dateVente = vente.getDateVente() != null ? sdf.format(vente.getDateVente()) : "N/A";
            
            donnees[i][0] = dateVente;
            donnees[i][1] = modele;
            donnees[i][2] = vente.getPrixVente() + " €";
            donnees[i][3] = vente.getStatut();
            i++;
        }
        
        return donnees;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == this.btModifier) {
            this.setEditable(true);
            this.btModifier.setVisible(false);
            this.btEnregistrer.setVisible(true);
        }
        else if(e.getSource() == this.btEnregistrer) {
            this.sauvegarderModifications();
        }
        else if(e.getSource() == this.btChangerMdp) {
            this.changerMotDePasse();
        }
    }
    
    private void sauvegarderModifications() {
        // Mise à jour de l'utilisateur
        this.utilisateur.setNom(this.txtNom.getText());
        this.utilisateur.setPrenom(this.txtPrenom.getText());
        this.utilisateur.setEmail(this.txtEmail.getText());
        this.utilisateur.setTelephone(this.txtTel.getText());
        this.utilisateur.setAdresse(this.txtAdresse.getText());
        
        if(UtilisateurControleur.updateUtilisateur(this.utilisateur)) {
            JOptionPane.showMessageDialog(this,
                "Vos informations ont été mises à jour avec succès !",
                "Succès",
                JOptionPane.INFORMATION_MESSAGE);
                
            this.setEditable(false);
            this.btModifier.setVisible(true);
            this.btEnregistrer.setVisible(false);
        } else {
            JOptionPane.showMessageDialog(this,
                "Erreur lors de la mise à jour de vos informations",
                "Erreur",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void changerMotDePasse() {
        String ancienMdp = new String(this.txtAncienMdp.getPassword());
        String nouveauMdp = new String(this.txtNouveauMdp.getPassword());
        String confirmMdp = new String(this.txtConfirmMdp.getPassword());
        
        if(ancienMdp.isEmpty() || nouveauMdp.isEmpty() || confirmMdp.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Veuillez remplir tous les champs",
                "Erreur",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if(!nouveauMdp.equals(confirmMdp)) {
            JOptionPane.showMessageDialog(this,
                "Les nouveaux mots de passe ne correspondent pas",
                "Erreur",
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if(UtilisateurControleur.verifierMotDePasse(this.utilisateur.getId(), ancienMdp)) {
            if(UtilisateurControleur.updateMotDePasse(this.utilisateur.getId(), nouveauMdp)) {
                JOptionPane.showMessageDialog(this,
                    "Votre mot de passe a été modifié avec succès !",
                    "Succès",
                    JOptionPane.INFORMATION_MESSAGE);
                    
                this.txtAncienMdp.setText("");
                this.txtNouveauMdp.setText("");
                this.txtConfirmMdp.setText("");
            } else {
                JOptionPane.showMessageDialog(this,
                    "Erreur lors de la modification du mot de passe",
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this,
                "Ancien mot de passe incorrect",
                "Erreur",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void rafraichirDonnees() {
        // Mettre à jour les tableaux
        String[] entetesLocations = {"Date début", "Date fin", "Véhicule", "Prix total", "Statut"};
        Object[][] donneesLocations = this.getDonneesLocations();
        this.tableLocations.setModel(new DefaultTableModel(donneesLocations, entetesLocations));
        
        String[] entetesAchats = {"Date", "Véhicule", "Prix", "Statut"};
        Object[][] donneesAchats = this.getDonneesAchats();
        this.tableAchats.setModel(new DefaultTableModel(donneesAchats, entetesAchats));
    }
}