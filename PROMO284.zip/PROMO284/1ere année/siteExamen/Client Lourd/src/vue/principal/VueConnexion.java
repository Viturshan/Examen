package vue.principal;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import controleur.UtilisateurControleur;
import modele.entites.Utilisateur;

public class VueConnexion extends JFrame implements ActionListener {
    private JPanel panelConnexion = new JPanel();
    private JButton btSeConnecter = new JButton("Se Connecter");
    private JButton btAnnuler = new JButton("Annuler");
    private JButton btInscription = new JButton("Créer un compte");
    private JTextField txtEmail = new JTextField();
    private JPasswordField txtMdp = new JPasswordField();
    
    public VueConnexion() {
        this.setTitle("E-Peugeot - Connexion");
        this.setBounds(100, 100, 600, 400);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);
        this.setResizable(false);
        
        // Configuration du panel de connexion
        this.panelConnexion.setBounds(150, 100, 300, 200);
        this.panelConnexion.setLayout(new GridLayout(4, 2, 10, 20));
        
        // Ajout des composants
        this.panelConnexion.add(new JLabel("Email :"));
        this.panelConnexion.add(this.txtEmail);
        this.panelConnexion.add(new JLabel("Mot de passe :"));
        this.panelConnexion.add(this.txtMdp);
        this.panelConnexion.add(this.btAnnuler);
        this.panelConnexion.add(this.btSeConnecter);
        this.panelConnexion.add(new JLabel("Pas encore de compte ?"));
        this.panelConnexion.add(this.btInscription);
        
        this.add(this.panelConnexion);
        
        // Ajout des écouteurs
        this.btSeConnecter.addActionListener(this);
        this.btAnnuler.addActionListener(this);
        this.btInscription.addActionListener(this);
        
        this.setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == this.btAnnuler) {
            this.txtEmail.setText("");
            this.txtMdp.setText("");
        }
        else if(e.getSource() == this.btSeConnecter) {
            String email = this.txtEmail.getText();
            String mdp = new String(this.txtMdp.getPassword());
            
            // Vérification des champs
            if(email.equals("") || mdp.equals("")) {
                JOptionPane.showMessageDialog(this, 
                    "Veuillez remplir tous les champs", 
                    "Erreur de saisie", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Tentative de connexion
            Utilisateur utilisateur = UtilisateurControleur.connexionUtilisateur(email, mdp);
            if(utilisateur != null) {
                JOptionPane.showMessageDialog(this, 
                    "Bienvenue " + utilisateur.getPrenom() + " " + utilisateur.getNom(),
                    "Connexion réussie", 
                    JOptionPane.INFORMATION_MESSAGE);
                
                // Ouverture de la fenêtre principale
                new VueGenerale(utilisateur);
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Email ou mot de passe incorrect", 
                    "Erreur de connexion", 
                    JOptionPane.ERROR_MESSAGE);
            }
        }
        else if(e.getSource() == this.btInscription) {
            new VueInscription();
            this.dispose();
        }
    }
}