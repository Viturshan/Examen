package vue.principal;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import modele.entites.Utilisateur;
import vue.panels.*;

public class VueGenerale extends JFrame implements ActionListener {
    private Utilisateur utilisateurConnecte;
    private JPanel panelMenu = new JPanel();
    private JPanel panelContenu = new JPanel();
    
    // Les différents panels
    private PanelAccueil panelAccueil;
    private PanelVehicules panelVehicules;
    private PanelPanier panelPanier;
    private PanelCompte panelCompte;
    private PanelAdmin panelAdmin;
    
    // Les boutons du menu
    private JButton btAccueil = new JButton("Accueil");
    private JButton btVehicules = new JButton("Nos Véhicules");
    private JButton btPanier = new JButton("Panier");
    private JButton btCompte = new JButton("Mon Compte");
    private JButton btDeconnexion = new JButton("Déconnexion");
    private JButton btAdmin = new JButton("Administration");
    
    public VueGenerale(Utilisateur utilisateur) {
        this.utilisateurConnecte = utilisateur;
        
        // Configuration de la fenêtre
        this.setTitle("E-Peugeot - Vente et Location de Véhicules d'Occasion");
        this.setBounds(50, 50, 1200, 700);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);
        this.setResizable(false);
        
        // Configuration du menu
        this.panelMenu.setBounds(0, 0, 1200, 50);
        this.panelMenu.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));
        
        // Ajout du logo Peugeot
        ImageIcon logoPeugeot = new ImageIcon("images/logo.png");
        JLabel labelLogo = new JLabel(logoPeugeot);
        labelLogo.setBounds(10, 5, 40, 40);
        this.panelMenu.add(labelLogo);
        
        // Ajout des boutons au menu
        this.panelMenu.add(this.btAccueil);
        this.panelMenu.add(this.btVehicules);
        this.panelMenu.add(this.btPanier);
        this.panelMenu.add(this.btCompte);
        
        // Ajouter le bouton Admin seulement si l'utilisateur est administrateur
        if(this.utilisateurConnecte.isAdmin()) {
            this.panelMenu.add(this.btAdmin);
        }
        
        this.panelMenu.add(this.btDeconnexion);
        
        // Configuration du panel de contenu
        this.panelContenu.setBounds(0, 50, 1200, 650);
        this.panelContenu.setLayout(null);
        
        // Initialisation des panels
        this.panelAccueil = new PanelAccueil();
        this.panelVehicules = new PanelVehicules(this, this.utilisateurConnecte);
        this.panelPanier = new PanelPanier(this, this.utilisateurConnecte);
        this.panelCompte = new PanelCompte(this.utilisateurConnecte);
        
        // Initialisation du panel Admin si l'utilisateur est admin
        if(this.utilisateurConnecte.isAdmin()) {
            this.panelAdmin = new PanelAdmin(this);
        }
        
        // Ajout des panels au conteneur
        this.panelContenu.add(this.panelAccueil);
        this.panelContenu.add(this.panelVehicules);
        this.panelContenu.add(this.panelPanier);
        this.panelContenu.add(this.panelCompte);
        
        if(this.utilisateurConnecte.isAdmin()) {
            this.panelContenu.add(this.panelAdmin);
        }
        
        // Ajout des panels principaux à la fenêtre
        this.add(this.panelMenu);
        this.add(this.panelContenu);
        
        // Ajout des écouteurs
        this.btAccueil.addActionListener(this);
        this.btVehicules.addActionListener(this);
        this.btPanier.addActionListener(this);
        this.btCompte.addActionListener(this);
        this.btDeconnexion.addActionListener(this);
        
        if(this.utilisateurConnecte.isAdmin()) {
            this.btAdmin.addActionListener(this);
        }
        
        // Affichage initial
        this.afficherPanel("accueil");
        this.setVisible(true);
    }
    
    private void afficherPanel(String panel) {
        this.panelAccueil.setVisible(panel.equals("accueil"));
        this.panelVehicules.setVisible(panel.equals("vehicules"));
        this.panelPanier.setVisible(panel.equals("panier"));
        this.panelCompte.setVisible(panel.equals("compte"));
        
        // Si le panneau panier devient visible, le rafraîchir
        if(panel.equals("panier")) {
            this.rafraichirPanier();
        }
        
        // Si le panneau compte devient visible, le rafraîchir
        if(panel.equals("compte")) {
            this.rafraichirCompte();
        }
        
        if(this.utilisateurConnecte.isAdmin()) {
            this.panelAdmin.setVisible(panel.equals("admin"));
        }
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == this.btAccueil) {
            this.afficherPanel("accueil");
        }
        else if(e.getSource() == this.btVehicules) {
            this.afficherPanel("vehicules");
        }
        else if(e.getSource() == this.btPanier) {
            this.afficherPanel("panier");
        }
        else if(e.getSource() == this.btCompte) {
            this.afficherPanel("compte");
        }
        else if(e.getSource() == this.btAdmin) {
            this.afficherPanel("admin");
        }
        else if(e.getSource() == this.btDeconnexion) {
            int choix = JOptionPane.showConfirmDialog(this,
                "Voulez-vous vraiment vous déconnecter ?",
                "Confirmation de déconnexion",
                JOptionPane.YES_NO_OPTION);
                
            if(choix == JOptionPane.YES_OPTION) {
                new VueConnexion();
                this.dispose();
            }
        }
    }
    
    // Méthodes d'accès aux panels
    public PanelVehicules getPanelVehicules() {
        return this.panelVehicules;
    }
    
    // Méthode pour rafraîchir le panier
    public void rafraichirPanier() {
        if(this.panelPanier != null) {
            this.panelPanier.chargerPanier();
        }
    }
    
    // Méthode pour rafraîchir le compte
    public void rafraichirCompte() {
        if (this.panelCompte != null) {
            this.panelCompte.rafraichirDonnees();
        }
    }
}