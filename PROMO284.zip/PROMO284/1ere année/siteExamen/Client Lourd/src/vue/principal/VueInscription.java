package vue.principal;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import controleur.UtilisateurControleur;
import modele.entites.Utilisateur;
import util.ValidationUtils;

public class VueInscription extends JFrame implements ActionListener {
    private JPanel panelInscription = new JPanel();
    private JButton btInscription = new JButton("S'inscrire");
    private JButton btAnnuler = new JButton("Annuler");
    private JTextField txtEmail = new JTextField();
    private JPasswordField txtMdp = new JPasswordField();
    private JPasswordField txtConfirmMdp = new JPasswordField();
    private JTextField txtNom = new JTextField();
    private JTextField txtPrenom = new JTextField();
    private JTextField txtAdresse = new JTextField();
    private JTextField txtTelephone = new JTextField();
    
    public VueInscription() {
        this.setTitle("E-Peugeot - Inscription");
        this.setBounds(100, 100, 600, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);
        this.setResizable(false);
        
        // Configuration du panel d'inscription
        this.panelInscription.setBounds(100, 50, 400, 350);
        this.panelInscription.setLayout(new GridLayout(8, 2, 10, 10));
        
        // Ajout des composants
        this.panelInscription.add(new JLabel("Email :"));
        this.panelInscription.add(this.txtEmail);
        this.panelInscription.add(new JLabel("Mot de passe :"));
        this.panelInscription.add(this.txtMdp);
        this.panelInscription.add(new JLabel("Confirmer mot de passe :"));
        this.panelInscription.add(this.txtConfirmMdp);
        this.panelInscription.add(new JLabel("Nom :"));
        this.panelInscription.add(this.txtNom);
        this.panelInscription.add(new JLabel("Prénom :"));
        this.panelInscription.add(this.txtPrenom);
        this.panelInscription.add(new JLabel("Adresse :"));
        this.panelInscription.add(this.txtAdresse);
        this.panelInscription.add(new JLabel("Téléphone :"));
        this.panelInscription.add(this.txtTelephone);
        this.panelInscription.add(this.btAnnuler);
        this.panelInscription.add(this.btInscription);
        
        this.add(this.panelInscription);
        
        // Ajout des écouteurs
        this.btInscription.addActionListener(this);
        this.btAnnuler.addActionListener(this);
        
        this.setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == this.btAnnuler) {
            new VueConnexion();
            this.dispose();
        }
        else if(e.getSource() == this.btInscription) {
            // Récupération des valeurs
            String email = this.txtEmail.getText();
            String mdp = new String(this.txtMdp.getPassword());
            String confirmMdp = new String(this.txtConfirmMdp.getPassword());
            String nom = this.txtNom.getText();
            String prenom = this.txtPrenom.getText();
            String adresse = this.txtAdresse.getText();
            String telephone = this.txtTelephone.getText();
            
            // Validation des données
            if(email.isEmpty() || mdp.isEmpty() || confirmMdp.isEmpty() || 
               nom.isEmpty() || prenom.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                    "Veuillez remplir tous les champs obligatoires",
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Vérification de la correspondance des mots de passe
            if(!mdp.equals(confirmMdp)) {
                JOptionPane.showMessageDialog(this,
                    "Les mots de passe ne correspondent pas",
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Vérification de l'email
            if(UtilisateurControleur.emailExiste(email)) {
                JOptionPane.showMessageDialog(this,
                    "Cet email est déjà utilisé",
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Création de l'utilisateur
            Utilisateur utilisateur = new Utilisateur(
                email, mdp, nom, prenom, adresse, telephone
            );
            
            // Insertion dans la base de données
            if(UtilisateurControleur.insertUtilisateur(utilisateur)) {
                JOptionPane.showMessageDialog(this,
                    "Compte créé avec succès ! Vous pouvez maintenant vous connecter.",
                    "Succès",
                    JOptionPane.INFORMATION_MESSAGE);
                    
                new VueConnexion();
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this,
                    "Erreur lors de la création du compte",
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}