package vue.composants;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import modele.entites.Vehicule;
import util.ImageManager;
import vue.dialogs.DialogDetailVehicule;

public class VehiculeCard extends JPanel {
    private Vehicule vehicule;
    private JLabel lbMarque;
    private JLabel lbImage;
    private JLabel lbModele;
    private JLabel lbPrixVente;
    private JLabel lbPrixLocation;
    private JButton btDetails;

    public VehiculeCard(Vehicule vehicule) {
        this.vehicule = vehicule;
        this.setPreferredSize(new Dimension(300, 400));
        this.setLayout(null);
        this.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        this.setBackground(Color.WHITE);

        // Image du véhicule
        this.lbImage = new JLabel();
        this.lbImage.setBounds(10, 10, 280, 200);
        this.lbImage.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        this.lbImage.setHorizontalAlignment(JLabel.CENTER);
        
        // Chargement de l'image
        ImageIcon image = ImageManager.getVehiculeImage(vehicule.getReference());
        if (image != null) {
            this.lbImage.setIcon(image);
        } else {
            this.lbImage.setText("Image non disponible");
        }
        this.add(this.lbImage);

        // Informations du véhicule
        Font titleFont = new Font("Arial", Font.BOLD, 16);
        Font normalFont = new Font("Arial", Font.PLAIN, 14);

        this.lbModele = new JLabel(vehicule.getModele());
        this.lbModele.setFont(titleFont);
        this.lbModele.setBounds(10, 220, 280, 25);
        this.add(this.lbModele);

        // Informations complémentaires dans un sous-panel
        JPanel panelInfo = new JPanel(new GridLayout(4, 1, 5, 5));
        panelInfo.setBounds(10, 250, 280, 100);
        panelInfo.setBackground(Color.WHITE);
        
        JLabel lbMarque = new JLabel("Année : " + marque.getMarque());
        lbMarque.setFont(normalFont);
        panelInfo.add(lbMarque);

        JLabel lbAnnee = new JLabel("Année : " + vehicule.getAnnee());
        lbAnnee.setFont(normalFont);
        panelInfo.add(lbAnnee);

        JLabel lbKm = new JLabel("Kilométrage : " + vehicule.getKilometrage() + " km");
        lbKm.setFont(normalFont);
        panelInfo.add(lbKm);

        this.lbPrixVente = new JLabel("Prix vente : " + vehicule.getPrixVente() + " €");
        this.lbPrixVente.setFont(normalFont);
        this.lbPrixVente.setForeground(new Color(0, 100, 0));
        panelInfo.add(this.lbPrixVente);

        this.lbPrixLocation = new JLabel("Location : " + vehicule.getPrixLocationJour() + " €/jour");
        this.lbPrixLocation.setFont(normalFont);
        this.lbPrixLocation.setForeground(new Color(0, 0, 150));
        panelInfo.add(this.lbPrixLocation);

        this.add(panelInfo);

        // Bouton Détails
        this.btDetails = new JButton("Voir détails");
        this.btDetails.setBounds(85, 360, 130, 30);
        this.btDetails.setBackground(new Color(51, 122, 183));
        this.btDetails.setForeground(Color.WHITE);
        this.btDetails.setBorderPainted(false);
        this.btDetails.setFocusPainted(false);
        this.add(this.btDetails);

        // Ajout des écouteurs
        this.btDetails.addActionListener(e -> afficherDetails());
        
        // Effet de survol sur le bouton
        this.btDetails.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btDetails.setBackground(new Color(40, 96, 144));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btDetails.setBackground(new Color(51, 122, 183));
            }
        });

        // Effet de survol sur la carte
        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                setBorder(BorderFactory.createLineBorder(new Color(51, 122, 183), 2));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                setBorder(BorderFactory.createLineBorder(Color.GRAY));
            }
        });
    }

    private void afficherDetails() {
        Window window = SwingUtilities.getWindowAncestor(this);
        if (window instanceof JFrame) {
            DialogDetailVehicule dialog = new DialogDetailVehicule(
                (JFrame) window, 
                this.vehicule,
                0  // l'ID de l'utilisateur devrait être passé en paramètre
            );
            dialog.setVisible(true);
        }
    }
}