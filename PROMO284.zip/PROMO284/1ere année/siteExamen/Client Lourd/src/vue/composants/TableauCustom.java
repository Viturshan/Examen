package vue.composants;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class TableauCustom extends JTable {
    private ArrayList<String> colonnesTriables;
    private boolean alternateRowColor;

    public TableauCustom(TableModel model) {
        this(model, true, new ArrayList<>());
    }

    public TableauCustom(TableModel model, boolean alternateRowColor, ArrayList<String> colonnesTriables) {
        super(model);
        this.alternateRowColor = alternateRowColor;
        this.colonnesTriables = colonnesTriables;
        
        // Configuration de base
        this.setShowGrid(true);
        this.setGridColor(new Color(220, 220, 220));
        this.setRowHeight(30);
        this.setIntercellSpacing(new Dimension(0, 0));
        this.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        this.setAutoCreateRowSorter(true);

        // Configuration de l'en-tête
        JTableHeader header = this.getTableHeader();
        header.setBackground(new Color(240, 240, 240));
        header.setForeground(Color.BLACK);
        header.setFont(new Font("Arial", Font.BOLD, 12));
        header.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));

        // Rendu personnalisé pour les cellules
        this.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, 
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, 
                        isSelected, hasFocus, row, column);

                if (!isSelected) {
                    if (alternateRowColor && row % 2 == 0) {
                        c.setBackground(new Color(245, 245, 250));
                    } else {
                        c.setBackground(Color.WHITE);
                    }
                } else {
                    c.setBackground(new Color(51, 122, 183));
                    c.setForeground(Color.WHITE);
                }

                // Bordures des cellules
                ((JComponent) c).setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));

                return c;
            }
        });

        // Configuration du tri
        if (!colonnesTriables.isEmpty()) {
            TableRowSorter<TableModel> sorter = new TableRowSorter<>(model);
            this.setRowSorter(sorter);

            // Désactiver le tri pour les colonnes non triables
            for (int i = 0; i < model.getColumnCount(); i++) {
                String columnName = model.getColumnName(i);
                if (!colonnesTriables.contains(columnName)) {
                    sorter.setSortable(i, false);
                }
            }
        }

        // Ajout d'un listener pour le clic droit
        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                if (e.isPopupTrigger()) {
                    JTable source = (JTable) e.getSource();
                    int row = source.rowAtPoint(e.getPoint());
                    int column = source.columnAtPoint(e.getPoint());

                    if (!source.isRowSelected(row)) {
                        source.changeSelection(row, column, false, false);
                    }

                    showPopupMenu(e);
                }
            }
        });
    }

    private void showPopupMenu(MouseEvent e) {
        JPopupMenu popup = new JPopupMenu();
        
        JMenuItem menuCopy = new JMenuItem("Copier");
        menuCopy.addActionListener(evt -> copySelectedCellToClipboard());
        popup.add(menuCopy);

        if (this.getSelectedRow() != -1) {
            popup.addSeparator();
            
            JMenuItem menuExport = new JMenuItem("Exporter la ligne");
            menuExport.addActionListener(evt -> exportSelectedRow());
            popup.add(menuExport);
        }

        popup.show(e.getComponent(), e.getX(), e.getY());
    }

    private void copySelectedCellToClipboard() {
        int row = this.getSelectedRow();
        int col = this.getSelectedColumn();
        
        if (row != -1 && col != -1) {
            Object value = this.getValueAt(row, col);
            if (value != null) {
                String stringValue = value.toString();
                java.awt.Toolkit.getDefaultToolkit()
                    .getSystemClipboard()
                    .setContents(new java.awt.datatransfer.StringSelection(stringValue), null);
            }
        }
    }

    private void exportSelectedRow() {
        int row = this.getSelectedRow();
        if (row != -1) {
            StringBuilder sb = new StringBuilder();
            for (int col = 0; col < this.getColumnCount(); col++) {
                Object value = this.getValueAt(row, col);
                sb.append(value != null ? value.toString() : "").append("\t");
            }
            java.awt.Toolkit.getDefaultToolkit()
                .getSystemClipboard()
                .setContents(new java.awt.datatransfer.StringSelection(sb.toString()), null);
        }
    }

    // Méthode pour filtrer le tableau
    public void filtrer(String texte) {
        if (this.getRowSorter() == null) {
            this.setRowSorter(new TableRowSorter<>(this.getModel()));
        }
        
        TableRowSorter<TableModel> sorter = (TableRowSorter<TableModel>) this.getRowSorter();
        if (texte.length() == 0) {
            sorter.setRowFilter(null);
        } else {
            sorter.setRowFilter(RowFilter.regexFilter("(?i)" + texte));
        }
    }
}