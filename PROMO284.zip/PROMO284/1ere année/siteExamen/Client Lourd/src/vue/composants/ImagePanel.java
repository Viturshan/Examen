package vue.composants;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.swing.border.Border;

public class ImagePanel extends JPanel {
    private Image image;
    private int width;
    private int height;
    private boolean maintainAspectRatio;
    private boolean zoomable;
    private float zoomFactor = 1.0f;
    private Point dragStart;
    private Point imagePosition = new Point(0, 0);

    public ImagePanel() {
        this(null, true, true);
    }

    public ImagePanel(Image image) {
        this(image, true, true);
    }

    public ImagePanel(Image image, boolean maintainAspectRatio, boolean zoomable) {
        this.image = image;
        this.maintainAspectRatio = maintainAspectRatio;
        this.zoomable = zoomable;

        setBackground(Color.WHITE);
        setBorder(BorderFactory.createLineBorder(Color.GRAY));

        // Gestion du zoom avec la molette de la souris
        if (zoomable) {
            addMouseWheelListener(e -> {
                if (image != null) {
                    int notches = e.getWheelRotation();
                    // Zoom in/out par pas de 10%
                    float factor = 1 - (notches * 0.1f);
                    zoom(factor);
                }
            });

            // Gestion du drag & drop de l'image
            addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    dragStart = e.getPoint();
                }

                @Override
                public void mouseReleased(MouseEvent e) {
                    dragStart = null;
                }
            });

            addMouseMotionListener(new MouseMotionAdapter() {
                @Override
                public void mouseDragged(MouseEvent e) {
                    if (dragStart != null && image != null) {
                        Point current = e.getPoint();
                        imagePosition.x += current.x - dragStart.x;
                        imagePosition.y += current.y - dragStart.y;
                        dragStart = current;
                        repaint();
                    }
                }
            });
        }
    }

    public void setImage(Image image) {
        this.image = image;
        this.zoomFactor = 1.0f;
        this.imagePosition = new Point(0, 0);
        if (image != null) {
            this.width = image.getWidth(null);
            this.height = image.getHeight(null);
        }
        repaint();
    }

    public void zoom(float factor) {
        this.zoomFactor *= factor;
        // Limiter le zoom entre 0.1 et 5.0
        this.zoomFactor = Math.max(0.1f, Math.min(5.0f, this.zoomFactor));
        repaint();
    }

    public void resetZoom() {
        this.zoomFactor = 1.0f;
        this.imagePosition = new Point(0, 0);
        repaint();
    }

    public void setBorderWithTitle(String title) {
        Border border = BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(Color.GRAY),
            title
        );
        setBorder(border);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        if (image == null) {
            // Afficher un message si pas d'image
            String message = "Aucune image";
            FontMetrics fm = g.getFontMetrics();
            int messageWidth = fm.stringWidth(message);
            int messageHeight = fm.getHeight();
            g.drawString(message, 
                (getWidth() - messageWidth) / 2,
                (getHeight() - messageHeight) / 2);
            return;
        }

        Graphics2D g2d = (Graphics2D) g;
        // Activer l'antialiasing pour une meilleure qualité
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                            RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                            RenderingHints.VALUE_INTERPOLATION_BILINEAR);

        // Calculer les dimensions de l'image
        int imageWidth = (int) (width * zoomFactor);
        int imageHeight = (int) (height * zoomFactor);

        if (maintainAspectRatio) {
            // Calculer le ratio pour maintenir les proportions
            double ratio = Math.min(
                (double) getWidth() / width,
                (double) getHeight() / height
            );
            imageWidth = (int) (width * ratio * zoomFactor);
            imageHeight = (int) (height * ratio * zoomFactor);
        }

        // Centrer l'image si nécessaire
        int x = imagePosition.x;
        int y = imagePosition.y;
        if (imageWidth < getWidth()) {
            x = (getWidth() - imageWidth) / 2;
        }
        if (imageHeight < getHeight()) {
            y = (getHeight() - imageHeight) / 2;
        }

        // Dessiner l'image
        g2d.drawImage(image, x, y, imageWidth, imageHeight, null);

        // Ajouter une ombre portée si l'image est plus petite que le panel
        if (imageWidth < getWidth() || imageHeight < getHeight()) {
            int shadowSize = 5;
            int shadowOffset = 3;
            g2d.setColor(new Color(0, 0, 0, 50));
            g2d.fillRect(x + shadowOffset, y + shadowOffset,
                        imageWidth + shadowSize, imageHeight + shadowSize);
        }
    }

    // Méthodes utilitaires
    public Image getScaledImage(int targetWidth, int targetHeight) {
        if (image == null) return null;

        BufferedImage resized = new BufferedImage(targetWidth, targetHeight, 
                                                BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = resized.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                            RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2d.drawImage(image, 0, 0, targetWidth, targetHeight, null);
        g2d.dispose();
        return resized;
    }

    public void setImageWithMaxDimension(Image image, int maxDimension) {
        if (image == null) {
            setImage(null);
            return;
        }

        int originalWidth = image.getWidth(null);
        int originalHeight = image.getHeight(null);

        if (originalWidth <= maxDimension && originalHeight <= maxDimension) {
            setImage(image);
            return;
        }

        // Calculer les nouvelles dimensions en maintenant le ratio
        double ratio = Math.min(
            (double) maxDimension / originalWidth,
            (double) maxDimension / originalHeight
        );
        int newWidth = (int) (originalWidth * ratio);
        int newHeight = (int) (originalHeight * ratio);

        setImage(getScaledImage(newWidth, newHeight));
    }

    public void setImageFromFile(String path) {
        try {
            Image img = new ImageIcon(path).getImage();
            setImage(img);
        } catch (Exception e) {
            System.err.println("Erreur lors du chargement de l'image : " + path);
            e.printStackTrace();
        }
    }

    public void saveToFile(String path) {
        if (image == null) return;

        try {
            // Créer une image buffered de la taille actuelle
            BufferedImage bi = new BufferedImage(getWidth(), getHeight(), 
                                               BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2d = bi.createGraphics();
            this.paint(g2d);
            g2d.dispose();

            // Sauvegarder l'image
            String extension = path.substring(path.lastIndexOf('.') + 1);
            javax.imageio.ImageIO.write(bi, extension, new java.io.File(path));
        } catch (Exception e) {
            System.err.println("Erreur lors de la sauvegarde de l'image : " + path);
            e.printStackTrace();
        }
    }

    // Getters
    public Image getImage() { return image; }
    public float getZoomFactor() { return zoomFactor; }
    public boolean isZoomable() { return zoomable; }
    public boolean isMaintainAspectRatio() { return maintainAspectRatio; }

    // Setters
    public void setZoomable(boolean zoomable) { this.zoomable = zoomable; }
    public void setMaintainAspectRatio(boolean maintainAspectRatio) { 
        this.maintainAspectRatio = maintainAspectRatio; 
    }
}