package util;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Calendar;

public class DateUtils {
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy");
    private static final SimpleDateFormat DATE_TIME_FORMAT = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    private static final SimpleDateFormat SQL_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
    private static final SimpleDateFormat SQL_DATE_TIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    // Convertir une String en Date
    public static Date stringToDate(String dateStr) {
        try {
            return DATE_FORMAT.parse(dateStr);
        } catch (ParseException e) {
            System.err.println("Erreur de conversion de la date: " + dateStr);
            return null;
        }
    }

    // Convertir une Date en String
    public static String dateToString(Date date) {
        if (date == null) return "";
        return DATE_FORMAT.format(date);
    }

    // Convertir une Date en format SQL
    public static String dateToSqlString(Date date) {
        if (date == null) return null;
        return SQL_DATE_FORMAT.format(date);
    }

    // Convertir une String SQL en Date
    public static Date sqlStringToDate(String sqlDate) {
        try {
            return SQL_DATE_FORMAT.parse(sqlDate);
        } catch (ParseException e) {
            System.err.println("Erreur de conversion de la date SQL: " + sqlDate);
            return null;
        }
    }

    // Obtenir la date du jour
    public static Date today() {
        return new Date();
    }

    // Ajouter des jours à une date
    public static Date addDays(Date date, int days) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, days);
        return cal.getTime();
    }

    // Calculer la différence en jours entre deux dates
    public static int daysBetween(Date date1, Date date2) {
        long diff = date2.getTime() - date1.getTime();
        return (int) (diff / (1000 * 60 * 60 * 24));
    }

    // Vérifier si une date est antérieure à aujourd'hui
    public static boolean isBeforeToday(Date date) {
        return date.before(today());
    }

    // Vérifier si une date est future
    public static boolean isFutureDate(Date date) {
        return date.after(today());
    }

    // Obtenir le premier jour du mois
    public static Date getFirstDayOfMonth() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_MONTH, 1);
        return cal.getTime();
    }

    // Obtenir le dernier jour du mois
    public static Date getLastDayOfMonth() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
        return cal.getTime();
    }

    // Vérifier si une date est comprise dans une période
    public static boolean isDateInRange(Date date, Date startDate, Date endDate) {
        return !date.before(startDate) && !date.after(endDate);
    }

    // Vérifier si deux périodes se chevauchent
    public static boolean periodsOverlap(Date start1, Date end1, Date start2, Date end2) {
        return start1.before(end2) && end1.after(start2);
    }

    // Formater une date avec l'heure
    public static String formatDateTime(Date date) {
        if (date == null) return "";
        return DATE_TIME_FORMAT.format(date);
    }

    // Obtenir l'âge à partir d'une date de naissance
    public static int getAge(Date birthDate) {
        Calendar birth = Calendar.getInstance();
        birth.setTime(birthDate);
        Calendar today = Calendar.getInstance();

        int age = today.get(Calendar.YEAR) - birth.get(Calendar.YEAR);
        
        if (today.get(Calendar.DAY_OF_YEAR) < birth.get(Calendar.DAY_OF_YEAR)) {
            age--;
        }
        
        return age;
    }

    // Vérifier si une année est bissextile
    public static boolean isLeapYear(int year) {
        return year % 4 == 0 && (year % 100 != 0 || year % 400 == 0);
    }

    // Obtenir une date sans l'heure
    public static Date truncateTime(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    // Vérifier si une chaîne est une date valide
    public static boolean isValidDate(String dateStr) {
        try {
            DATE_FORMAT.setLenient(false);
            DATE_FORMAT.parse(dateStr);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }
}