package util;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

public class ImageManager {
    private static final String IMAGE_PATH = "resources/images/vehicules/";
    private static final String DEFAULT_IMAGE = "default.jpg";
    
    public static ImageIcon getVehiculeImage(String reference) {
        return getVehiculeImage(reference, 160, 120);
    }
    
    public static ImageIcon getVehiculeImage(String reference, int width, int height) {
        try {
            String imagePath = IMAGE_PATH + reference + ".jpg";
            File file = new File(imagePath);
            
            if(!file.exists()) {
                file = new File(IMAGE_PATH + DEFAULT_IMAGE);
            }
            
            BufferedImage img = ImageIO.read(file);
            Image resizedImg = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
            return new ImageIcon(resizedImg);
            
        } catch(IOException e) {
            System.out.println("Erreur chargement image : " + e.getMessage());
            return null;
        }
    }
    
    public static boolean saveVehiculeImage(String reference, File sourceFile) {
        try {
            BufferedImage img = ImageIO.read(sourceFile);
            File destFile = new File(IMAGE_PATH + reference + ".jpg");
            return ImageIO.write(img, "jpg", destFile);
        } catch(IOException e) {
            System.out.println("Erreur sauvegarde image : " + e.getMessage());
            return false;
        }
    }
    
    public static JLabel createImageLabel(String reference, int width, int height) {
        JLabel label = new JLabel();
        label.setPreferredSize(new Dimension(width, height));
        label.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        
        ImageIcon icon = getVehiculeImage(reference, width, height);
        if(icon != null) {
            label.setIcon(icon);
        } else {
            label.setText("Image non disponible");
            label.setHorizontalAlignment(JLabel.CENTER);
        }
        
        return label;
    }
    
    public static void removeVehiculeImage(String reference) {
        File file = new File(IMAGE_PATH + reference + ".jpg");
        if(file.exists()) {
            file.delete();
        }
    }
}