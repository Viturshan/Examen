package util;

import javax.swing.*;
import java.awt.*;

public class SystemMessages {
    private static final ImageIcon ICON_SUCCESS = new ImageIcon("resources/images/icons/success.png");
    private static final ImageIcon ICON_ERROR = new ImageIcon("resources/images/icons/error.png");
    private static final ImageIcon ICON_WARNING = new ImageIcon("resources/images/icons/warning.png");
    private static final ImageIcon ICON_INFO = new ImageIcon("resources/images/icons/info.png");

    public static void showSuccess(Component parent, String message) {
        JOptionPane.showMessageDialog(parent,
            message,
            "Succès",
            JOptionPane.INFORMATION_MESSAGE,
            ICON_SUCCESS);
    }

    public static void showError(Component parent, String message) {
        JOptionPane.showMessageDialog(parent,
            message,
            "Erreur",
            JOptionPane.ERROR_MESSAGE,
            ICON_ERROR);
    }

    public static void showWarning(Component parent, String message) {
        JOptionPane.showMessageDialog(parent,
            message,
            "Attention",
            JOptionPane.WARNING_MESSAGE,
            ICON_WARNING);
    }

    public static void showInfo(Component parent, String message) {
        JOptionPane.showMessageDialog(parent,
            message,
            "Information",
            JOptionPane.INFORMATION_MESSAGE,
            ICON_INFO);
    }

    public static boolean showConfirm(Component parent, String message) {
        return JOptionPane.showConfirmDialog(parent,
            message,
            "Confirmation",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION;
    }

    public static String showInput(Component parent, String message) {
        return JOptionPane.showInputDialog(parent,
            message,
            "Saisie",
            JOptionPane.QUESTION_MESSAGE);
    }

    public static void showLoadingDialog(JFrame parent, String message) {
        JDialog dialog = new JDialog(parent, "Chargement", true);
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JLabel messageLabel = new JLabel(message);
        JProgressBar progressBar = new JProgressBar();
        progressBar.setIndeterminate(true);
        
        panel.add(messageLabel, BorderLayout.NORTH);
        panel.add(progressBar, BorderLayout.CENTER);
        
        dialog.add(panel);
        dialog.pack();
        dialog.setLocationRelativeTo(parent);
        
        // Afficher la dialog dans un thread séparé
        new Thread(() -> dialog.setVisible(true)).start();
    }

    public static void hideLoadingDialog(JDialog dialog) {
        if(dialog != null && dialog.isVisible()) {
            dialog.dispose();
        }
    }
}