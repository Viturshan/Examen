package util;

public class Constants {
    // Configuration de la base de données
    public static final String DB_HOST = "localhost";
    public static final String DB_PORT = "3306";
    public static final String DB_NAME = "epeugeot";
    public static final String DB_USER = "root";
    public static final String DB_PASSWORD = "";
    
    // Chemins des ressources
    public static final String PATH_RESOURCES = "resources/";
    public static final String PATH_IMAGES = PATH_RESOURCES + "images/";
    public static final String PATH_ICONS = PATH_IMAGES + "icons/";
    public static final String PATH_VEHICULES = PATH_IMAGES + "vehicules/";
    
    // Statuts des commandes
    public static final String STATUS_EN_ATTENTE = "EN_ATTENTE";
    public static final String STATUS_CONFIRMEE = "CONFIRMEE";
    public static final String STATUS_EN_COURS = "EN_COURS";
    public static final String STATUS_TERMINEE = "TERMINEE";
    public static final String STATUS_ANNULEE = "ANNULEE";
    
    // Catégories de véhicules
    public static final String[] CATEGORIES = {"Citadines", "Berlines"};
    
    // États des véhicules
    public static final String[] ETATS = {"Excellent", "Bien", "Moyen", "Mauvais"};
    
    // Configuration de l'interface
    public static final int WINDOW_WIDTH = 1200;
    public static final int WINDOW_HEIGHT = 700;
    public static final int CARD_WIDTH = 350;
    public static final int CARD_HEIGHT = 200;
    
    // Messages système
    public static final String MSG_ERREUR_CONNEXION = "Erreur de connexion à la base de données";
    public static final String MSG_ERREUR_REQUETE = "Erreur lors de l'exécution de la requête";
    public static final String MSG_CONFIRMATION_SUPPRESSION = "Voulez-vous vraiment supprimer cet élément ?";
    public static final String MSG_SUCCES_AJOUT = "Élément ajouté avec succès";
    public static final String MSG_SUCCES_MODIFICATION = "Modifications enregistrées avec succès";
    public static final String MSG_SUCCES_SUPPRESSION = "Élément supprimé avec succès";
    
    // Formats de date
    public static final String DATE_FORMAT = "dd/MM/yyyy";
    public static final String DATE_TIME_FORMAT = "dd/MM/yyyy HH:mm:ss";
    
    // Délais et durées
    public static final int DUREE_MIN_LOCATION = 1; // en jours
    public static final int DUREE_MAX_LOCATION = 30; // en jours
    public static final int DELAI_RESERVATION = 2; // en jours
    
    // Rôles utilisateurs
    public static final String ROLE_ADMIN = "ADMIN";
    public static final String ROLE_CLIENT = "CLIENT";
    
    // Configuration emails
    public static final String EMAIL_FROM = "noreply@epeugeot.fr";
    public static final String EMAIL_SUBJECT_CONFIRMATION = "Confirmation de votre commande";
    public static final String EMAIL_SUBJECT_ANNULATION = "Annulation de votre commande";
}