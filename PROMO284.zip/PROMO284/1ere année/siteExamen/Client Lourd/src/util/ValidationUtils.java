package util;

import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class ValidationUtils {
    // Patterns pour la validation
    private static final Pattern EMAIL_PATTERN = 
        Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");
    private static final Pattern PHONE_PATTERN = 
        Pattern.compile("^0[1-9][0-9]{8}$");
    private static final Pattern POSTAL_CODE_PATTERN = 
        Pattern.compile("^[0-9]{5}$");
    private static final Pattern NAME_PATTERN = 
        Pattern.compile("^[A-Za-zÀ-ÿ\\s'-]+$");
    private static final Pattern PASSWORD_PATTERN = 
        Pattern.compile("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$");
    private static final Pattern CREDIT_CARD_PATTERN = 
        Pattern.compile("^[0-9]{16}$");

    // Validation de l'email
    public static boolean isValidEmail(String email) {
        if (email == null) return false;
        Matcher matcher = EMAIL_PATTERN.matcher(email);
        return matcher.matches();
    }

    // Validation du numéro de téléphone (format français)
    public static boolean isValidPhone(String phone) {
        if (phone == null) return false;
        phone = phone.replaceAll("\\s", "").replaceAll("\\.", "");
        Matcher matcher = PHONE_PATTERN.matcher(phone);
        return matcher.matches();
    }

    // Validation du code postal
    public static boolean isValidPostalCode(String postalCode) {
        if (postalCode == null) return false;
        Matcher matcher = POSTAL_CODE_PATTERN.matcher(postalCode);
        return matcher.matches();
    }

    // Validation du nom/prénom
    public static boolean isValidName(String name) {
        if (name == null || name.trim().isEmpty()) return false;
        Matcher matcher = NAME_PATTERN.matcher(name);
        return matcher.matches();
    }

    // Validation du mot de passe
    public static boolean isValidPassword(String password) {
        if (password == null) return false;
        Matcher matcher = PASSWORD_PATTERN.matcher(password);
        return matcher.matches();
    }

    // Validation du numéro de carte de crédit
    public static boolean isValidCreditCard(String cardNumber) {
        if (cardNumber == null) return false;
        cardNumber = cardNumber.replaceAll("\\s", "");
        Matcher matcher = CREDIT_CARD_PATTERN.matcher(cardNumber);
        if (!matcher.matches()) return false;
        
        // Algorithme de Luhn
        return isValidLuhn(cardNumber);
    }

    // Algorithme de Luhn pour la validation des cartes de crédit
    private static boolean isValidLuhn(String number) {
        int sum = 0;
        boolean alternate = false;
        
        for (int i = number.length() - 1; i >= 0; i--) {
            int n = Integer.parseInt(number.substring(i, i + 1));
            if (alternate) {
                n *= 2;
                if (n > 9) {
                    n = (n % 10) + 1;
                }
            }
            sum += n;
            alternate = !alternate;
        }
        
        return (sum % 10 == 0);
    }

    // Validation des champs obligatoires
    public static boolean isNotEmpty(String... fields) {
        for (String field : fields) {
            if (field == null || field.trim().isEmpty()) {
                return false;
            }
        }
        return true;
    }

    // Validation de la longueur d'une chaîne
    public static boolean isValidLength(String text, int minLength, int maxLength) {
        if (text == null) return false;
        int length = text.length();
        return length >= minLength && length <= maxLength;
    }

    // Validation des nombres
    public static boolean isValidNumber(String number) {
        try {
            Double.parseDouble(number);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // Validation des nombres entiers positifs
    public static boolean isPositiveInteger(String number) {
        try {
            int value = Integer.parseInt(number);
            return value > 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // Validation des montants positifs
    public static boolean isValidAmount(String amount) {
        try {
            double value = Double.parseDouble(amount);
            return value >= 0 && amount.matches("^\\d+(\\.\\d{0,2})?$");
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // Validation d'une URL
    public static boolean isValidUrl(String url) {
        try {
            new java.net.URL(url).toURI();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // Validation d'une adresse IP
    public static boolean isValidIpAddress(String ip) {
        if (ip == null || ip.isEmpty()) return false;
        
        String[] parts = ip.split("\\.");
        if (parts.length != 4) return false;
        
        try {
            for (String part : parts) {
                int value = Integer.parseInt(part);
                if (value < 0 || value > 255) return false;
            }
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // Nettoyage des entrées HTML
    public static String sanitizeHtml(String input) {
        if (input == null) return null;
        return input.replaceAll("<[^>]*>", "")
                   .replaceAll("&", "&amp;")
                   .replaceAll("\"", "&quot;")
                   .replaceAll("'", "&#x27;")
                   .replaceAll("<", "&lt;")
                   .replaceAll(">", "&gt;");
    }
}