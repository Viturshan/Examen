package controleur;

import modele.bdd.Connexion;
import modele.entites.Vente;
import java.sql.*;
import java.util.ArrayList;
import java.math.BigDecimal;

public class VenteControleur {
    private static Connection connexion = Connexion.getInstance().getMaConnexion();

    public static boolean creerVente(Vente vente) {
        String requete = "INSERT INTO vente (utilisateur_id, vehicule_id, prix_vente, statut) " +
                        "VALUES (?, ?, ?, ?);";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, vente.getUtilisateurId());
            pstmt.setInt(2, vente.getVehiculeId());
            pstmt.setBigDecimal(3, vente.getPrixVente());
            pstmt.setString(4, vente.getStatut());
            
            boolean resultat = pstmt.executeUpdate() > 0;
            if (resultat) {
                // Mettre à jour le statut du véhicule
                updateDisponibiliteVehicule(vente.getVehiculeId(), false);
            }
            return resultat;
        } catch(SQLException exp) {
            System.out.println("Erreur création vente : " + exp.getMessage());
            return false;
        }
    }

    public static ArrayList<Vente> getVentesUtilisateur(int utilisateurId) {
        ArrayList<Vente> ventes = new ArrayList<>();
        String requete = "SELECT * FROM vente WHERE utilisateur_id = ?;";
        
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, utilisateurId);
            ResultSet rs = pstmt.executeQuery();
            
            while(rs.next()) {
                Vente vente = new Vente(
                    rs.getInt("id"),
                    rs.getInt("utilisateur_id"),
                    rs.getInt("vehicule_id"),
                    rs.getBigDecimal("prix_vente"),
                    rs.getTimestamp("date_vente"),
                    rs.getString("statut")
                );
                ventes.add(vente);
            }
        } catch(SQLException exp) {
            System.out.println("Erreur récupération ventes : " + exp.getMessage());
        }
        return ventes;
    }

    public static boolean updateStatutVente(int venteId, String nouveauStatut) {
        String requete = "UPDATE vente SET statut = ? WHERE id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setString(1, nouveauStatut);
            pstmt.setInt(2, venteId);
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException exp) {
            System.out.println("Erreur mise à jour statut vente : " + exp.getMessage());
            return false;
        }
    }

    public static boolean annulerVente(int venteId) {
        // Récupérer d'abord l'ID du véhicule
        String requeteVehicule = "SELECT vehicule_id FROM vente WHERE id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requeteVehicule);
            pstmt.setInt(1, venteId);
            ResultSet rs = pstmt.executeQuery();
            
            if(rs.next()) {
                int vehiculeId = rs.getInt("vehicule_id");
                // Mettre à jour le statut de la vente
                if(updateStatutVente(venteId, "ANNULEE")) {
                    // Remettre le véhicule comme disponible
                    return updateDisponibiliteVehicule(vehiculeId, true);
                }
            }
        } catch(SQLException exp) {
            System.out.println("Erreur annulation vente : " + exp.getMessage());
        }
        return false;
    }

    private static boolean updateDisponibiliteVehicule(int vehiculeId, boolean disponible) {
        String requete = "UPDATE vehicule SET disponible = ? WHERE id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setBoolean(1, disponible);
            pstmt.setInt(2, vehiculeId);
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException exp) {
            System.out.println("Erreur mise à jour disponibilité véhicule : " + exp.getMessage());
            return false;
        }
    }
    
    public static boolean supprimerVente(int venteId) {
        Connection conn = Connexion.getInstance().getMaConnexion();
        boolean success = false;
        
        try {
            // Désactiver l'autocommit pour garantir l'atomicité de l'opération
            conn.setAutoCommit(false);
            
            // Récupérer l'ID du véhicule associé à la vente
            int vehiculeId = -1;
            String requeteVehicule = "SELECT vehicule_id FROM vente WHERE id = ?;";
            PreparedStatement pstmtVehicule = conn.prepareStatement(requeteVehicule);
            pstmtVehicule.setInt(1, venteId);
            ResultSet rs = pstmtVehicule.executeQuery();
            
            if(rs.next()) {
                vehiculeId = rs.getInt("vehicule_id");
                
                // Supprimer la vente
                String requete = "DELETE FROM vente WHERE id = ?;";
                PreparedStatement pstmt = conn.prepareStatement(requete);
                pstmt.setInt(1, venteId);
                
                boolean venteSupprimee = pstmt.executeUpdate() > 0;
                
                // Si la vente a été supprimée, vérifier s'il y a d'autres locations/ventes actives pour ce véhicule
                if(venteSupprimee && vehiculeId > 0) {
                    boolean estUtilise = false;
                    
                    // Vérifier les locations actives
                    String requeteLocations = "SELECT COUNT(*) as nb FROM location WHERE vehicule_id = ? AND statut NOT IN ('ANNULEE', 'TERMINEE');";
                    PreparedStatement pstmtLocations = conn.prepareStatement(requeteLocations);
                    pstmtLocations.setInt(1, vehiculeId);
                    ResultSet rsLocations = pstmtLocations.executeQuery();
                    
                    if(rsLocations.next() && rsLocations.getInt("nb") > 0) {
                        estUtilise = true;
                    }
                    
                    // Vérifier les ventes actives
                    String requeteVentes = "SELECT COUNT(*) as nb FROM vente WHERE vehicule_id = ? AND statut NOT IN ('ANNULEE');";
                    PreparedStatement pstmtVentes = conn.prepareStatement(requeteVentes);
                    pstmtVentes.setInt(1, vehiculeId);
                    ResultSet rsVentes = pstmtVentes.executeQuery();
                    
                    if(rsVentes.next() && rsVentes.getInt("nb") > 0) {
                        estUtilise = true;
                    }
                    
                    // Si le véhicule n'est plus utilisé, le marquer comme disponible
                    if(!estUtilise) {
                        String requeteDisponibilite = "UPDATE vehicule SET disponible = true WHERE id = ?;";
                        PreparedStatement pstmtDisponibilite = conn.prepareStatement(requeteDisponibilite);
                        pstmtDisponibilite.setInt(1, vehiculeId);
                        pstmtDisponibilite.executeUpdate();
                    }
                    
                    success = true;
                }
            }
            
            if(success) {
                conn.commit();
            } else {
                conn.rollback();
            }
            
        } catch(SQLException exp) {
            try {
                conn.rollback();
            } catch(SQLException e) {
                System.out.println("Erreur rollback : " + e.getMessage());
            }
            System.out.println("Erreur suppression vente : " + exp.getMessage());
            success = false;
        } finally {
            try {
                conn.setAutoCommit(true);
            } catch(SQLException e) {
                System.out.println("Erreur reset autocommit : " + e.getMessage());
            }
        }
        
        return success;
    }

    public static ArrayList<Vente> getAllVentes() {
        ArrayList<Vente> ventes = new ArrayList<>();
        String requete = "SELECT v.*, u.nom, u.prenom, vh.modele FROM vente v " +
                        "JOIN utilisateur u ON v.utilisateur_id = u.id " +
                        "JOIN vehicule vh ON v.vehicule_id = vh.id " +
                        "ORDER BY v.date_vente DESC;";
        
        try {
            Statement stmt = connexion.createStatement();
            ResultSet rs = stmt.executeQuery(requete);
            
            while(rs.next()) {
                Vente vente = new Vente(
                    rs.getInt("id"),
                    rs.getInt("utilisateur_id"),
                    rs.getInt("vehicule_id"),
                    rs.getBigDecimal("prix_vente"),
                    rs.getTimestamp("date_vente"),
                    rs.getString("statut")
                );
                // Ajouter les informations complémentaires
                vente.setNomUtilisateur(rs.getString("prenom") + " " + rs.getString("nom"));
                vente.setModeleVehicule(rs.getString("modele"));
                ventes.add(vente);
            }
        } catch(SQLException exp) {
            System.out.println("Erreur récupération ventes : " + exp.getMessage());
        }
        return ventes;
    }

    public static BigDecimal calculerMontantTotal(ArrayList<Integer> vehiculeIds) {
        BigDecimal total = BigDecimal.ZERO;
        String requete = "SELECT prix_vente FROM vehicule WHERE id = ?;";
        
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            for(Integer vehiculeId : vehiculeIds) {
                pstmt.setInt(1, vehiculeId);
                ResultSet rs = pstmt.executeQuery();
                if(rs.next()) {
                    total = total.add(rs.getBigDecimal("prix_vente"));
                }
            }
        } catch(SQLException exp) {
            System.out.println("Erreur calcul montant total : " + exp.getMessage());
        }
        return total;
    }
}