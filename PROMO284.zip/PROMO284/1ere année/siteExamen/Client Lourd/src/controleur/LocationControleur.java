package controleur;

import modele.bdd.Connexion;
import modele.entites.Location;
import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.math.BigDecimal;

public class LocationControleur {
    private static Connection connexion = Connexion.getInstance().getMaConnexion();

    public static boolean creerLocation(Location location) {
        // Si le statut n'est pas défini, le définir à CONFIRMEE car le paiement a été effectué
        if ("EN_ATTENTE".equals(location.getStatut())) {
            location.setStatut("CONFIRMEE");
        }
        
        String requete = "INSERT INTO location (utilisateur_id, vehicule_id, date_debut, " +
                        "date_fin, prix_total, statut) VALUES (?, ?, ?, ?, ?, ?);";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, location.getUtilisateurId());
            pstmt.setInt(2, location.getVehiculeId());
            pstmt.setDate(3, new java.sql.Date(location.getDateDebut().getTime()));
            pstmt.setDate(4, new java.sql.Date(location.getDateFin().getTime()));
            pstmt.setBigDecimal(5, location.getPrixTotal());
            pstmt.setString(6, location.getStatut());
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException exp) {
            System.out.println("Erreur création location : " + exp.getMessage());
            exp.printStackTrace();
            return false;
        }
    }

    public static ArrayList<Location> getLocationsUtilisateur(int utilisateurId) {
        ArrayList<Location> locations = new ArrayList<>();
        String requete = "SELECT * FROM location WHERE utilisateur_id = ?;";
        
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, utilisateurId);
            ResultSet rs = pstmt.executeQuery();
            
            while(rs.next()) {
                Location location = new Location(
                    rs.getInt("id"),
                    rs.getInt("utilisateur_id"),
                    rs.getInt("vehicule_id"),
                    rs.getDate("date_debut"),
                    rs.getDate("date_fin"),
                    rs.getString("statut"),
                    rs.getTimestamp("date_creation")
                );
                locations.add(location);
            }
        } catch(SQLException exp) {
            System.out.println("Erreur récupération locations : " + exp.getMessage());
        }
        return locations;
    }

    public static boolean updateStatutLocation(int locationId, String nouveauStatut) {
        String requete = "UPDATE location SET statut = ? WHERE id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setString(1, nouveauStatut);
            pstmt.setInt(2, locationId);
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException exp) {
            System.out.println("Erreur mise à jour statut location : " + exp.getMessage());
            return false;
        }
    }

    public static boolean annulerLocation(int locationId) {
        return updateStatutLocation(locationId, "ANNULEE");
    }
    
    public static boolean supprimerLocation(int locationId) {
        Connection conn = Connexion.getInstance().getMaConnexion();
        boolean success = false;
        
        try {
            // Désactiver l'autocommit pour garantir l'atomicité de l'opération
            conn.setAutoCommit(false);
            
            // Récupérer l'ID du véhicule associé à la location
            int vehiculeId = -1;
            String requeteVehicule = "SELECT vehicule_id FROM location WHERE id = ?;";
            PreparedStatement pstmtVehicule = conn.prepareStatement(requeteVehicule);
            pstmtVehicule.setInt(1, locationId);
            ResultSet rs = pstmtVehicule.executeQuery();
            
            if(rs.next()) {
                vehiculeId = rs.getInt("vehicule_id");
                
                // Supprimer la location
                String requete = "DELETE FROM location WHERE id = ?;";
                PreparedStatement pstmt = conn.prepareStatement(requete);
                pstmt.setInt(1, locationId);
                
                boolean locationSupprimee = pstmt.executeUpdate() > 0;
                
                // Si la location a été supprimée, vérifier s'il y a d'autres locations/ventes actives pour ce véhicule
                if(locationSupprimee && vehiculeId > 0) {
                    boolean estUtilise = false;
                    
                    // Vérifier les locations actives
                    String requeteLocations = "SELECT COUNT(*) as nb FROM location WHERE vehicule_id = ? AND statut NOT IN ('ANNULEE', 'TERMINEE');";
                    PreparedStatement pstmtLocations = conn.prepareStatement(requeteLocations);
                    pstmtLocations.setInt(1, vehiculeId);
                    ResultSet rsLocations = pstmtLocations.executeQuery();
                    
                    if(rsLocations.next() && rsLocations.getInt("nb") > 0) {
                        estUtilise = true;
                    }
                    
                    // Vérifier les ventes actives
                    String requeteVentes = "SELECT COUNT(*) as nb FROM vente WHERE vehicule_id = ? AND statut NOT IN ('ANNULEE');";
                    PreparedStatement pstmtVentes = conn.prepareStatement(requeteVentes);
                    pstmtVentes.setInt(1, vehiculeId);
                    ResultSet rsVentes = pstmtVentes.executeQuery();
                    
                    if(rsVentes.next() && rsVentes.getInt("nb") > 0) {
                        estUtilise = true;
                    }
                    
                    // Si le véhicule n'est plus utilisé, le marquer comme disponible
                    if(!estUtilise) {
                        String requeteDisponibilite = "UPDATE vehicule SET disponible = true WHERE id = ?;";
                        PreparedStatement pstmtDisponibilite = conn.prepareStatement(requeteDisponibilite);
                        pstmtDisponibilite.setInt(1, vehiculeId);
                        pstmtDisponibilite.executeUpdate();
                    }
                    
                    success = true;
                }
            }
            
            if(success) {
                conn.commit();
            } else {
                conn.rollback();
            }
            
        } catch(SQLException exp) {
            try {
                conn.rollback();
            } catch(SQLException e) {
                System.out.println("Erreur rollback : " + e.getMessage());
            }
            System.out.println("Erreur suppression location : " + exp.getMessage());
            success = false;
        } finally {
            try {
                conn.setAutoCommit(true);
            } catch(SQLException e) {
                System.out.println("Erreur reset autocommit : " + e.getMessage());
            }
        }
        
        return success;
    }

    public static ArrayList<Location> getAllLocations() {
        ArrayList<Location> locations = new ArrayList<>();
        String requete = "SELECT l.*, u.nom, u.prenom, v.modele FROM location l " +
                        "JOIN utilisateur u ON l.utilisateur_id = u.id " +
                        "JOIN vehicule v ON l.vehicule_id = v.id " +
                        "ORDER BY l.date_creation DESC;";
        
        try {
            Statement stmt = connexion.createStatement();
            ResultSet rs = stmt.executeQuery(requete);
            
            while(rs.next()) {
                Location location = new Location(
                    rs.getInt("id"),
                    rs.getInt("utilisateur_id"),
                    rs.getInt("vehicule_id"),
                    rs.getDate("date_debut"),
                    rs.getDate("date_fin"),
                    rs.getString("statut"),
                    rs.getTimestamp("date_creation")
                );
                // Ajouter les informations complémentaires
                location.setNomUtilisateur(rs.getString("prenom") + " " + rs.getString("nom"));
                location.setModeleVehicule(rs.getString("modele"));
                locations.add(location);
            }
        } catch(SQLException exp) {
            System.out.println("Erreur récupération locations : " + exp.getMessage());
        }
        return locations;
    }

    public static boolean verifierDisponibilite(int vehiculeId, Date dateDebut, Date dateFin) {
        // Vérifier d'abord si le véhicule est marqué comme disponible
        boolean vehiculeDisponible = false;
        try {
            String requeteVehicule = "SELECT disponible FROM vehicule WHERE id = ?;";
            PreparedStatement pstmtVehicule = connexion.prepareStatement(requeteVehicule);
            pstmtVehicule.setInt(1, vehiculeId);
            ResultSet rsVehicule = pstmtVehicule.executeQuery();
            
            if(rsVehicule.next()) {
                vehiculeDisponible = rsVehicule.getBoolean("disponible");
            }
            
            rsVehicule.close();
            pstmtVehicule.close();
            
            // Si le véhicule n'est pas disponible, inutile de continuer
            if(!vehiculeDisponible) {
                return false;
            }
        } catch(SQLException exp) {
            System.out.println("Erreur vérification disponibilité véhicule : " + exp.getMessage());
            return false;
        }
        
        // Ensuite, vérifier les réservations existantes
        String requete = "SELECT COUNT(*) as nb FROM location " +
                        "WHERE vehicule_id = ? AND statut NOT IN ('ANNULEE', 'TERMINEE') " +
                        "AND ((date_debut BETWEEN ? AND ?) OR (date_fin BETWEEN ? AND ?));";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, vehiculeId);
            pstmt.setDate(2, new java.sql.Date(dateDebut.getTime()));
            pstmt.setDate(3, new java.sql.Date(dateFin.getTime()));
            pstmt.setDate(4, new java.sql.Date(dateDebut.getTime()));
            pstmt.setDate(5, new java.sql.Date(dateFin.getTime()));
            
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()) {
                return rs.getInt("nb") == 0;
            }
        } catch(SQLException exp) {
            System.out.println("Erreur vérification disponibilité : " + exp.getMessage());
        }
        return false;
    }
}