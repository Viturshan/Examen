package controleur;

import vue.principal.VueConnexion;

public class Epeugeot {
    private static VueConnexion vueConnexion;
    
    public static void main(String[] args) {
        try {
            // Configuration de l'apparence
            javax.swing.UIManager.setLookAndFeel(
                javax.swing.UIManager.getSystemLookAndFeelClassName()
            );
            
            // Lancement de l'application
            vueConnexion = new VueConnexion();
            vueConnexion.setVisible(true);
            
        } catch (Exception e) {
            System.err.println("Erreur au lancement : " + e.getMessage());
            e.printStackTrace();
        }
    }
}