package controleur;

import modele.bdd.Connexion;
import modele.entites.Vehicule;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.Date;

import java.util.List;
import java.util.Scanner;

public class VehiculeControleur {
    private static Connection connexion = Connexion.getInstance().getMaConnexion();

    public static ArrayList<Vehicule> selectAllVehicules() {
        ArrayList<Vehicule> lesVehicules = new ArrayList<>();
        String requete = "SELECT * FROM vehicule;";
        
        try {
            Statement stmt = connexion.createStatement();
            ResultSet rs = stmt.executeQuery(requete);
            
            while(rs.next()) {
                Vehicule unVehicule = new Vehicule(
                    rs.getInt("id"),
                    rs.getString("marque"),
                    rs.getString("reference"),
                    rs.getString("modele"),
                    rs.getString("description"),
                    rs.getInt("annee"),
                    rs.getInt("kilometrage"),
                    rs.getBigDecimal("prix_vente"),
                    rs.getBigDecimal("prix_location_jour"),
                    rs.getBoolean("disponible"),
                    rs.getInt("categorie_id"),
                    rs.getString("images")
                );
                lesVehicules.add(unVehicule);
            }
            stmt.close();
        } catch(SQLException exp) {
            System.out.println("Erreur execution requête : " + requete);
            exp.printStackTrace();
        }
        return lesVehicules;
    }
    
    public static Vehicule getVehiculeById(int id) {
        String requete = "SELECT * FROM vehicule WHERE id = ?;";
        
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            
            if(rs.next()) {
                Vehicule vehicule = new Vehicule(
                    rs.getInt("id"),
                    rs.getString("marque"),
                    rs.getString("reference"),
                    rs.getString("modele"),
                    rs.getString("description"),
                    rs.getInt("annee"),
                    rs.getInt("kilometrage"),
                    rs.getBigDecimal("prix_vente"),
                    rs.getBigDecimal("prix_location_jour"),
                    rs.getBoolean("disponible"),
                    rs.getInt("categorie_id"),
                    rs.getString("images")
                );
                pstmt.close();
                return vehicule;
            }
        } catch(SQLException exp) {
            System.out.println("Erreur récupération véhicule par ID : " + exp.getMessage());
            exp.printStackTrace();
        }
        return null;
    }
    
    public static ArrayList<Vehicule> getDerniersVehicules(int nbVehicule) {
        ArrayList<Vehicule> lesVehicules = new ArrayList<>();
        String requete = "SELECT * FROM vehicule ORDER BY date_ajout DESC;";
        
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            ResultSet rs = pstmt.executeQuery();
            
            int i=0;
            while(rs.next() && i<nbVehicule) {
                Vehicule unVehicule = new Vehicule(
                    rs.getInt("id"),
                    rs.getString("marque"),
                    rs.getString("reference"),
                    rs.getString("modele"),
                    rs.getString("description"),
                    rs.getInt("annee"),
                    rs.getInt("kilometrage"),
                    rs.getBigDecimal("prix_vente"),
                    rs.getBigDecimal("prix_location_jour"),
                    rs.getBoolean("disponible"),
                    rs.getInt("categorie_id"),
                    rs.getString("images")
                );
                i++;
                lesVehicules.add(unVehicule);
            }
            pstmt.close();
        } catch(SQLException exp) {
            System.out.println("Erreur execution requête : " + requete);
            exp.printStackTrace();
        }
        return lesVehicules;
    }

    public static ArrayList<Vehicule> selectByCategorie(int categorieId) {
        ArrayList<Vehicule> lesVehicules = new ArrayList<>();
        String requete = "SELECT * FROM vehicule WHERE categorie_id = ?;";
        
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, categorieId);
            ResultSet rs = pstmt.executeQuery();
            
            while(rs.next()) {
                Vehicule unVehicule = new Vehicule(
                    rs.getInt("id"),
                    rs.getString("marque"),
                    rs.getString("reference"),
                    rs.getString("modele"),
                    rs.getString("description"),
                    rs.getInt("annee"),
                    rs.getInt("kilometrage"),
                    rs.getBigDecimal("prix_vente"),
                    rs.getBigDecimal("prix_location_jour"),
                    rs.getBoolean("disponible"),
                    rs.getInt("categorie_id"),
                    rs.getString("images")
                );
                lesVehicules.add(unVehicule);
            }
            pstmt.close();
        } catch(SQLException exp) {
            System.out.println("Erreur execution requête : " + requete);
            exp.printStackTrace();
        }
        return lesVehicules;
    }

    public static boolean insertVehicule(Vehicule unVehicule) {
        String requete = "INSERT INTO vehicule (marque,reference, modele, description, annee, " +
                        "kilometrage, prix_vente, prix_location_jour, categorie_id, disponible) " +
                        "VALUES (?,?, ?, ?, ?, ?, ?, ?, ?, ?);";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setString(1, unVehicule.getMarque());
            pstmt.setString(1, unVehicule.getReference());
            pstmt.setString(2, unVehicule.getModele());
            pstmt.setString(3, unVehicule.getDescription());
            pstmt.setInt(4, unVehicule.getAnnee());
            pstmt.setInt(5, unVehicule.getKilometrage());
            pstmt.setBigDecimal(6, unVehicule.getPrixVente());
            pstmt.setBigDecimal(7, unVehicule.getPrixLocationJour());
            pstmt.setInt(8, unVehicule.getCategorieId());
            pstmt.setBoolean(9, true); // Le véhicule est disponible par défaut
            
            int result = pstmt.executeUpdate();
            System.out.println("Résultat de l'insertion : " + result + " ligne(s) affectée(s)");
            
            return result > 0;
        } catch(SQLException exp) {
            System.out.println("Erreur execution requête : " + requete);
            System.out.println("Message d'erreur SQL : " + exp.getMessage());
            System.out.println("État SQL : " + exp.getSQLState());
            System.out.println("Code d'erreur : " + exp.getErrorCode());
            exp.printStackTrace();
            return false;
        }
    }

    public static boolean updateDisponibilite(int vehiculeId, boolean disponible) {
        String requete = "UPDATE vehicule SET disponible = ? WHERE id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setBoolean(1, disponible);
            pstmt.setInt(2, vehiculeId);
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException exp) {
            System.out.println("Erreur mise à jour disponibilité : " + exp.getMessage());
            exp.printStackTrace();
            return false;
        }
    }
    public class Main {
        public static void main(String[] args) {
            // Créer une liste de véhicules 
            List<Vehicule> vehicules = new ArrayList<>();
            vehicules.add(new Vehicule("Toyota", "Corolla"));
            vehicules.add(new Vehicule("Toyota", "Camry"));
            vehicules.add(new Vehicule("Honda", "Civic"));
            vehicules.add(new Vehicule("Honda", "Accord"));
            vehicules.add(new Vehicule("Ford", "Mustang"));
            vehicules.add(new Vehicule("Ford", "F-150"));
            vehicules.add(new Vehicule("Chevrolet", "Camaro"));
            vehicules.add(new Vehicule("Chevrolet", "Silverado"));
            vehicules.add(new Vehicule("Nissan", "Altima"));
            vehicules.add(new Vehicule("Nissan", "Rogue"));

            // Afficher les marques disponibles
            System.out.println("Choisissez une marque de véhicule:");
            System.out.println("1. Toyota");
            System.out.println("2. Honda");
            System.out.println("3. Ford");
            System.out.println("4. Chevrolet");
            System.out.println("5. Nissan");

            // Lire le choix de l'utilisateur
            Scanner scanner = new Scanner(System.in);
            int choix = scanner.nextInt();

            // Déterminer la marque choisie
            String marqueChoisie = "";
            switch (choix) {
                case 1:
                    marqueChoisie = "Toyota";
                    break;
                case 2:
                    marqueChoisie = "Honda";
                    break;
                case 3:
                    marqueChoisie = "Ford";
                    break;
                case 4:
                    marqueChoisie = "Chevrolet";
                    break;
                case 5:
                    marqueChoisie = "Nissan";
                    break;
                default:
                    System.out.println("Choix invalide.");
                    return;
            }

            // Afficher les véhicules de la marque choisie
            System.out.println("Véhicules de la marque " + marqueChoisie + ":");
            for (Vehicule v : vehicules) {
                if (v.getMarque().equals(marqueChoisie)) {
                    System.out.println(v);
                }
            }
        }
    }
}