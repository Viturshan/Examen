package controleur;

import modele.bdd.Connexion;
import modele.entites.Panier;
import modele.entites.Vehicule;
import modele.entites.Location;
import modele.entites.Vente;
import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.math.BigDecimal;
import controleur.LocationControleur;
import controleur.VehiculeControleur;
import controleur.VenteControleur;

public class PanierControleur {
    private static Connection connexion = Connexion.getInstance().getMaConnexion();

    public static boolean ajouterAuPanier(Panier panier) {
        String requete = "INSERT INTO panier (utilisateur_id, vehicule_id, type, date_debut, date_fin) " +
                        "VALUES (?, ?, ?, ?, ?);";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, panier.getUtilisateurId());
            pstmt.setInt(2, panier.getVehiculeId());
            pstmt.setString(3, panier.getType());
            
            if(panier.getType().equals("LOCATION")) {
                pstmt.setDate(4, new java.sql.Date(panier.getDateDebut().getTime()));
                pstmt.setDate(5, new java.sql.Date(panier.getDateFin().getTime()));
            } else {
                pstmt.setNull(4, java.sql.Types.DATE);
                pstmt.setNull(5, java.sql.Types.DATE);
            }
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException exp) {
            System.out.println("Erreur ajout au panier : " + exp.getMessage());
            return false;
        }
    }

    public static ArrayList<Panier> getPanierUtilisateur(int utilisateurId) {
        ArrayList<Panier> panier = new ArrayList<>();
        String requete = "SELECT p.*, v.* FROM panier p " +
                        "JOIN vehicule v ON p.vehicule_id = v.id " +
                        "WHERE p.utilisateur_id = ?;";
        
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, utilisateurId);
            ResultSet rs = pstmt.executeQuery();
            
            while(rs.next()) {
                Panier item = new Panier(
                    rs.getInt("id"),
                    rs.getInt("utilisateur_id"),
                    rs.getInt("vehicule_id"),
                    rs.getString("type"),
                    rs.getTimestamp("date_ajout"),
                    rs.getDate("date_debut"),
                    rs.getDate("date_fin")
                );
                panier.add(item);
            }
        } catch(SQLException exp) {
            System.out.println("Erreur récupération panier : " + exp.getMessage());
        }
        return panier;
    }

    public static boolean supprimerDuPanier(int panierId) {
        String requete = "DELETE FROM panier WHERE id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, panierId);
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException exp) {
            System.out.println("Erreur suppression du panier : " + exp.getMessage());
            return false;
        }
    }
  

    public static boolean viderPanier(int utilisateurId) {
        String requete = "DELETE FROM panier WHERE utilisateur_id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, utilisateurId);
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException exp) {
            System.out.println("Erreur vidage du panier : " + exp.getMessage());
            return false;
        }
    }

    public static boolean validerPanier(int utilisateurId) {
        ArrayList<Panier> panier = getPanierUtilisateur(utilisateurId);
        boolean succes = true;
        
        for(Panier item : panier) {
            if(item.getType().equals("LOCATION")) {
                // Créer une location
                LocationControleur.creerLocation(
                    new modele.entites.Location(
                        item.getUtilisateurId(),
                        item.getVehiculeId(),
                        item.getDateDebut(),
                        item.getDateFin()
                    )
                );
            } else {
                // Créer une vente
                VenteControleur.creerVente(
                    new modele.entites.Vente(
                        item.getUtilisateurId(),
                        item.getVehiculeId(),
                        item.getPrixVente()
                    )
                );
            }
        }
        
        if(succes) {
            return viderPanier(utilisateurId);
        }
        return false;
    }
    
    /**
     * Valide les achats sélectionnés dans le panier
     * @param itemsId Liste des IDs des éléments du panier à valider
     * @param utilisateurId ID de l'utilisateur
     * @return true si tous les achats ont été validés avec succès
     */
    public static boolean validerAchats(ArrayList<Integer> itemsId, int utilisateurId) {
        boolean succes = true;
        Connection conn = Connexion.getInstance().getMaConnexion();
        
        try {
            // Désactiver l'autocommit pour assurer l'atomicité de l'opération
            conn.setAutoCommit(false);
            
            // Pour chaque article
            for (Integer itemId : itemsId) {
                // 1. Récupérer l'information du panier
                String requetePanier = "SELECT vehicule_id FROM panier WHERE id = ?;";
                PreparedStatement pstmtPanier = conn.prepareStatement(requetePanier);
                pstmtPanier.setInt(1, itemId);
                ResultSet rsPanier = pstmtPanier.executeQuery();
                
                if (rsPanier.next()) {
                    int vehiculeId = rsPanier.getInt("vehicule_id");
                    
                    // 2. Récupérer les informations du véhicule
                    String requeteVehicule = "SELECT prix_vente FROM vehicule WHERE id = ?;";
                    PreparedStatement pstmtVehicule = conn.prepareStatement(requeteVehicule);
                    pstmtVehicule.setInt(1, vehiculeId);
                    ResultSet rsVehicule = pstmtVehicule.executeQuery();
                    
                    if (rsVehicule.next()) {
                        BigDecimal prixVente = rsVehicule.getBigDecimal("prix_vente");
                        
                        // 3. Créer une vente
                        Vente vente = new Vente(utilisateurId, vehiculeId, prixVente);
                        if (!VenteControleur.creerVente(vente)) {
                            succes = false;
                            break;
                        }
                        
                        // 4. Supprimer l'élément du panier
                        if (!supprimerDuPanier(itemId)) {
                            succes = false;
                            break;
                        }
                    } else {
                        succes = false;
                        break;
                    }
                    
                    rsVehicule.close();
                    pstmtVehicule.close();
                } else {
                    succes = false;
                    break;
                }
                
                rsPanier.close();
                pstmtPanier.close();
            }
            
            if (succes) {
                conn.commit();
            } else {
                conn.rollback();
            }
            
        } catch (SQLException e) {
            try {
                conn.rollback();
            } catch (SQLException ex) {
                System.out.println("Erreur lors du rollback : " + ex.getMessage());
            }
            succes = false;
            System.out.println("Erreur validation achats : " + e.getMessage());
        } finally {
            try {
                conn.setAutoCommit(true);
            } catch (SQLException e) {
                System.out.println("Erreur reset autocommit : " + e.getMessage());
            }
        }
        
        return succes;
    }

    /**
     * Valide les locations sélectionnées dans le panier
     * @param itemsId Liste des IDs des éléments du panier à valider
     * @param utilisateurId ID de l'utilisateur
     * @return true si toutes les locations ont été validées avec succès
     */
    public static boolean validerLocations(ArrayList<Integer> itemsId, int utilisateurId) {
        System.out.println("Début de validerLocations() dans PanierControleur");
        System.out.println("Nombre d'éléments à valider : " + itemsId.size());
        
        boolean succes = true;
        Connection conn = Connexion.getInstance().getMaConnexion();
        
        try {
            // Désactiver l'autocommit pour assurer l'atomicité de l'opération
            conn.setAutoCommit(false);
            System.out.println("Autocommit désactivé");
            
            // Pour chaque article
            for (Integer itemId : itemsId) {
                System.out.println("Traitement de l'élément panier ID : " + itemId);
                
                // 1. Récupérer l'information du panier
                String requetePanier = "SELECT vehicule_id, date_debut, date_fin FROM panier WHERE id = ?;";
                PreparedStatement pstmtPanier = conn.prepareStatement(requetePanier);
                pstmtPanier.setInt(1, itemId);
                ResultSet rsPanier = pstmtPanier.executeQuery();
                
                if (rsPanier.next()) {
                    int vehiculeId = rsPanier.getInt("vehicule_id");
                    Date dateDebut = rsPanier.getDate("date_debut");
                    Date dateFin = rsPanier.getDate("date_fin");
                    
                    System.out.println("Informations récupérées: vehiculeId=" + vehiculeId + 
                        ", dateDebut=" + dateDebut + ", dateFin=" + dateFin);
                    
                    // 2. Créer une location
                    Location location = new Location(utilisateurId, vehiculeId, dateDebut, dateFin);
                    System.out.println("Location créée, appel de LocationControleur.creerLocation()");
                    
                    if (!LocationControleur.creerLocation(location)) {
                        System.out.println("Erreur lors de la création de la location");
                        succes = false;
                        break;
                    }
                    
                    // 3. Supprimer l'élément du panier
                    System.out.println("Location créée avec succès, suppression de l'élément du panier");
                    if (!supprimerDuPanier(itemId)) {
                        System.out.println("Erreur lors de la suppression de l'élément du panier");
                        succes = false;
                        break;
                    }
                    
                    System.out.println("Élément du panier supprimé avec succès");
                } else {
                    System.out.println("Élément panier non trouvé");
                    succes = false;
                    break;
                }
                
                rsPanier.close();
                pstmtPanier.close();
            }
            
            if (succes) {
                System.out.println("Toutes les opérations ont réussi, commit des transactions");
                conn.commit();
            } else {
                System.out.println("Des erreurs se sont produites, rollback des transactions");
                conn.rollback();
            }
            
        } catch (SQLException e) {
            System.out.println("Exception SQL: " + e.getMessage());
            try {
                conn.rollback();
                System.out.println("Rollback effectué suite à l'exception");
            } catch (SQLException ex) {
                System.out.println("Erreur lors du rollback : " + ex.getMessage());
            }
            succes = false;
        } finally {
            try {
                conn.setAutoCommit(true);
                System.out.println("Autocommit réactivé");
            } catch (SQLException e) {
                System.out.println("Erreur reset autocommit : " + e.getMessage());
            }
        }
        
        System.out.println("Fin de validerLocations(), résultat : " + succes);
        return succes;
    }
}