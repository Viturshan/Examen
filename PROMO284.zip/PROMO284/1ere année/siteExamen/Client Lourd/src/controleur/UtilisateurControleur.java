package controleur;

import modele.bdd.Connexion;
import modele.entites.Utilisateur;
import java.sql.*;

public class UtilisateurControleur {
    private static Connection connexion = Connexion.getInstance().getMaConnexion();

    public static Utilisateur connexionUtilisateur(String email, String motDePasse) {
        String requete = "SELECT * FROM utilisateur WHERE email = ? AND mot_de_passe = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setString(1, email);
            pstmt.setString(2, motDePasse);
            
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()) {
                Utilisateur unUtilisateur = new Utilisateur(
                    rs.getInt("id"),
                    rs.getString("email"),
                    rs.getString("mot_de_passe"),
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    rs.getString("adresse"),
                    rs.getString("telephone"),
                    rs.getString("role")
                );
                pstmt.close();
                return unUtilisateur;
            }
        } catch(SQLException exp) {
            System.out.println("Erreur execution requête : " + requete);
            exp.printStackTrace();
        }
        return null;
    }

    public static boolean insertUtilisateur(Utilisateur unUtilisateur) {
        String requete = "INSERT INTO utilisateur (email, mot_de_passe, nom, prenom, adresse, telephone, role) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?);";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setString(1, unUtilisateur.getEmail());
            pstmt.setString(2, unUtilisateur.getMotDePasse());
            pstmt.setString(3, unUtilisateur.getNom());
            pstmt.setString(4, unUtilisateur.getPrenom());
            pstmt.setString(5, unUtilisateur.getAdresse());
            pstmt.setString(6, unUtilisateur.getTelephone());
            pstmt.setString(7, unUtilisateur.getRole());
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException exp) {
            System.out.println("Erreur execution requête : " + requete);
            exp.printStackTrace();
            return false;
        }
    }

    public static boolean updateUtilisateur(Utilisateur unUtilisateur) {
        String requete = "UPDATE utilisateur SET email = ?, nom = ?, prenom = ?, " +
                        "adresse = ?, telephone = ? WHERE id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setString(1, unUtilisateur.getEmail());
            pstmt.setString(2, unUtilisateur.getNom());
            pstmt.setString(3, unUtilisateur.getPrenom());
            pstmt.setString(4, unUtilisateur.getAdresse());
            pstmt.setString(5, unUtilisateur.getTelephone());
            pstmt.setInt(6, unUtilisateur.getId());
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException exp) {
            System.out.println("Erreur execution requête : " + requete);
            exp.printStackTrace();
            return false;
        }
    }

    public static boolean updateMotDePasse(int userId, String nouveauMotDePasse) {
        String requete = "UPDATE utilisateur SET mot_de_passe = ? WHERE id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setString(1, nouveauMotDePasse);
            pstmt.setInt(2, userId);
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException exp) {
            System.out.println("Erreur execution requête : " + requete);
            exp.printStackTrace();
            return false;
        }
    }
    
    public static boolean verifierMotDePasse(int utilisateurId, String motDePasse) {
        String requete = "SELECT * FROM utilisateur WHERE id = ? AND mot_de_passe = ?;";
        boolean resultat = false;
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, utilisateurId);
            pstmt.setString(2, motDePasse);
            
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()) {
                resultat = true;
            }
            else {
                resultat = false;
            }
            pstmt.close();
        } catch(SQLException exp) {
            System.out.println("Erreur execution requête : " + requete);
            exp.printStackTrace();
        }
        return resultat;
    }
    
    /**
     * Vérifie si un email existe déjà dans la base de données
     * @param email L'email à vérifier
     * @return true si l'email existe déjà
     */
    public static boolean emailExiste(String email) {
        String requete = "SELECT COUNT(*) as nb FROM utilisateur WHERE email = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setString(1, email);
            
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()) {
                return rs.getInt("nb") > 0;
            }
        } catch(SQLException exp) {
            System.out.println("Erreur vérification email : " + exp.getMessage());
        }
        return false;
    }
}