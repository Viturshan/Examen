package modele.dao;

import modele.entites.Vente;
import modele.bdd.Connexion;
import java.sql.*;
import java.util.ArrayList;
import java.math.BigDecimal;

public class VenteDAO {
    private Connection connexion;

    public VenteDAO() {
        this.connexion = Connexion.getInstance().getMaConnexion();
    }

    public boolean create(Vente vente) {
        String requete = "INSERT INTO vente (utilisateur_id, vehicule_id, prix_vente, statut) " +
                        "VALUES (?, ?, ?, ?);";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, vente.getUtilisateurId());
            pstmt.setInt(2, vente.getVehiculeId());
            pstmt.setBigDecimal(3, vente.getPrixVente());
            pstmt.setString(4, vente.getStatut());
            
            boolean resultat = pstmt.executeUpdate() > 0;
            if (resultat) {
                // Mettre à jour le statut du véhicule
                updateDisponibiliteVehicule(vente.getVehiculeId(), false);
            }
            return resultat;
        } catch(SQLException e) {
            System.out.println("Erreur création vente : " + e.getMessage());
            return false;
        }
    }

    public Vente read(int id) {
        String requete = "SELECT * FROM vente WHERE id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, id);
            
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()) {
                return new Vente(
                    rs.getInt("id"),
                    rs.getInt("utilisateur_id"),
                    rs.getInt("vehicule_id"),
                    rs.getBigDecimal("prix_vente"),
                    rs.getTimestamp("date_vente"),
                    rs.getString("statut")
                );
            }
        } catch(SQLException e) {
            System.out.println("Erreur lecture vente : " + e.getMessage());
        }
        return null;
    }

    public ArrayList<Vente> findByUtilisateur(int utilisateurId) {
        ArrayList<Vente> ventes = new ArrayList<>();
        String requete = "SELECT v.*, vh.modele FROM vente v " +
                        "JOIN vehicule vh ON v.vehicule_id = vh.id " +
                        "WHERE v.utilisateur_id = ? ORDER BY v.date_vente DESC;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, utilisateurId);
            
            ResultSet rs = pstmt.executeQuery();
            while(rs.next()) {
                Vente vente = new Vente(
                    rs.getInt("id"),
                    rs.getInt("utilisateur_id"),
                    rs.getInt("vehicule_id"),
                    rs.getBigDecimal("prix_vente"),
                    rs.getTimestamp("date_vente"),
                    rs.getString("statut")
                );
                vente.setModeleVehicule(rs.getString("modele")); // Pour l'affichage
                ventes.add(vente);
            }
        } catch(SQLException e) {
            System.out.println("Erreur recherche ventes utilisateur : " + e.getMessage());
        }
        return ventes;
    }

    public boolean updateStatut(int venteId, String nouveauStatut) {
        String requete = "UPDATE vente SET statut = ? WHERE id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setString(1, nouveauStatut);
            pstmt.setInt(2, venteId);
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException e) {
            System.out.println("Erreur mise à jour statut : " + e.getMessage());
            return false;
        }
    }

    public boolean annulerVente(int venteId) {
        try {
            connexion.setAutoCommit(false);
            
            // Récupérer l'ID du véhicule
            int vehiculeId = -1;
            String requeteVehicule = "SELECT vehicule_id FROM vente WHERE id = ?;";
            PreparedStatement pstmtVehicule = connexion.prepareStatement(requeteVehicule);
            pstmtVehicule.setInt(1, venteId);
            ResultSet rs = pstmtVehicule.executeQuery();
            if(rs.next()) {
                vehiculeId = rs.getInt("vehicule_id");
            }

            if(vehiculeId != -1) {
                // Mettre à jour le statut de la vente
                if(updateStatut(venteId, "ANNULEE")) {
                    // Remettre le véhicule comme disponible
                    if(updateDisponibiliteVehicule(vehiculeId, true)) {
                        connexion.commit();
                        return true;
                    }
                }
            }
            
            connexion.rollback();
            return false;
        } catch(SQLException e) {
            try {
                connexion.rollback();
            } catch(SQLException ex) {
                System.out.println("Erreur rollback : " + ex.getMessage());
            }
            System.out.println("Erreur annulation vente : " + e.getMessage());
            return false;
        } finally {
            try {
                connexion.setAutoCommit(true);
            } catch(SQLException e) {
                System.out.println("Erreur reset autocommit : " + e.getMessage());
            }
        }
    }

    private boolean updateDisponibiliteVehicule(int vehiculeId, boolean disponible) {
        String requete = "UPDATE vehicule SET disponible = ? WHERE id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setBoolean(1, disponible);
            pstmt.setInt(2, vehiculeId);
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException e) {
            System.out.println("Erreur mise à jour disponibilité véhicule : " + e.getMessage());
            return false;
        }
    }

    public BigDecimal getChiffreAffairesTotal() {
        String requete = "SELECT SUM(prix_vente) as total FROM vente WHERE statut = 'PAYEE';";
        try {
            Statement stmt = connexion.createStatement();
            ResultSet rs = stmt.executeQuery(requete);
            if(rs.next()) {
                return rs.getBigDecimal("total");
            }
        } catch(SQLException e) {
            System.out.println("Erreur calcul chiffre d'affaires : " + e.getMessage());
        }
        return BigDecimal.ZERO;
    }
}