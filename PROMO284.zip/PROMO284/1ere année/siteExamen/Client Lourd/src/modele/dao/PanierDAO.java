package modele.dao;

import modele.entites.Panier;
import modele.bdd.Connexion;
import java.sql.*;
import java.util.ArrayList;

public class PanierDAO {
    private Connection connexion;

    public PanierDAO() {
        this.connexion = Connexion.getInstance().getMaConnexion();
    }

    public boolean ajouterAuPanier(Panier panier) {
        String requete = "INSERT INTO panier (utilisateur_id, vehicule_id, type, date_debut, date_fin) " +
                        "VALUES (?, ?, ?, ?, ?);";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, panier.getUtilisateurId());
            pstmt.setInt(2, panier.getVehiculeId());
            pstmt.setString(3, panier.getType());
            
            if(panier.getType().equals("LOCATION")) {
                pstmt.setDate(4, new java.sql.Date(panier.getDateDebut().getTime()));
                pstmt.setDate(5, new java.sql.Date(panier.getDateFin().getTime()));
            } else {
                pstmt.setNull(4, java.sql.Types.DATE);
                pstmt.setNull(5, java.sql.Types.DATE);
            }
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException e) {
            System.out.println("Erreur ajout au panier : " + e.getMessage());
            return false;
        }
    }

    public ArrayList<Panier> getPanierUtilisateur(int utilisateurId) {
        ArrayList<Panier> panier = new ArrayList<>();
        String requete = "SELECT p.*, v.modele, v.prix_vente, v.prix_location_jour " +
                        "FROM panier p " +
                        "JOIN vehicule v ON p.vehicule_id = v.id " +
                        "WHERE p.utilisateur_id = ?;";
        
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, utilisateurId);
            ResultSet rs = pstmt.executeQuery();
            
            while(rs.next()) {
                Panier item = new Panier(
                    rs.getInt("id"),
                    rs.getInt("utilisateur_id"),
                    rs.getInt("vehicule_id"),
                    rs.getString("type"),
                    rs.getTimestamp("date_ajout"),
                    rs.getDate("date_debut"),
                    rs.getDate("date_fin")
                );
                // Ajouter les informations du véhicule pour l'affichage
                item.setModeleVehicule(rs.getString("modele"));
                item.setPrixVente(rs.getBigDecimal("prix_vente"));
                item.setPrixLocationJour(rs.getBigDecimal("prix_location_jour"));
                panier.add(item);
            }
        } catch(SQLException e) {
            System.out.println("Erreur récupération panier : " + e.getMessage());
        }
        return panier;
    }

    public boolean supprimerDuPanier(int panierId) {
        String requete = "DELETE FROM panier WHERE id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, panierId);
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException e) {
            System.out.println("Erreur suppression du panier : " + e.getMessage());
            return false;
        }
    }

    public boolean viderPanier(int utilisateurId) {
        String requete = "DELETE FROM panier WHERE utilisateur_id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, utilisateurId);
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException e) {
            System.out.println("Erreur vidage du panier : " + e.getMessage());
            return false;
        }
    }

    public boolean verifierDoublonPanier(int utilisateurId, int vehiculeId) {
        String requete = "SELECT COUNT(*) as nb FROM panier WHERE utilisateur_id = ? AND vehicule_id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, utilisateurId);
            pstmt.setInt(2, vehiculeId);
            
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()) {
                return rs.getInt("nb") > 0;
            }
        } catch(SQLException e) {
            System.out.println("Erreur vérification doublon : " + e.getMessage());
        }
        return false;
    }

    public int getNombreArticles(int utilisateurId) {
        String requete = "SELECT COUNT(*) as nb FROM panier WHERE utilisateur_id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, utilisateurId);
            
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()) {
                return rs.getInt("nb");
            }
        } catch(SQLException e) {
            System.out.println("Erreur comptage articles : " + e.getMessage());
        }
        return 0;
    }
}