package modele.dao;

import modele.entites.Vehicule;
import modele.bdd.Connexion;
import java.sql.*;
import java.util.ArrayList;

public class VehiculeDAO {
    private Connection connexion;

    public VehiculeDAO() {
        this.connexion = Connexion.getInstance().getMaConnexion();
    }

    // Créer un véhicule
    public boolean create(Vehicule vehicule) {
        String requete = "INSERT INTO vehicule (reference,marque, modele, description, annee, " +
                        "kilometrage, prix_vente, prix_location_jour, categorie_id) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setString(1, vehicule.getReference());
            pstmt.setString(2, vehicule.getModele());
            pstmt.setString(3, vehicule.getDescription());
            pstmt.setInt(4, vehicule.getAnnee());
            pstmt.setInt(5, vehicule.getKilometrage());
            pstmt.setBigDecimal(6, vehicule.getPrixVente());
            pstmt.setBigDecimal(7, vehicule.getPrixLocationJour());
            pstmt.setInt(8, vehicule.getCategorieId());
            pstmt.setString(9, vehicule.getMarque());
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException e) {
            System.out.println("Erreur lors de la création du véhicule : " + e.getMessage());
            return false;
        }
    }

    // Lire un véhicule par son ID
    public Vehicule read(int id) {
        String requete = "SELECT * FROM vehicule WHERE id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, id);
            
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()) {
                return new Vehicule(
                    rs.getInt("id"),
                    rs.getString("marque"),
                    rs.getString("reference"),
                    rs.getString("modele"),
                    rs.getString("description"),
                    rs.getInt("annee"),
                    rs.getInt("kilometrage"),
                    rs.getBigDecimal("prix_vente"),
                    rs.getBigDecimal("prix_location_jour"),
                    rs.getBoolean("disponible"),
                    rs.getInt("categorie_id"),
                    rs.getString("images")
                );
            }
        } catch(SQLException e) {
            System.out.println("Erreur lors de la lecture du véhicule : " + e.getMessage());
        }
        return null;
    }

    // Mettre à jour un véhicule
    public boolean update(Vehicule vehicule) {
        String requete = "UPDATE vehicule SET marque = ?,reference = ?, modele = ?, description = ?, " +
                        "annee = ?, kilometrage = ?, prix_vente = ?, prix_location_jour = ?, " +
                        "categorie_id = ? WHERE id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setString(1, vehicule.getReference());
            pstmt.setString(2, vehicule.getModele());
            pstmt.setString(3, vehicule.getDescription());
            pstmt.setInt(4, vehicule.getAnnee());
            pstmt.setInt(5, vehicule.getKilometrage());
            pstmt.setBigDecimal(6, vehicule.getPrixVente());
            pstmt.setBigDecimal(7, vehicule.getPrixLocationJour());
            pstmt.setInt(8, vehicule.getCategorieId());
            pstmt.setInt(9, vehicule.getId());
            pstmt.setString(10, vehicule.getMarque());
            return pstmt.executeUpdate() > 0;
        } catch(SQLException e) {
            System.out.println("Erreur lors de la mise à jour du véhicule : " + e.getMessage());
            return false;
        }
    }

    // Supprimer un véhicule
    public boolean delete(int id) {
        String requete = "DELETE FROM vehicule WHERE id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, id);
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException e) {
            System.out.println("Erreur lors de la suppression du véhicule : " + e.getMessage());
            return false;
        }
    }

    // Lire tous les véhicules
    public ArrayList<Vehicule> readAll() {
        ArrayList<Vehicule> vehicules = new ArrayList<>();
        String requete = "SELECT * FROM vehicule;";
        try {
            Statement stmt = connexion.createStatement();
            ResultSet rs = stmt.executeQuery(requete);
            
            while(rs.next()) {
                vehicules.add(new Vehicule(
                    rs.getInt("id"),
                    rs.getString("marque"),
                    rs.getString("reference"),
                    rs.getString("modele"),
                    rs.getString("description"),
                    rs.getInt("annee"),
                    rs.getInt("kilometrage"),
                    rs.getBigDecimal("prix_vente"),
                    rs.getBigDecimal("prix_location_jour"),
                    rs.getBoolean("disponible"),
                    rs.getInt("categorie_id"),
                    rs.getString("images")
                ));
            }
        } catch(SQLException e) {
            System.out.println("Erreur lors de la lecture des véhicules : " + e.getMessage());
        }
        return vehicules;
    }

    // Méthodes spécifiques
    public ArrayList<Vehicule> findByCategorie(int categorieId) {
        ArrayList<Vehicule> vehicules = new ArrayList<>();
        String requete = "SELECT * FROM vehicule WHERE categorie_id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, categorieId);
            
            ResultSet rs = pstmt.executeQuery();
            while(rs.next()) {
                vehicules.add(new Vehicule(
                    rs.getInt("id"),
                    rs.getString("marque"),
                    rs.getString("reference"),
                    rs.getString("modele"),
                    rs.getString("description"),
                    rs.getInt("annee"),
                    rs.getInt("kilometrage"),
                    rs.getBigDecimal("prix_vente"),
                    rs.getBigDecimal("prix_location_jour"),
                    rs.getBoolean("disponible"),
                    rs.getInt("categorie_id"),
                    rs.getString("images")
                ));
            }
        } catch(SQLException e) {
            System.out.println("Erreur lors de la recherche par catégorie : " + e.getMessage());
        }
        return vehicules;
    }
}