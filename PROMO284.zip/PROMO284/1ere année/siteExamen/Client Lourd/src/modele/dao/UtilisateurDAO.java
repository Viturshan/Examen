package modele.dao;

import modele.entites.Utilisateur;
import modele.bdd.Connexion;
import java.sql.*;
import java.util.ArrayList;

public class UtilisateurDAO {
    private Connection connexion;

    public UtilisateurDAO() {
        this.connexion = Connexion.getInstance().getMaConnexion();
    }

    public boolean create(Utilisateur utilisateur) {
        String requete = "INSERT INTO utilisateur (email, mot_de_passe, nom, prenom, " +
                        "adresse, telephone, role) VALUES (?, ?, ?, ?, ?, ?, ?);";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setString(1, utilisateur.getEmail());
            pstmt.setString(2, utilisateur.getMotDePasse());
            pstmt.setString(3, utilisateur.getNom());
            pstmt.setString(4, utilisateur.getPrenom());
            pstmt.setString(5, utilisateur.getAdresse());
            pstmt.setString(6, utilisateur.getTelephone());
            pstmt.setString(7, utilisateur.getRole());
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException e) {
            System.out.println("Erreur création utilisateur : " + e.getMessage());
            return false;
        }
    }

    public Utilisateur read(int id) {
        String requete = "SELECT * FROM utilisateur WHERE id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, id);
            
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()) {
                return new Utilisateur(
                    rs.getInt("id"),
                    rs.getString("email"),
                    rs.getString("mot_de_passe"),
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    rs.getString("adresse"),
                    rs.getString("telephone"),
                    rs.getString("role")
                );
            }
        } catch(SQLException e) {
            System.out.println("Erreur lecture utilisateur : " + e.getMessage());
        }
        return null;
    }

    public boolean update(Utilisateur utilisateur) {
        String requete = "UPDATE utilisateur SET email = ?, nom = ?, prenom = ?, " +
                        "adresse = ?, telephone = ? WHERE id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setString(1, utilisateur.getEmail());
            pstmt.setString(2, utilisateur.getNom());
            pstmt.setString(3, utilisateur.getPrenom());
            pstmt.setString(4, utilisateur.getAdresse());
            pstmt.setString(5, utilisateur.getTelephone());
            pstmt.setInt(6, utilisateur.getId());
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException e) {
            System.out.println("Erreur mise à jour utilisateur : " + e.getMessage());
            return false;
        }
    }

    public boolean delete(int id) {
        String requete = "DELETE FROM utilisateur WHERE id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, id);
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException e) {
            System.out.println("Erreur suppression utilisateur : " + e.getMessage());
            return false;
        }
    }

    public ArrayList<Utilisateur> readAll() {
        ArrayList<Utilisateur> utilisateurs = new ArrayList<>();
        String requete = "SELECT * FROM utilisateur;";
        try {
            Statement stmt = connexion.createStatement();
            ResultSet rs = stmt.executeQuery(requete);
            
            while(rs.next()) {
                utilisateurs.add(new Utilisateur(
                    rs.getInt("id"),
                    rs.getString("email"),
                    rs.getString("mot_de_passe"),
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    rs.getString("adresse"),
                    rs.getString("telephone"),
                    rs.getString("role")
                ));
            }
        } catch(SQLException e) {
            System.out.println("Erreur lecture utilisateurs : " + e.getMessage());
        }
        return utilisateurs;
    }

    // Méthodes spécifiques
    public Utilisateur findByEmail(String email) {
        String requete = "SELECT * FROM utilisateur WHERE email = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setString(1, email);
            
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()) {
                return new Utilisateur(
                    rs.getInt("id"),
                    rs.getString("email"),
                    rs.getString("mot_de_passe"),
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    rs.getString("adresse"),
                    rs.getString("telephone"),
                    rs.getString("role")
                );
            }
        } catch(SQLException e) {
            System.out.println("Erreur recherche par email : " + e.getMessage());
        }
        return null;
    }

    public boolean updateMotDePasse(int id, String nouveauMotDePasse) {
        String requete = "UPDATE utilisateur SET mot_de_passe = ? WHERE id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setString(1, nouveauMotDePasse);
            pstmt.setInt(2, id);
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException e) {
            System.out.println("Erreur mise à jour mot de passe : " + e.getMessage());
            return false;
        }
    }

    public Utilisateur verifierConnexion(String email, String motDePasse) {
        String requete = "SELECT * FROM utilisateur WHERE email = ? AND mot_de_passe = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setString(1, email);
            pstmt.setString(2, motDePasse);
            
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()) {
                return new Utilisateur(
                    rs.getInt("id"),
                    rs.getString("email"),
                    rs.getString("mot_de_passe"),
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    rs.getString("adresse"),
                    rs.getString("telephone"),
                    rs.getString("role")
                );
            }
        } catch(SQLException e) {
            System.out.println("Erreur vérification connexion : " + e.getMessage());
        }
        return null;
    }
}