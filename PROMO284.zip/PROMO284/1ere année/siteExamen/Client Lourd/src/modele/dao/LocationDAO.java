package modele.dao;

import modele.entites.Location;
import modele.bdd.Connexion;
import java.sql.*;
import java.util.ArrayList;

public class LocationDAO {
    private Connection connexion;

    public LocationDAO() {
        this.connexion = Connexion.getInstance().getMaConnexion();
    }
    
//    public static Connection getConnexion() {
//    	LocationDAO dao = new LocationDAO();
//        return dao.connexion;
//    }

    public boolean create(Location location) {
        String requete = "INSERT INTO location (utilisateur_id, vehicule_id, date_debut, " +
                        "date_fin, prix_total, statut) VALUES (?, ?, ?, ?, ?, ?);";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, location.getUtilisateurId());
            pstmt.setInt(2, location.getVehiculeId());
            pstmt.setDate(3, new java.sql.Date(location.getDateDebut().getTime()));
            pstmt.setDate(4, new java.sql.Date(location.getDateFin().getTime()));
            pstmt.setBigDecimal(5, location.getPrixTotal());
            pstmt.setString(6, location.getStatut());
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException e) {
            System.out.println("Erreur création location : " + e.getMessage());
            return false;
        }
    }
    
    public boolean disponible(int vehiculeid, java.util.Date dateDebut, java.util.Date dateFin) {
//    	Connection connexion = getConnexion();
    	java.sql.Date dateDebutS = new java.sql.Date(dateDebut.getTime());
    	java.sql.Date dateFinS = new java.sql.Date(dateFin.getTime());
    	String requete = "SELECT * FROM location WHERE vehicule_id = ? AND (? between date_debut AND date_fin"+
    					" OR ? between date_debut AND date_fin OR (?<= date_debut AND ?>=date_fin));";
    	boolean sortie = false;
    	try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, vehiculeid);
            pstmt.setDate(2, dateDebutS);
            pstmt.setDate(3, dateFinS);
            pstmt.setDate(4, dateDebutS);
            pstmt.setDate(5, dateFinS);
            
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()) {
            	sortie = false;
            }
            else {
            	sortie = true;
            }
        } catch(SQLException e) {
            System.out.println("Erreur lecture location : " + e.getMessage());
        }
    	return sortie;
    }

    public Location read(int id) {
        String requete = "SELECT * FROM location WHERE id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, id);
            
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()) {
                return new Location(
                    rs.getInt("id"),
                    rs.getInt("utilisateur_id"),
                    rs.getInt("vehicule_id"),
                    rs.getDate("date_debut"),
                    rs.getDate("date_fin"),
                    rs.getString("statut"),
                    rs.getTimestamp("date_creation")
                );
            }
        } catch(SQLException e) {
            System.out.println("Erreur lecture location : " + e.getMessage());
        }
        return null;
    }

    public boolean update(Location location) {
        String requete = "UPDATE location SET date_debut = ?, date_fin = ?, " +
                        "prix_total = ?, statut = ? WHERE id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setDate(1, new java.sql.Date(location.getDateDebut().getTime()));
            pstmt.setDate(2, new java.sql.Date(location.getDateFin().getTime()));
            pstmt.setBigDecimal(3, location.getPrixTotal());
            pstmt.setString(4, location.getStatut());
            pstmt.setInt(5, location.getId());
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException e) {
            System.out.println("Erreur mise à jour location : " + e.getMessage());
            return false;
        }
    }

    public ArrayList<Location> findByUtilisateur(int utilisateurId) {
        ArrayList<Location> locations = new ArrayList<>();
        String requete = "SELECT * FROM location WHERE utilisateur_id = ? ORDER BY date_creation DESC;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, utilisateurId);
            
            ResultSet rs = pstmt.executeQuery();
            while(rs.next()) {
                locations.add(new Location(
                    rs.getInt("id"),
                    rs.getInt("utilisateur_id"),
                    rs.getInt("vehicule_id"),
                    rs.getDate("date_debut"),
                    rs.getDate("date_fin"),
                    rs.getString("statut"),
                    rs.getTimestamp("date_creation")
                ));
            }
        } catch(SQLException e) {
            System.out.println("Erreur recherche locations utilisateur : " + e.getMessage());
        }
        return locations;
    }

    public boolean verifierDisponibilite(int vehiculeId, Date dateDebut, Date dateFin) {
        String requete = "SELECT COUNT(*) as nb FROM location " +
                        "WHERE vehicule_id = ? AND statut NOT IN ('ANNULEE', 'TERMINEE') " +
                        "AND ((date_debut BETWEEN ? AND ?) OR (date_fin BETWEEN ? AND ?));";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setInt(1, vehiculeId);
            pstmt.setDate(2, new java.sql.Date(dateDebut.getTime()));
            pstmt.setDate(3, new java.sql.Date(dateFin.getTime()));
            pstmt.setDate(4, new java.sql.Date(dateDebut.getTime()));
            pstmt.setDate(5, new java.sql.Date(dateFin.getTime()));
            
            ResultSet rs = pstmt.executeQuery();
            if(rs.next()) {
                return rs.getInt("nb") == 0;
            }
        } catch(SQLException e) {
            System.out.println("Erreur vérification disponibilité : " + e.getMessage());
        }
        return false;
    }

    public boolean updateStatut(int locationId, String nouveauStatut) {
        String requete = "UPDATE location SET statut = ? WHERE id = ?;";
        try {
            PreparedStatement pstmt = connexion.prepareStatement(requete);
            pstmt.setString(1, nouveauStatut);
            pstmt.setInt(2, locationId);
            
            return pstmt.executeUpdate() > 0;
        } catch(SQLException e) {
            System.out.println("Erreur mise à jour statut : " + e.getMessage());
            return false;
        }
    }
}