package modele.entites;

import java.util.Date;
import java.math.BigDecimal;
import java.time.temporal.ChronoUnit;
import java.time.LocalDate;
import java.time.ZoneId;


public class Location {
    private int id;
    private int utilisateurId;
    private int vehiculeId;
    private Date dateDebut;
    private Date dateFin;
    private BigDecimal prixTotal;
    private String statut;
    private Date dateCreation;
    
    
    

    // Variables pour l'affichage (non stockées en base)
    private String modeleVehicule;
    private String nomUtilisateur;

    // Constructeur complet
    public Location(int id, int utilisateurId, int vehiculeId, Date dateDebut, 
                   Date dateFin, String statut, Date dateCreation) {
        this.id = id;
        this.utilisateurId = utilisateurId;
        this.vehiculeId = vehiculeId;
        this.dateDebut = dateDebut;
        this.dateFin = dateFin;
        this.prixTotal = CalculPrixTot(vehiculeId, dateDebut, dateFin);
        this.statut = statut;
        this.dateCreation = dateCreation;
        
    }

    // Constructeur pour nouvelle location
    public Location(int utilisateurId, int vehiculeId, Date dateDebut, 
                   Date dateFin) {
        this.utilisateurId = utilisateurId;
        this.vehiculeId = vehiculeId;
        this.dateDebut = dateDebut;
        this.dateFin = dateFin;
        this.prixTotal = CalculPrixTot(vehiculeId, dateDebut, dateFin);
        this.statut = "EN_ATTENTE";
        this.dateCreation = new Date();
    }

    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUtilisateurId() { return utilisateurId; }
    public void setUtilisateurId(int utilisateurId) { this.utilisateurId = utilisateurId; }

    public int getVehiculeId() { return vehiculeId; }
    public void setVehiculeId(int vehiculeId) { this.vehiculeId = vehiculeId; }

    public Date getDateDebut() { return dateDebut; }
    public void setDateDebut(Date dateDebut) { this.dateDebut = dateDebut; }

    public Date getDateFin() { return dateFin; }
    public void setDateFin(Date dateFin) { this.dateFin = dateFin; }

    public BigDecimal getPrixTotal() { return prixTotal; }
    public void setPrixTotal(BigDecimal prixTotal) { this.prixTotal = prixTotal; }

    public String getStatut() { return statut; }
    public void setStatut(String statut) { this.statut = statut; }

    public Date getDateCreation() { return dateCreation; }
    public void setDateCreation(Date dateCreation) { this.dateCreation = dateCreation; }

    public String getModeleVehicule() { return modeleVehicule; }
    public void setModeleVehicule(String modeleVehicule) { this.modeleVehicule = modeleVehicule; }

    public String getNomUtilisateur() { return nomUtilisateur; }
    public void setNomUtilisateur(String nomUtilisateur) { this.nomUtilisateur = nomUtilisateur; }

    // Méthodes utiles
    public int getDureeLocation() {
        long diff = this.dateFin.getTime() - this.dateDebut.getTime();
        return (int) (diff / (1000 * 60 * 60 * 24));
    }

    public boolean isEnCours() {
        Date now = new Date();
        return now.after(this.dateDebut) && now.before(this.dateFin);
    }

    @Override
    public String toString() {
        return "Location{" +
            "id=" + id +
            ", vehicule='" + modeleVehicule + '\'' +
            ", dateDebut=" + dateDebut +
            ", dateFin=" + dateFin +
            ", prixTotal=" + prixTotal +
            ", statut='" + statut + '\'' +
            '}';
    }
    
    
    private static BigDecimal CalculPrixTot(int vehiculeId, Date dateDebut, Date dateFin) {
        // Calculer la différence en millisecondes
        long diffMillis = dateFin.getTime() - dateDebut.getTime();
        
        // Convertir en jours
        long nbJour = diffMillis / (1000 * 60 * 60 * 24);
        
        // Ajouter 1 pour inclure le jour de début
        nbJour = nbJour + 1;
        
        BigDecimal nbJourBd = BigDecimal.valueOf(nbJour);
        modele.entites.Vehicule leVehicule = new modele.dao.VehiculeDAO().read(vehiculeId);
        BigDecimal lePrix = leVehicule.getPrixLocationJour().multiply(nbJourBd);
        return lePrix;
    }
}