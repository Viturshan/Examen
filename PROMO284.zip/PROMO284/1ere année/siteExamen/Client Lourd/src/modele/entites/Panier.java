package modele.entites;

import java.util.Date;
import java.math.BigDecimal;

public class Panier {
    private int id;
    private int utilisateurId;
    private int vehiculeId;
    private String type; // "LOCATION" ou "ACHAT"
    private Date dateAjout;
    private Date dateDebut;  // Pour location uniquement
    private Date dateFin;    // Pour location uniquement

    // Variables pour l'affichage (non stockées en base)
    private String modeleVehicule;
    private BigDecimal prixVente;
    private BigDecimal prixLocationJour;

    // Constructeur complet
    public Panier(int id, int utilisateurId, int vehiculeId, String type,
                 Date dateAjout, Date dateDebut, Date dateFin) {
        this.id = id;
        this.utilisateurId = utilisateurId;
        this.vehiculeId = vehiculeId;
        this.type = type;
        this.dateAjout = dateAjout;
        this.dateDebut = dateDebut;
        this.dateFin = dateFin;
    }

    // Constructeur pour achat
    public Panier(int utilisateurId, int vehiculeId) {
        this.utilisateurId = utilisateurId;
        this.vehiculeId = vehiculeId;
        this.type = "ACHAT";
        this.dateAjout = new Date();
    }

    // Constructeur pour location
    public Panier(int utilisateurId, int vehiculeId, Date dateDebut, Date dateFin) {
        this.utilisateurId = utilisateurId;
        this.vehiculeId = vehiculeId;
        this.type = "LOCATION";
        this.dateAjout = new Date();
        this.dateDebut = dateDebut;
        this.dateFin = dateFin;
    }

    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUtilisateurId() { return utilisateurId; }
    public void setUtilisateurId(int utilisateurId) { this.utilisateurId = utilisateurId; }

    public int getVehiculeId() { return vehiculeId; }
    public void setVehiculeId(int vehiculeId) { this.vehiculeId = vehiculeId; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public Date getDateAjout() { return dateAjout; }
    public void setDateAjout(Date dateAjout) { this.dateAjout = dateAjout; }

    public Date getDateDebut() { return dateDebut; }
    public void setDateDebut(Date dateDebut) { this.dateDebut = dateDebut; }

    public Date getDateFin() { return dateFin; }
    public void setDateFin(Date dateFin) { this.dateFin = dateFin; }

    public String getModeleVehicule() { return modeleVehicule; }
    public void setModeleVehicule(String modeleVehicule) { this.modeleVehicule = modeleVehicule; }

    public BigDecimal getPrixVente() { return prixVente; }
    public void setPrixVente(BigDecimal prixVente) { this.prixVente = prixVente; }

    public BigDecimal getPrixLocationJour() { return prixLocationJour; }
    public void setPrixLocationJour(BigDecimal prixLocationJour) { this.prixLocationJour = prixLocationJour; }

    // Méthodes utiles
    public boolean isLocation() {
        return "LOCATION".equals(this.type);
    }

    public boolean isAchat() {
        return "ACHAT".equals(this.type);
    }

    public int getDureeLocation() {
        if (!isLocation() || dateDebut == null || dateFin == null) {
            return 0;
        }
        long diff = dateFin.getTime() - dateDebut.getTime();
        return (int) (diff / (1000 * 60 * 60 * 24));
    }

    public BigDecimal calculerTotal() {
        if (isAchat()) {
            return prixVente;
        } else if (isLocation() && prixLocationJour != null) {
            return prixLocationJour.multiply(new BigDecimal(getDureeLocation()));
        }
        return BigDecimal.ZERO;
    }

    @Override
    public String toString() {
        if (isAchat()) {
            return "Panier{Achat de '" + modeleVehicule + "' pour " + prixVente + " €}";
        } else {
            return "Panier{Location de '" + modeleVehicule + "' du " + dateDebut + 
                   " au " + dateFin + " pour " + calculerTotal() + " €}";
        }
    }
}