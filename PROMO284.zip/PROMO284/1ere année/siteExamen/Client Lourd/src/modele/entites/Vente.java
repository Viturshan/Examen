package modele.entites;

import java.util.Date;
import java.math.BigDecimal;

public class Vente {
    private int id;
    private int utilisateurId;
    private int vehiculeId;
    private BigDecimal prixVente;
    private Date dateVente;
    private String statut;

    // Variables pour l'affichage (non stockées en base)
    private String modeleVehicule;
    private String nomUtilisateur;

    // Constructeur complet
    public Vente(int id, int utilisateurId, int vehiculeId, BigDecimal prixVente,
                 Date dateVente, String statut) {
        this.id = id;
        this.utilisateurId = utilisateurId;
        this.vehiculeId = vehiculeId;
        this.prixVente = prixVente;
        this.dateVente = dateVente;
        this.statut = statut;
    }

    // Constructeur pour nouvelle vente
    public Vente(int utilisateurId, int vehiculeId, BigDecimal prixVente) {
        this.utilisateurId = utilisateurId;
        this.vehiculeId = vehiculeId;
        this.prixVente = prixVente;
        this.dateVente = new Date();
        this.statut = "EN_ATTENTE";
    }

    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUtilisateurId() { return utilisateurId; }
    public void setUtilisateurId(int utilisateurId) { this.utilisateurId = utilisateurId; }

    public int getVehiculeId() { return vehiculeId; }
    public void setVehiculeId(int vehiculeId) { this.vehiculeId = vehiculeId; }

    public BigDecimal getPrixVente() { return prixVente; }
    public void setPrixVente(BigDecimal prixVente) { this.prixVente = prixVente; }

    public Date getDateVente() { return dateVente; }
    public void setDateVente(Date dateVente) { this.dateVente = dateVente; }

    public String getStatut() { return statut; }
    public void setStatut(String statut) { this.statut = statut; }

    public String getModeleVehicule() { return modeleVehicule; }
    public void setModeleVehicule(String modeleVehicule) { this.modeleVehicule = modeleVehicule; }

    public String getNomUtilisateur() { return nomUtilisateur; }
    public void setNomUtilisateur(String nomUtilisateur) { this.nomUtilisateur = nomUtilisateur; }

    // Méthodes utiles
    public boolean isPayee() {
        return "PAYEE".equals(this.statut);
    }

    public boolean isAnnulee() {
        return "ANNULEE".equals(this.statut);
    }

    public boolean isModifiable() {
        return "EN_ATTENTE".equals(this.statut);
    }

    @Override
    public String toString() {
        return "Vente{" +
            "id=" + id +
            ", vehicule='" + modeleVehicule + '\'' +
            ", prixVente=" + prixVente +
            ", dateVente=" + dateVente +
            ", statut='" + statut + '\'' +
            '}';
    }
}