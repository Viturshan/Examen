package modele.entites;

import java.math.BigDecimal;

public class Vehicule {
    private int id;
    private String marque;
    private String reference;
    private String modele;
    private String description;
    private int annee;
    private int kilometrage;
    private BigDecimal prixVente;
    private BigDecimal prixLocationJour;
    private boolean disponible;
    private int categorieId;
    private String images;

    // Constructeur complet
    public Vehicule(int id,String marque, String reference, String modele, String description, 
                   int annee, int kilometrage, BigDecimal prixVente, 
                   BigDecimal prixLocationJour, boolean disponible, 
                   int categorieId, String images) {
        this.id = id;
        this.marque = marque;
        this.reference = reference;
        this.modele = modele;
        this.description = description;
        this.annee = annee;
        this.kilometrage = kilometrage;
        this.prixVente = prixVente;
        this.prixLocationJour = prixLocationJour;
        this.disponible = disponible;
        this.categorieId = categorieId;
        this.images = images;
    }

    // Constructeur sans id (pour création)
    public Vehicule(String marque, String reference, String modele, String description, 
                   int annee, int kilometrage, BigDecimal prixVente, 
                   BigDecimal prixLocationJour, int categorieId) {
        this.marque = marque;
        this.reference = reference;
        this.modele = modele;
        this.description = description;
        this.annee = annee;
        this.kilometrage = kilometrage;
        this.prixVente = prixVente;
        this.prixLocationJour = prixLocationJour;
        this.disponible = true;
        this.categorieId = categorieId;
    }

    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getMarque() {
		return marque;
	}

	public void setMarque(String marque) {
		this.marque = marque;
	}

	public String getReference() { return reference; }
    public void setReference(String reference) { this.reference = reference; }

    public String getModele() { return modele; }
    public void setModele(String modele) { this.modele = modele; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public int getAnnee() { return annee; }
    public void setAnnee(int annee) { this.annee = annee; }

    public int getKilometrage() { return kilometrage; }
    public void setKilometrage(int kilometrage) { this.kilometrage = kilometrage; }

    public BigDecimal getPrixVente() { return prixVente; }
    public void setPrixVente(BigDecimal prixVente) { this.prixVente = prixVente; }

    public BigDecimal getPrixLocationJour() { return prixLocationJour; }
    public void setPrixLocationJour(BigDecimal prixLocationJour) { this.prixLocationJour = prixLocationJour; }

    public boolean isDisponible() { return disponible; }
    public void setDisponible(boolean disponible) { this.disponible = disponible; }

    public int getCategorieId() { return categorieId; }
    public void setCategorieId(int categorieId) { this.categorieId = categorieId; }

    public String getImages() { return images; }
    public void setImages(String images) { this.images = images; }

    @Override
    public String toString() {
        return "Vehicule{" +
            "id=" + id +
            ", marque='" + marque + '\'' +
            ", reference='" + reference + '\'' +
            ", modele='" + modele + '\'' +
            ", annee=" + annee +
            ", kilometrage=" + kilometrage +
            ", prixVente=" + prixVente +
            ", prixLocationJour=" + prixLocationJour +
            '}';
    }
}