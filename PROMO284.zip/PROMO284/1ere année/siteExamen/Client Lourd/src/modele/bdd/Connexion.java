package modele.bdd;

import java.sql.*;
import util.Constants;

public class Connexion {
    private static Connexion instance = null;
    private Connection maConnexion;
    
    // Informations de connexion
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String URL = "jdbc:mysql://" + Constants.DB_HOST + ":" + 
                                    Constants.DB_PORT + "/" + Constants.DB_NAME +
                                    "?serverTimezone=UTC";
    private static final String USER = Constants.DB_USER;
    private static final String PASSWORD = Constants.DB_PASSWORD;

    // Constructeur privé (pattern Singleton)
    private Connexion() {
        try {
            // Chargement du driver
            Class.forName(DRIVER);
            
            // Établissement de la connexion
            this.maConnexion = DriverManager.getConnection(URL, USER, PASSWORD);
            
            System.out.println("Connexion à la base de données établie avec succès !");
            
        } catch (ClassNotFoundException e) {
            System.out.println("Erreur de chargement du driver : " + e.getMessage());
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Erreur de connexion à la base de données : " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Méthode pour obtenir l'instance unique de la connexion
    public static synchronized Connexion getInstance() {
        if (instance == null) {
            instance = new Connexion();
        }
        return instance;
    }

    // Méthode pour récupérer la connexion
    public Connection getMaConnexion() {
        // Vérifier si la connexion est toujours valide
        try {
            if (this.maConnexion == null || this.maConnexion.isClosed()) {
                this.maConnexion = DriverManager.getConnection(URL, USER, PASSWORD);
            }
        } catch (SQLException e) {
            System.out.println("Erreur lors de la vérification/restauration de la connexion : " + e.getMessage());
            e.printStackTrace();
        }
        return this.maConnexion;
    }

    // Méthode pour fermer la connexion
    public void fermerConnexion() {
        try {
            if (this.maConnexion != null && !this.maConnexion.isClosed()) {
                this.maConnexion.close();
                System.out.println("Connexion à la base de données fermée avec succès !");
            }
        } catch (SQLException e) {
            System.out.println("Erreur lors de la fermeture de la connexion : " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Méthode pour tester la connexion
    public boolean testerConnexion() {
        try {
            return this.maConnexion != null && !this.maConnexion.isClosed();
        } catch (SQLException e) {
            System.out.println("Erreur lors du test de la connexion : " + e.getMessage());
            return false;
        }
    }

    // Méthode pour réinitialiser la connexion
    public void reinitialiserConnexion() {
        fermerConnexion();
        instance = new Connexion();
    }

    // Méthode pour exécuter une requête de type SELECT
    public ResultSet executeQuery(String requete) throws SQLException {
        Statement stmt = this.getMaConnexion().createStatement();
        return stmt.executeQuery(requete);
    }

    // Méthode pour exécuter une requête de type INSERT, UPDATE, DELETE
    public int executeUpdate(String requete) throws SQLException {
        Statement stmt = this.getMaConnexion().createStatement();
        return stmt.executeUpdate(requete);
    }

    // Méthode pour préparer une requête paramétrée
    public PreparedStatement prepareStatement(String requete) throws SQLException {
        return this.getMaConnexion().prepareStatement(requete);
    }

    // Méthode pour gérer les transactions
    public void setAutoCommit(boolean autoCommit) throws SQLException {
        this.getMaConnexion().setAutoCommit(autoCommit);
    }

    public void commit() throws SQLException {
        this.getMaConnexion().commit();
    }

    public void rollback() throws SQLException {
        this.getMaConnexion().rollback();
    }
}